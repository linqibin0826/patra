"""把 PMC JATS XML 抽成画板用的结构化数据（章节 → 块 → 行内片段），只为出设计稿，不是正式解析器。

用法：python3 -I jats2board.py <xml> <meta.json> <out.json> [--paras N] [--mparas N]
"""
import json
import re
import sys
import xml.etree.ElementTree as ET

XLINK = "{http://www.w3.org/1999/xlink}href"


def local(tag):
    return tag.split("}")[-1] if isinstance(tag, str) else ""


def norm(s):
    return re.sub(r"\s+", " ", s or "")


class Ctx:
    def __init__(self):
        self.first_cite = {}  # rid -> 首次引用的锚点 id
        self.cite_seq = 0


def runs_of(el, ctx, fmt=None, out=None, link=None):
    """把行内混排节点压平成 runs：{text, href, style}。"""
    fmt = fmt or {}
    out = out if out is not None else []

    def emit(text, f, href=None, anchor=None):
        if not text:
            return
        text = norm(text)
        style = []
        if f.get("i"):
            style.append("font-style: italic")
        if f.get("b"):
            style.append("font-weight: 600")
        if f.get("sup"):
            style.append("vertical-align: super; font-size: 0.72em; line-height: 0")
        if f.get("sub"):
            style.append("vertical-align: sub; font-size: 0.72em; line-height: 0")
        if f.get("sc"):
            style.append("font-variant: small-caps")
        r = {"text": text, "style": "; ".join(style)}
        if href:
            r["href"] = href
            r["kind"] = f.get("kind", "ext")
            if anchor:
                r["anchor"] = anchor
        out.append(r)

    def walk(node, f, href, anchor):
        t = local(node.tag)
        nf = dict(f)
        nh, na = href, anchor
        if t == "italic":
            nf["i"] = True
        elif t == "bold":
            nf["b"] = True
        elif t == "sup":
            nf["sup"] = True
        elif t == "sub":
            nf["sub"] = True
        elif t == "sc":
            nf["sc"] = True
        elif t == "xref":
            rt = node.get("ref-type")
            rid = (node.get("rid") or "").split()[0]
            if rt == "bibr":
                nf["kind"] = "cite"
                nh = f"#ref-{rid}"
                ctx.cite_seq += 1
                na = f"cite-{ctx.cite_seq}"
                ctx.first_cite.setdefault(rid, na)
            elif rt in ("fig", "table", "table-fn", "disp-formula"):
                nf["kind"] = "xref"
                nh = f"#{rid}"
        elif t in ("ext-link", "uri"):
            nf["kind"] = "ext"
            nh = node.get(XLINK) or norm("".join(node.itertext()))
        elif t in ("inline-formula", "disp-formula", "tex-math", "math"):
            emit("[公式]", nf)
            if node.tail:
                emit(node.tail, f, href, anchor)
            return
        elif t in ("fig", "table-wrap", "list", "disp-quote", "boxed-text"):
            # 块级节点在段落里出现时，由调用方单独处理
            if node.tail:
                emit(node.tail, f, href, anchor)
            return
        if node.text:
            emit(node.text, nf, nh, na)
        for ch in node:
            walk(ch, nf, nh, na)
        if node.tail and node is not el:
            emit(node.tail, f, href, anchor)

    if el.text:
        emit(el.text, fmt, link)
    for ch in el:
        walk(ch, fmt, link, None)
    # 去掉首尾空白
    if out:
        out[0]["text"] = out[0]["text"].lstrip()
        out[-1]["text"] = out[-1]["text"].rstrip()
    return [r for r in out if r["text"]]


def caption_of(node, ctx):
    cap = node.find("caption")
    title, text = "", []
    if cap is not None:
        t = cap.find("title")
        if t is not None:
            title = norm("".join(t.itertext())).strip()
        for p in cap.findall("p"):
            text.extend(runs_of(p, ctx))
            text.append({"text": " ", "style": ""})
    return title, [r for r in text if r["text"].strip() or r["text"] == " "]


def cell_text(c):
    return norm("".join(c.itertext())).strip()


def table_of(tw, ctx):
    label = norm(tw.findtext("label") or "").strip()
    title, cap = caption_of(tw, ctx)
    head, rows = [], []
    for tr in tw.iter():
        if local(tr.tag) != "tr":
            continue
        cells = []
        for c in tr:
            if local(c.tag) in ("td", "th"):
                cells.append({"v": cell_text(c), "span": int(c.get("colspan") or 1), "rs": int(c.get("rowspan") or 1)})
        parent_is_head = False
        rows.append((cells, tr))
    # thead 判断
    thead = tw.find(".//thead")
    head_trs = set(thead.iter()) if thead is not None else set()
    head = [c for c, tr in rows if tr in head_trs]
    body = [c for c, tr in rows if tr not in head_trs]
    foot = []
    f = tw.find("table-wrap-foot")
    if f is not None:
        for p in f.iter():
            if local(p.tag) in ("p",):
                foot.append(norm("".join(p.itertext())).strip())
    ncols = max([sum(c["span"] for c in r) for r in head + body] or [0])
    return {
        "kind": "table", "id": tw.get("id"), "label": label, "title": title, "caption": cap,
        "head": head, "rows": body, "nrows": len(body), "ncols": ncols, "foot": foot[:3],
    }


def fig_of(fg, ctx):
    label = norm(fg.findtext("label") or "").strip()
    title, cap = caption_of(fg, ctx)
    g = fg.find(".//graphic")
    href = g.get(XLINK) if g is not None else None
    return {"kind": "fig", "id": fg.get("id"), "label": label, "title": title, "caption": cap, "file": href}


def blocks_of_sec(sec, ctx, level, out, toc, budget):
    title_el = sec.find("title")
    title = norm("".join(title_el.itertext())).strip() if title_el is not None else ""
    label = norm(sec.findtext("label") or "").strip()
    sid = sec.get("id") or f"sec-{len(toc)+1}"
    if title:
        out.append({"kind": "h2" if level == 1 else "h3", "id": sid, "text": (label + " " if label else "") + title})
        toc.append({"id": sid, "title": title, "level": level})
    paras = 0
    for ch in sec:
        t = local(ch.tag)
        if t == "p":
            # 段落里嵌的块级 fig / table-wrap 拆出来
            inner = [x for x in ch if local(x.tag) in ("fig", "table-wrap")]
            paras += 1
            out.append({"kind": "p", "runs": runs_of(ch, ctx), "n": paras})
            for x in inner:
                out.append(fig_of(x, ctx) if local(x.tag) == "fig" else table_of(x, ctx))
        elif t == "fig":
            out.append(fig_of(ch, ctx))
        elif t == "table-wrap":
            out.append(table_of(ch, ctx))
        elif t == "list":
            items = [runs_of(li.find("p") if li.find("p") is not None else li, ctx) for li in ch.findall("list-item")]
            out.append({"kind": "list", "items": [{"runs": r} for r in items], "n": paras})
        elif t == "sec":
            blocks_of_sec(ch, ctx, level + 1, out, toc, budget)
        elif t == "disp-formula":
            out.append({"kind": "formula", "id": ch.get("id")})


def ref_of(ref, ctx, n):
    rid = ref.get("id")
    cit = None
    for c in ref:
        if local(c.tag) in ("element-citation", "mixed-citation", "citation"):
            cit = c
            break
    label = norm(ref.findtext("label") or "").strip() or str(n)
    doi = pmid = None
    text = ""
    if cit is not None:
        for pid in cit.findall("pub-id"):
            if pid.get("pub-id-type") == "doi":
                doi = norm(pid.text).strip()
            if pid.get("pub-id-type") == "pmid":
                pmid = norm(pid.text).strip()
        if local(cit.tag) == "mixed-citation":
            text = norm("".join(x for x in cit.itertext())).strip()
        else:
            names = []
            for nm in cit.iter():
                if local(nm.tag) == "name":
                    sn = norm(nm.findtext("surname") or "").strip()
                    gn = norm(nm.findtext("given-names") or "").strip()
                    names.append(f"{sn} {gn}".strip())
            etal = cit.find(".//etal") is not None
            au = ", ".join(names[:6]) + (", et al" if etal or len(names) > 6 else "")
            at = norm("".join(cit.find("article-title").itertext())).strip() if cit.find("article-title") is not None else ""
            src = norm("".join(cit.find("source").itertext())).strip() if cit.find("source") is not None else ""
            yr = norm(cit.findtext("year") or "").strip()
            vol = norm(cit.findtext("volume") or "").strip()
            fp = norm(cit.findtext("fpage") or cit.findtext("elocation-id") or "").strip()
            lp = norm(cit.findtext("lpage") or "").strip()
            pages = fp + ("–" + lp if lp else "")
            parts = [au + "." if au else "", at.rstrip(".") + "." if at else "", (src + " " if src else "") + yr + (";" + vol if vol else "") + (":" + pages if pages else "") + "."]
            text = " ".join(p for p in parts if p).replace(" .", ".")
    text = re.sub(r"\s*doi:\s*\S+", "", text)
    text = re.sub(r"\s*PMID:?\s*\d+", "", text)
    r = {"id": f"ref-{rid}", "label": label, "text": text.strip(), "back": ctx.first_cite.get(rid)}
    if doi:
        r["doi"] = doi
    if pmid:
        r["pmid"] = pmid
    return r


def main():
    xml_path, meta_path, out_path = sys.argv[1:4]
    raw = open(xml_path, encoding="utf-8").read()
    raw = re.sub(r"<!DOCTYPE[^>]*>", "", raw)
    root = ET.fromstring(raw)
    meta = json.load(open(meta_path))
    ctx = Ctx()
    front = root.find("front")
    am = front.find("article-meta")
    title = norm("".join(am.find("title-group/article-title").itertext())).strip()
    authors = []
    for c in am.iter():
        if local(c.tag) == "contrib" and c.get("contrib-type") == "author":
            nm = c.find("name")
            if nm is not None:
                authors.append((norm(nm.findtext("given-names") or "") + " " + norm(nm.findtext("surname") or "")).strip())
            elif c.find("collab") is not None:
                authors.append(norm("".join(c.find("collab").itertext())).strip())
    lic = am.find(".//license")
    lic_url = lic.get(XLINK) if lic is not None else None
    if lic is not None and not lic_url:
        for x in lic.iter():
            if local(x.tag) == "ext-link":
                lic_url = x.get(XLINK)
                break
    abstract = []
    ab = am.find("abstract")
    if ab is not None:
        secs = ab.findall("sec")
        if secs:
            for s in secs:
                t = norm(s.findtext("title") or "").strip()
                txt = " ".join(norm("".join(p.itertext())).strip() for p in s.findall("p"))
                abstract.append({"label": t, "text": txt})
        else:
            for p in ab.findall("p"):
                abstract.append({"label": "", "text": norm("".join(p.itertext())).strip()})
    body = root.find("body")
    blocks, toc = [], []
    for ch in body:
        t = local(ch.tag)
        if t == "sec":
            blocks_of_sec(ch, ctx, 1, blocks, toc, None)
        elif t == "p":
            blocks.append({"kind": "p", "runs": runs_of(ch, ctx), "n": 1})
    words = len(re.sub(r"<[^>]+>", " ", ET.tostring(body, encoding="unicode")).split())
    refs = []
    back = root.find("back")
    if back is not None:
        for i, r in enumerate(back.iter()):
            pass
        n = 0
        for r in back.iter():
            if local(r.tag) == "ref":
                n += 1
                refs.append(ref_of(r, ctx, n))
    # 浮动在 floats-group 的图表
    fg = root.find("floats-group")
    floats = {}
    if fg is not None:
        for x in fg:
            if local(x.tag) == "fig":
                floats[x.get("id")] = fig_of(x, ctx)
            elif local(x.tag) == "table-wrap":
                floats[x.get("id")] = table_of(x, ctx)
    out = {
        "pmcid": meta["pmcid"], "doi": meta["doi"], "pmid": meta.get("pmid"), "citation": meta["citation"],
        "license": meta.get("license_code"), "licenseUrl": lic_url, "hasPdf": bool(meta.get("pdf_url")),
        "title": title, "authors": authors, "abstract": abstract, "words": words,
        "readMin": max(1, -(-words // 200)), "toc": toc, "blocks": blocks, "floats": floats, "refs": refs,
        "counts": {
            "fig": sum(1 for b in blocks if b["kind"] == "fig") + sum(1 for v in floats.values() if v["kind"] == "fig"),
            "table": sum(1 for b in blocks if b["kind"] == "table") + sum(1 for v in floats.values() if v["kind"] == "table"),
            "ref": len(refs),
        },
    }
    json.dump(out, open(out_path, "w"), ensure_ascii=False, indent=1)
    print(out_path, "words", words, "readMin", out["readMin"], "toc", len(toc), "blocks", len(blocks), "refs", len(refs), "counts", out["counts"], "floats", list(floats))
    for t in toc:
        print("  " * t["level"], t["id"], t["title"])
    for b in blocks:
        if b["kind"] in ("fig", "table"):
            print("   [", b["kind"], b["id"], b["label"], b.get("title", "")[:70], b.get("nrows", ""), b.get("ncols", ""), b.get("file", ""))


if __name__ == "__main__":
    main()
