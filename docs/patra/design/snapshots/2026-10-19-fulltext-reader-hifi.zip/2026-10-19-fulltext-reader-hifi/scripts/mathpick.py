import re, sys
x = open(sys.argv[1]).read()
def clean(m):
    m = re.sub(r"</?mml:", lambda k: k.group(0).replace("mml:", ""), m)
    m = re.sub(r'\s(xmlns:mml|id|overflow|class|columnalign)="[^"]*"', "", m)
    # mfenced -> mrow + mo
    def fx(mt):
        attrs, inner = mt.group(1), mt.group(2)
        o = re.search(r'open="([^"]*)"', attrs); c = re.search(r'close="([^"]*)"', attrs)
        o = o.group(1) if o else "("; c = c.group(1) if c else ")"
        return f"<mrow><mo>{o}</mo>{inner}<mo>{c}</mo></mrow>"
    for _ in range(5):
        m = re.sub(r"<mfenced([^>]*)>((?:(?!<mfenced).)*?)</mfenced>", fx, m, flags=re.S)
    return re.sub(r"\s+", " ", m)
disp = re.findall(r'<disp-formula id="([^"]+)">(.*?)</disp-formula>', x, re.S)
for i, (fid, body) in enumerate(disp):
    lab = re.search(r"<label>(.*?)</label>", body)
    mm = re.search(r"<mml:math.*?</mml:math>", body, re.S)
    if not mm: continue
    c = clean(mm.group(0))
    print(i, fid, "label", lab.group(1) if lab else None, "len", len(c), "mfenced", "mfenced" in mm.group(0), "mtable", "mtable" in c, "mi count", c.count("<mi"))
