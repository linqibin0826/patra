"""把抽出的文章数据裁成画板用的样例集 fulltext-samples.json（画板运行时 fetch）。

用法：python3 -I build_samples.py <data_dir> <out.json>
"""
import json
import re
import sys

D = sys.argv[1]
OUT = sys.argv[2]
BLOB = {
    "bmjopen-16-9-g001.webp": "/_blob/d3115ffcf7296c7721e490a590b95c70",
    "bmjopen-16-9-g002.webp": "/_blob/f43005898395de1051b509c1761c0ec5",
    "jamanetwopen-e2637214-g001.webp": "/_blob/c83b309d0a94994d2da3623b59be21e3",
}
DIMS = {
    "bmjopen-16-9-g001.webp": (1600, 2159),
    "bmjopen-16-9-g002.webp": (1600, 2319),
    "jamanetwopen-e2637214-g001.webp": (2000, 1293),
}
FETCHED = "2026-10-18"
# 按简报附录 A.4 的口径数的正文词数（去掉 MathML、表格单元格、补充材料）；阅读时长按后端 spec 7.2 的 230 词 / 分钟
WORDS = {"PMC13583816.1": 6913, "PMC13633532.1": 4635, "PMC12670376.1": 11076}
RCT = {"label": "随机对照试验", "en": "RCT", "lit": [1, 1, 1, 1, 0]}


def load(name):
    return json.load(open(f"{D}/{name}.json"))


def license_label(code, url):
    if not code:
        return "许可见原文"
    m = re.search(r"/licenses/([a-z-]+)/([\d.]+)", url or "")
    if m:
        return "CC " + m.group(1).upper() + " " + m.group(2)
    return code


def size_label(n):
    if n is None:
        return None
    if n >= 1024 * 1024:
        return f"{n / 1024 / 1024:.1f} MB"
    return f"{round(n / 1024)} KB"


def grid(rows):
    """把 rowspan / colspan 展开成矩形网格（画板简化，空格占位）。"""
    out, carry = [], {}
    for r in rows:
        line, ci, it = [], 0, iter(r)
        cells = list(r)
        k = 0
        while k < len(cells) or carry.get(ci):
            if carry.get(ci):
                line.append({"v": ""})
                carry[ci] -= 1
                ci += 1
                continue
            c = cells[k]
            k += 1
            line.append({"v": c["v"]})
            if c.get("rs", 1) > 1:
                carry[ci] = c["rs"] - 1
            for _ in range(c.get("span", 1) - 1):
                ci += 1
                line.append({"v": ""})
            ci += 1
        out.append(line)
    return out


def shape_runs(runs):
    out = []
    for r in runs:
        x = {"text": r["text"], "style": r.get("style", "")}
        if r.get("href"):
            x["isLink"] = True
            x["href"] = r["href"]
            x["cls"] = "pt-cite" if r.get("kind") == "cite" else "pt-xref" if r.get("kind") == "xref" else "pt-link"
            x["anchor"] = r.get("anchor") or ""
            x["label"] = "参考文献 " + r["text"].strip("[]() ") if r.get("kind") == "cite" else r["text"]
        else:
            x["isPlain"] = True
        out.append(x)
    return out


def shape_block(b, mobile):
    k = b["kind"]
    x = {"mobile": mobile, "isMath": False, "isH2": k == "h2", "isH3": k == "h3", "isP": k == "p", "isFig": k == "fig",
         "isTable": k == "table", "isList": k == "list"}
    if k in ("h2", "h3"):
        x.update(id=b["id"], text=b["text"])
    elif k == "p":
        x["runs"] = shape_runs(b["runs"])
    elif k == "list":
        x["items"] = [{"runs": shape_runs(i["runs"])} for i in b["items"]]
    elif k == "fig":
        w, h = DIMS.get(b["file"], (1600, 1000))
        x.update(id=b["id"], label=b["label"].upper().rstrip("."), title=b["title"],
                 caption="".join(r["text"] for r in b["caption"]).strip(), src=BLOB.get(b["file"], ""),
                 ratio=f"{w} / {h}", tall=h > w)
    elif k == "table":
        head = grid(b["head"])
        rows = grid(b["rows"])
        x.update(id=b["id"], label=b["label"].upper().rstrip("."), title=b["title"] or "".join(r["text"] for r in b["caption"]).strip(),
                 head=[{"cells": r} for r in head], rows=[{"cells": r} for r in rows], nrows=len(rows),
                 foot=b["foot"], collapsible=len(rows) > 12)
    return x


def toc_of(blocks):
    toc = []
    for b in blocks:
        if b["isH2"]:
            toc.append({"id": b["id"], "title": b["text"], "children": []})
        elif b["isH3"] and toc:
            toc[-1]["children"].append({"id": b["id"], "title": b["text"]})
    return toc


def clean_ref(t):
    t = re.sub(r",\s*\.", ", et al.", t)
    t = re.sub(r"\s+\.", ".", t)
    t = re.sub(r"\s+,", ",", t)
    return t


def fulltext(src, desk, mob, pdf_bytes, extra_blocks=None):
    d = load(src)
    keep = {i: (i in mob) for i in desk}
    blocks = [shape_block(d["blocks"][i], keep[i]) for i in desk]
    if extra_blocks:
        blocks = extra_blocks(d) + blocks
    cited_first = {}
    for b in blocks:
        for r in b.get("runs", []):
            if r.get("cls") == "pt-cite":
                rid = r["href"][1:]
                cited_first.setdefault(rid, r["anchor"])
    refs = []
    for r in d["refs"]:
        refs.append({"id": r["id"], "label": r["label"], "text": clean_ref(r["text"]),
                     "doi": r.get("doi") or "", "pmid": r.get("pmid") or "",
                     "doiHref": f"https://doi.org/{r['doi']}" if r.get("doi") else "",
                     "pmidHref": f"https://pubmed.ncbi.nlm.nih.gov/{r['pmid']}/" if r.get("pmid") else "",
                     "back": cited_first.get(r["id"], "")})
    authors = d["authors"]
    names = "、".join(authors[:10]) + (f" 等 {len(authors)} 位" if len(authors) > 10 else "")
    cit = d["citation"].split(" doi:")[0]
    return {
        "pmcid": d["pmcid"], "pmcHref": f"https://pmc.ncbi.nlm.nih.gov/articles/{d['pmcid']}/",
        "license": license_label(d["license"], d["licenseUrl"]), "licenseHref": d["licenseUrl"] or "",
        "citation": cit, "fetchedAt": FETCHED, "hasPdf": pdf_bytes is not None, "pdfSize": size_label(pdf_bytes),
        "words": f"{WORDS[src]:,}", "readMin": -(-WORDS[src] // 230), "nfig": d["counts"]["fig"], "ntab": d["counts"]["table"],
        "nref": len(refs), "authorsAll": names, "doi": d["doi"], "doiHref": f"https://doi.org/{d['doi']}",
        "toc": toc_of(blocks), "blocks": blocks, "refs": refs,
    }, d


def head(d, types, venue, year, evidence, corr=None):
    a = d["authors"]
    shown = [{"name": n, "corr": (n == corr)} for n in a[:3]]
    return {"types": types, "title": d["title"], "authors": shown, "extra": max(0, len(a) - 3), "venue": venue,
            "year": year, "evidence": evidence, "nAuthors": len(a)}


samples = {}

# 有全文 · 有 PDF：BMJ Open RCT
ft, d = fulltext("PMC13583816.1", [0, 1, 2, 3, 8, 9, 11, 12, 36, 40, 41, 42, 49, 52, 59, 60],
                 {0, 2, 3, 36, 40, 42}, 2609513)
samples["ft"] = {"head": head(d, ["Randomized Controlled Trial", "Journal Article"], "BMJ Open", 2026, RCT),
                 "abstract": d["abstract"], "pmid": "42731841", "ft": ft}
# 有全文 · 无 PDF：JAMA Netw Open
ft, d = fulltext("PMC13633532.1", [0, 1, 2, 4, 5, 6, 7, 9, 10, 11, 22, 23, 24, 25, 26, 34, 35, 42, 43],
                 {0, 4, 22, 23, 25, 26}, None)
for b in ft["blocks"]:
    if b["isTable"]:
        b["title"] = b["title"].rstrip(".")
samples["nopdf"] = {"head": head(d, ["Journal Article", "Observational Study"], "JAMA Netw Open", 2026, None),
                    "abstract": d["abstract"], "pmid": "42826020", "ft": ft}
# 压力样例：Stat Med。正文的公式段落在 StressMath 画板里是字面 MathML，这里只给两张表与参考文献
d = load("PMC12670376.1")
tb = {b["id"]: b for b in d["blocks"] if b["kind"] == "table"}
blocks = [
    {"mobile": True, "isH2": True, "id": "sim70237-sec-0002", "text": "Nonadaptive Graph‐Based Closed Testing"},
    {"mobile": True, "isMath": True},
    shape_block(tb["sim70237-tbl-0001"], True),
    {"mobile": True, "isH2": True, "id": "sim70237-sec-0015", "text": "Simulation study"},
    shape_block(tb["sim70237-tbl-0013"], True),
]
FLAGS = ("isH2", "isH3", "isP", "isFig", "isTable", "isList", "isMath")
for b in blocks:
    for f in FLAGS:
        b.setdefault(f, False)
refs = [{"id": r["id"], "label": r["label"], "text": clean_ref(r["text"]), "doi": r.get("doi") or "",
         "pmid": r.get("pmid") or "", "doiHref": f"https://doi.org/{r['doi']}" if r.get("doi") else "",
         "pmidHref": f"https://pubmed.ncbi.nlm.nih.gov/{r['pmid']}/" if r.get("pmid") else "", "back": ""}
        for r in d["refs"]]
for r in refs:
    if r["id"] == "ref-sim70237-bib-0008":
        r["back"] = "cite-stress-8"
samples["stress"] = {
    "head": head(d, ["Journal Article"], "Stat Med", 2025, None), "abstract": d["abstract"], "pmid": "41328627",
    "ft": {"pmcid": d["pmcid"], "pmcHref": f"https://pmc.ncbi.nlm.nih.gov/articles/{d['pmcid']}/",
           "license": license_label(d["license"], d["licenseUrl"]), "licenseHref": d["licenseUrl"] or "",
           "citation": d["citation"].split(" doi:")[0], "fetchedAt": FETCHED, "hasPdf": True, "pdfSize": size_label(1535739),
           "words": "11,076", "readMin": 49, "nfig": 7, "ntab": 14, "nref": len(refs),
           "authorsAll": "、".join(d["authors"]), "doi": d["doi"], "doiHref": f"https://doi.org/{d['doi']}",
           "toc": toc_of(blocks), "blocks": blocks, "refs": refs}}

# 无全文：三种原因各一篇真实文献
def nf(pmid, types, venue, year, evidence, reason, pmcid=None):
    r = json.load(open(f"{D}/nf-{pmid}.json"))["resultList"]["result"][0]
    a = [x.get("fullName") for x in r["authorList"]["author"]]
    ab = re.sub(r"<[^>]+>", " ", r.get("abstractText", "")).strip()
    parts = re.split(r"\s*\b(Background|Methods|Results|Conclusions)\b\s+", ab)
    abstract = []
    if len(parts) > 2:
        for i in range(1, len(parts) - 1, 2):
            abstract.append({"label": parts[i], "text": re.sub(r"\s+", " ", parts[i + 1]).strip()})
    elif ab:
        abstract.append({"label": "", "text": re.sub(r"\s+([,.;])", r"\1", re.sub(r"\s+", " ", ab))})
    return {"head": {"types": types, "title": r["title"].rstrip("."), "authors": [{"name": n, "corr": False} for n in a[:3]],
                     "extra": max(0, len(a) - 3), "venue": venue, "year": year, "evidence": evidence, "nAuthors": len(a)},
            "abstract": abstract, "pmid": str(pmid), "pmcid": pmcid, "doi": r.get("doi"), "reason": reason}

samples["nf_none"] = nf(42776074, ["Randomized Controlled Trial", "Multicenter Study"], "N Engl J Med", 2026, RCT, "none")
samples["nf_free"] = nf(41115161, ["Review", "Journal Article"], "Circulation", 2025, None, "free", "PMC12687667")
samples["nf_retracted"] = nf(38764239, ["Letter", "Retracted Publication"], "Cell Prolif", 2024, None, "retracted", "PMC11628729")
# 有 PDF 无正文（后端 NO_BODY）：XML 没有 <body>，PMC 提供了 PDF；元数据许可为空
samples["pdfonly"] = nf(15609508, ["Review", "Journal Article"], "Curr Top Microbiol Immunol", 2005, None, "pdfonly", "PMC7121018")
samples["pdfonly"]["pdf"] = {"pdfSize": size_label(342460), "license": "许可见原文", "licenseHref": "", "fetchedAt": FETCHED,
                             "citation": "Coronavirus Replication and Reverse Genetics. 2005;287:31–55."}

json.dump(samples, open(OUT, "w"), ensure_ascii=False, separators=(",", ":"))
import os
print(OUT, os.path.getsize(OUT), "bytes")
for k, v in samples.items():
    f = v.get("ft")
    print(k, v["head"]["title"][:60], "| abstract", len(v["abstract"]), "| blocks", len(f["blocks"]) if f else "-", "| toc", [t["title"][:20] for t in f["toc"]] if f else "-")
