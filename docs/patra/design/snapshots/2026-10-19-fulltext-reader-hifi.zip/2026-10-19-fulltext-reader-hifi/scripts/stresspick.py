import re, sys
x = open(sys.argv[1]).read()
def clean(m):
    m = re.sub(r"</?mml:", lambda k: k.group(0).replace("mml:", ""), m)
    m = re.sub(r'\s(xmlns:mml|xmlns|id|overflow|class|columnalign|columnspacing|rowspacing)="[^"]*"', "", m)
    def fx(mt):
        attrs, inner = mt.group(1), mt.group(2)
        o = re.search(r'open="([^"]*)"', attrs); c = re.search(r'close="([^"]*)"', attrs)
        return f"<mrow><mo>{o.group(1) if o else '('}</mo>{inner}<mo>{c.group(1) if c else ')'}</mo></mrow>"
    for _ in range(6):
        m = re.sub(r"<mfenced([^>]*)>((?:(?!<mfenced).)*?)</mfenced>", fx, m, flags=re.S)
    m = re.sub(r"\s+", " ", m).replace("> <", "><")
    # 去掉冗余的单子 mrow 包裹
    for _ in range(4):
        m = re.sub(r"<mrow><mrow>((?:(?!<mrow>|</mrow>).)*)</mrow></mrow>", r"<mrow>\1</mrow>", m)
    return m
def conv(s):
    s = re.sub(r"<mml:math.*?</mml:math>", lambda k: clean(k.group(0)), s, flags=re.S)
    s = re.sub(r'<xref ref-type="bibr" rid="([^"]+)">(.*?)</xref>', r'<a class="pt-cite" href="#ref-\1">\2</a>', s)
    s = re.sub(r'<xref[^>]*>(.*?)</xref>', r'\1', s)
    s = s.replace("<italic>", "<i>").replace("</italic>", "</i>").replace("<bold>", "<b>").replace("</bold>", "</b>")
    return re.sub(r"\s+", " ", s).strip()
sec = x.split('<sec id="sim70237-sec-0002"')[1]
ps = re.findall(r"<p>(.*?)</p>", sec, re.S)
p2 = conv(ps[1])
print("P2", len(p2)); print(p2)
disp = dict(re.findall(r'<disp-formula id="([^"]+)">(.*?)</disp-formula>', x, re.S))
for fid in ["sim70237-disp-0001", "sim70237-disp-0002", "sim70237-disp-0004", "sim70237-disp-0050"]:
    b = disp[fid]; lab = re.search(r"<label>(.*?)</label>", b)
    m = clean(re.search(r"<mml:math.*?</mml:math>", b, re.S).group(0))
    print("DISP", fid, lab.group(1) if lab else "", len(m)); print(m)
