import { createRequire } from "node:module";
import { readFileSync, existsSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
const require = createRequire(join(process.cwd(), "patra-portal/package.json")); // 在仓库根目录运行;
const { chromium } = require("@playwright/test");
const here = dirname(fileURLToPath(import.meta.url));
const [canvasDir, outDir] = process.argv.slice(2);
const BLOB = { "021ded01655533ba6021f8d53bb7e598": "assets/patra-mark.svg", "d3115ffcf7296c7721e490a590b95c70": "assets/bmjopen-16-9-g001.webp", "f43005898395de1051b509c1761c0ec5": "assets/bmjopen-16-9-g002.webp", "c83b309d0a94994d2da3623b59be21e3": "assets/jamanetwopen-e2637214-g001.webp", "a47ebcc84061c7119a8d15574923ef77": "data/fulltext-samples.json" };
const T = { html: "text/html", css: "text/css", js: "text/javascript", svg: "image/svg+xml", webp: "image/webp", json: "application/json" };
const browser = await chromium.launch();
async function open(file, q, vp) {
  const ctx = await browser.newContext({ viewport: vp });
  const page = await ctx.newPage();
  page.on("pageerror", (e) => console.log("[pageerror]", e.message));
  await page.route(/^https?:\/\//, (route) => {
    const u = new URL(route.request().url());
    if (u.hostname !== "patra.test") return route.abort();
    let f = u.pathname.startsWith("/_blob/") ? (BLOB[u.pathname.slice(7)] ? join(canvasDir, BLOB[u.pathname.slice(7)]) : "") : u.pathname === "/support.js" ? join(here, "support.js") : join(canvasDir, "project", u.pathname.slice(1));
    if (!f || !existsSync(f)) return route.fulfill({ status: 404, body: "" });
    return route.fulfill({ status: 200, contentType: T[f.split(".").pop()], body: readFileSync(f) });
  });
  await page.goto(`http://patra.test/${file}?${new URLSearchParams(q)}`);
  await page.waitForFunction(() => window.__dcReady && document.querySelector(".pt-main"));
  await page.waitForTimeout(300);
  return page;
}
// 桌面：引用跳转
let p = await open("Main.dc.html", { scenario: "有全文" }, { width: 1440, height: 900 });
console.log("refs before", await p.locator(".pt-ref").count());
await p.locator('a.pt-cite[href="#ref-R8"]').first().click();
await p.waitForTimeout(900);
console.log("refs after", await p.locator(".pt-ref").count(), "target", await p.locator(".pt-ref.is-target").getAttribute("id"),
  "back", await p.locator(".pt-ref.is-target .pt-ref-back").getAttribute("href"), "scrollY", await p.evaluate(() => Math.round(scrollY)));
await p.screenshot({ path: join(outDir, "i-cite.png") });
await p.locator(".pt-ref.is-target .pt-ref-back").click(); await p.waitForTimeout(600);
console.log("after back scrollY", await p.evaluate(() => Math.round(scrollY)));
// 长表展开
const before = await p.locator("#T2 .pt-tbody .pt-tr").count();
await p.locator("#T2 .pt-tbl-more button").click(); await p.waitForTimeout(200);
console.log("table rows", before, "->", await p.locator("#T2 .pt-tbody .pt-tr").count(), await p.locator("#T2 .pt-tbl-more button").textContent());
// 目录
await p.locator('.pt-aside-toc a[href="#s3"]').click(); await p.waitForTimeout(500);
console.log("toc active", await p.locator(".pt-aside-toc .pt-toc-a.is-active").allTextContents(), "scrollY", await p.evaluate(() => Math.round(scrollY)));
await p.screenshot({ path: join(outDir, "i-toc.png") });
// 放大图
await p.locator("#F1 .pt-fig-tray").click(); await p.waitForTimeout(400);
console.log("lightbox", await p.locator(".pt-lightbox").count());
await p.screenshot({ path: join(outDir, "i-lightbox.png") });
await p.locator(".pt-lightbox-close").click(); await p.waitForTimeout(200);
console.log("lightbox closed", await p.locator(".pt-lightbox").count());
// 移动：目录面板
p = await open("Mobile.dc.html", { scenario: "有全文" }, { width: 375, height: 812 });
await p.locator(".pt-toc-trigger").click(); await p.waitForTimeout(300);
console.log("sheet", await p.locator(".pt-sheet").count());
await p.screenshot({ path: join(outDir, "i-sheet.png") });
await p.locator('.pt-sheet a[href="#s3"]').click(); await p.waitForTimeout(500);
console.log("sheet after pick", await p.locator(".pt-sheet").count(), "scrollY", await p.evaluate(() => Math.round(scrollY)));
await p.screenshot({ path: join(outDir, "i-sheet-after.png") });
await browser.close();
