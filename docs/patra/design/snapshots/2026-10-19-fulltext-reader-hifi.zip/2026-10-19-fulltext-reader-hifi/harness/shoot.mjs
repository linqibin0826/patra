// 用 portal 自带的 Playwright 渲染画板（垫片运行时），按场景截整页图并量高度。
// 用法：node shoot.mjs <canvasDir> <outDir> [offline]
import { createRequire } from "node:module";
import { readFileSync, mkdirSync, existsSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const require = createRequire(join(process.cwd(), "patra-portal/package.json")); // 在仓库根目录运行;
const { chromium } = require("@playwright/test");
const here = dirname(fileURLToPath(import.meta.url));
const [canvasDir, outDir, offline] = process.argv.slice(2);
mkdirSync(outDir, { recursive: true });
const BLOB = {
  "021ded01655533ba6021f8d53bb7e598": "assets/patra-mark.svg",
  "d3115ffcf7296c7721e490a590b95c70": "assets/bmjopen-16-9-g001.webp",
  "f43005898395de1051b509c1761c0ec5": "assets/bmjopen-16-9-g002.webp",
  "c83b309d0a94994d2da3623b59be21e3": "assets/jamanetwopen-e2637214-g001.webp",
  "a47ebcc84061c7119a8d15574923ef77": "data/fulltext-samples.json",
};
const TYPES = { html: "text/html", css: "text/css", js: "text/javascript", svg: "image/svg+xml", webp: "image/webp", json: "application/json" };
const SCEN = [
  ["ft", "有全文", ""],
  ["nopdf", "有全文无 PDF", ""],
  ["nf-none", "无全文", "不在开放获取子集"],
  ["nf-free", "无全文", "PMC 收录但不能转载"],
  ["pdfonly", "有 PDF 无正文", ""],
  ["nf-retracted", "无全文", "已撤稿"],
  ["stress", "压力样例", ""],
  ["ft-manuscript", "有全文", ""],
  ["loading", "全文加载中", ""],
  ["error", "全文加载失败", ""],
];
const only = process.env.ONLY ? process.env.ONLY.split(",") : null;
const sizes = process.env.SIZES ? process.env.SIZES.split(",") : ["desktop", "mobile"];

const browser = await chromium.launch(offline ? {} : { proxy: { server: "http://127.0.0.1:7890" } });
const results = {};
for (const size of sizes) {
  const ctx = await browser.newContext(
    size === "desktop" ? { viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 } : { viewport: { width: 375, height: 812 }, deviceScaleFactor: 2 },
  );
  const page = await ctx.newPage();
  page.on("pageerror", (e) => console.log("[pageerror]", size, e.message));
  page.on("console", (m) => { if (m.type() === "error") console.log("[console]", size, m.text()); });
  await page.route(/^https?:\/\//, async (route) => {
    const u = new URL(route.request().url());
    if (u.hostname === "patra.test") {
      let file;
      if (u.pathname.startsWith("/_blob/")) file = BLOB[u.pathname.slice(7)] ? join(canvasDir, BLOB[u.pathname.slice(7)]) : "";
      else if (u.pathname === "/support.js") file = join(here, "support.js");
      else file = join(canvasDir, "project", u.pathname.slice(1));
      const ext = file.split(".").pop();
      if (!file || !existsSync(file)) return route.fulfill({ status: 404, body: "" });
      return route.fulfill({ status: 200, contentType: TYPES[ext] || "application/octet-stream", body: readFileSync(file) });
    }
    if (offline) return route.abort();
    return route.continue();
  });
  for (const [slug, scenario, reason] of SCEN) {
    if (only && !only.includes(slug)) continue;
    const file = size === "desktop" ? "Main.dc.html" : "Mobile.dc.html";
    const q = new URLSearchParams({ scenario, ...(reason ? { reason } : {}), ...(slug === "ft-manuscript" ? { manuscript: "1" } : {}) });
    await page.goto(`http://patra.test/${file}?${q}`, { waitUntil: "domcontentloaded" });
    await page.waitForFunction(() => window.__dcReady && document.querySelector(".pt-main"), null, { timeout: 20000 });
    await page.evaluate(() => document.fonts.ready);
    await page.waitForTimeout(offline ? 300 : 1500);
    const h = await page.evaluate(() => document.documentElement.scrollHeight);
    results[`${size}/${slug}`] = h;
    await page.screenshot({ path: join(outDir, `${size}-${slug}.png`), fullPage: true });
    console.log(size, slug, "height", h);
  }
  await ctx.close();
}
await browser.close();
console.log(JSON.stringify(results));
