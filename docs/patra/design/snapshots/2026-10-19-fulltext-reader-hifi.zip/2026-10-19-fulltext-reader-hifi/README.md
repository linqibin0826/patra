# v0.11 全文阅读 · 画板快照（PAP-83）

持久画布：https://claude.ai/artifact/4GKkd2ioquYvJmxP3vXjED　设计简报：`patra-portal/docs/design-briefs/v0.11/fulltext-reader.md`

| 目录 | 内容 |
|------|------|
| `project/` | 画布源文件：`canvas.json`、`Main.dc.html`（桌面 1440，阅读页本体）、`Mobile.dc.html`（移动 375，引用 Main 并打开窄屏模式）、`patra.css`（token 取自 portal `tokens.css` + 全文阅读版式类）、`ds/patra/tokens.json`（设计系统 token 副本） |
| `assets/` | 品牌标记与正文图片（PMC 公开桶原图，画布里以 `/_blob/<id>` 引用） |
| `data/fulltext-samples.json` | 画板运行时读取的样例集：有全文（PMC13583816）、有全文无 PDF（PMC13633532）、压力样例（PMC12670376）、无全文三种原因各一篇、有 PDF 无正文（PMC7121018） |
| `scripts/` | `jats2board.py` 把 JATS 抽成章节 / 块 / 行内片段；`build_samples.py` 裁节选、生成样例集；`stresspick.py` / `mathpick.py` 抽压力样例的 MathML（`mfenced` 改写成 `mrow` + `mo`） |
| `harness/` | 本机自查：`support.js` 是最小运行时垫片（只实现画板用到的 `{{}}`、`sc-if`、`sc-for`、`dc-import`、事件、`setState`，不是画布真实运行时）；`shoot.mjs` 按场景截整页图；`interact.mjs` 验证引用跳转、长表展开、目录、放大层、移动目录面板 |

场景在画板 Tweaks 里切换：有全文 / 有全文无 PDF / 无全文（不在开放获取子集 · PMC 收录但不能转载 · 已撤稿）/ 有 PDF 无正文 / 压力样例 / 全文加载中 / 全文加载失败；另有「作者手稿」开关。正文为节选，画板高度上限 8000px。
