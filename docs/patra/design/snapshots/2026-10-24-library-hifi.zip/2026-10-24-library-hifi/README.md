# v0.13 文献库 · 画板快照（PAP-107）

持久画布：https://claude.ai/artifact/BoLjKpkaQhzotxdiNJdeP6　设计简报：`patra-portal/docs/design-briefs/v0.13/library.md`

| 目录 | 内容 |
|------|------|
| `project/` | 画布源文件（2026-10-24 从画布读回，版本 1792837587-7f95）：`canvas.json`（5 页 20 块画板）、6 个可交互页面各一份桌面 `X.dc.html` 与移动 `X-M.dc.html`（移动板引用桌面板并打开窄屏模式）——流程 `Flow`、收藏按钮 `Save`、详情页页头 `Detail`、文献库 `Library`、公开收藏夹页 `Collection`、用户主页 `User`；组件板 `SavePop`（收藏浮层）、`Share`（分享面板）、`Export`、`Cite`、`Nav` / `Nav-M`；静态板 `HeaderNarrow`（窄屏操作行方案 A / B）、`Dates`（出版日期精度）；`patra.css`；`ds/patra/tokens.json`（设计系统 token 副本） |
| `assets/` | 画板里以 `/_blob/<id>` 引用的素材：品牌标记（`b171f1357e0abbb8450fa69c92bae450`）、纸底叶脉（`b1045c50fe04f46b808afae69ae9d328`，404 屏） |
| `scripts/` | `gen_tokens.py` 把 `patra-portal/src/styles/tokens.css` 的 `:root` 与 `components.css` 拼成 `project/patra.css`（在仓库根运行 `python3 <scripts>/gen_tokens.py <scripts>/components.css <project>/patra.css`） |
| `harness/` | 本机自查：`support.js` 是最小运行时垫片（只实现画板用到的 `{{}}`、`sc-if`、`sc-for`、`dc-import`、事件、`setState`、受控输入，子组件按出现顺序复用实例；不是画布真实运行时）；`shoot.mjs` 用 portal 自带的 Playwright 按清单截图，在装过 portal 依赖的检出根目录运行 `node <harness>/shoot.mjs <快照目录> <shots.json> <输出目录> [offline]`（不带 `offline` 时走本机 7890 代理拉 Google Fonts） |

画板分页：流程闭环（`Flow`）／收藏入口 · 详情页（`Save`、`Detail`、`HeaderNarrow`、`Dates`）／文献库（`Library`）／公开收藏夹 · 主页（`Collection`、`User`）／组件 · 导航（`SavePop`、`Share`、`Export`、`Cite`、`Nav`）。场景在每块画板的 Tweaks 里切：「场景」一组是数据与状态开关，「服务器返回」一组模拟后端的各种响应，「版式」里的窄屏只给桌面板用。状态 ID 与简报 §4 一一对应。

`Flow` 顶部是步骤条，串起 6 块真实画板（检索结果收藏并建夹 → 详情页收进两个夹 → 文献库设公开 → 林知远在陈宇主页找到 → 复制 → 导出与复制引用）；每一步的数据按上一步的结果预置，步骤之间不传状态。

示例数据用的是真实文献（DAPA-HF、EMPEROR-Reduced、PARADIGM-HF 等），引用文本为示意，落地时以 catalog（citeproc-java）的输出为准；「长内容」场景里的超长标题与收藏夹名是压力测试用的虚构数据。

`patra.css` 下半段的组件类是画板专用的，注释写了对应的门户组件；落地时照门户现有组件与 Tailwind 写法实现，不照搬类名。
