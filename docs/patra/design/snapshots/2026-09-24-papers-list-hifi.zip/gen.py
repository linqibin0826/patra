#!/usr/bin/env python3
"""生成 Patra 文献页 hi-fi 的 7 块 .dc.html 画板 + canvas.json。"""
import json
import os
from datetime import datetime, timezone

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "project")
os.makedirs(ROOT, exist_ok=True)

# ---------- Patra tokens ----------
C = dict(
    paper50="#fbf8f2", paper100="#f7f2e8", paper200="#f1eadc", paper300="#e7e1d4", paper400="#d6cfc0",
    ink900="#1c1917", ink800="#292524", ink700="#44403c", ink600="#57534e", ink500="#78716c", ink400="#a8a29e", ink300="#c7c0b6",
    clay50="#fbf1e8", clay100="#f4e0cb", clay200="#e9c39b", clay500="#ce6a37", clay600="#b85727", clay700="#97441e", clay800="#6e3216",
    border="#ddd5c4", borderSubtle="#e7e1d4", borderStrong="#d6cfc0",
    moss="#5f7a47", moss50="#eef1e6", amber="#b8862f", amber50="#f6eeda", slate="#4a6479", slate50="#e2e8ee",
    sel="#f4d9b8", emerald="#10b981",
)
SANS = "'Inter','Noto Sans SC',ui-sans-serif,system-ui,sans-serif"
SERIF = "'Source Serif 4','Noto Serif SC',Georgia,serif"
MONO = "'JetBrains Mono',ui-monospace,Menlo,monospace"

FONT_LINK = ('<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600'
             '&family=Source+Serif+4:ital,wght@0,400;0,500;0,600;1,400&family=JetBrains+Mono:wght@400;500'
             '&family=Noto+Sans+SC:wght@400;500;600&family=Noto+Serif+SC:wght@400;500&display=swap">')


def helmet():
    return f"""<helmet>
{FONT_LINK}
<style>
body{{margin:0;background:{C['paper100']};color:{C['ink900']};font-family:{SANS};-webkit-font-smoothing:antialiased}}
a{{color:{C['clay700']};text-decoration:none}}a:hover{{color:{C['clay800']}}}
.mono{{font-family:{MONO}}}
.serif{{font-family:{SERIF}}}
.caps{{font-family:{MONO};font-size:9.5px;text-transform:uppercase;letter-spacing:0.08em}}
.kind{{display:inline-flex;align-items:center;border:1px solid {C['borderSubtle']};background:{C['paper100']};border-radius:4px;padding:2px 6px;font-family:{MONO};font-size:10.5px;text-transform:uppercase;letter-spacing:0.08em;color:{C['ink600']}}}
.ev{{display:inline-flex;align-items:center;gap:6px;border:1px solid;border-radius:6px;padding:2px 8px;font-size:11.5px;font-weight:600}}
.ev-moss{{background:{C['moss50']};color:{C['moss']};border-color:rgba(95,122,71,.3)}}
.ev-amber{{background:{C['amber50']};color:#8a6320;border-color:rgba(184,134,47,.3)}}
.ev-slate{{background:{C['slate50']};color:{C['slate']};border-color:rgba(74,100,121,.3)}}
.bars{{display:inline-flex;align-items:flex-end;gap:2px;height:11px}}
.bars i{{display:block;width:3px;border-radius:1px;background:currentColor}}
.row{{display:flex;align-items:center;gap:8px;padding:5px 4px;border-radius:4px;font-size:13px;color:{C['ink800']}}}
.row:hover{{background:{C['paper200']}}}
.row .n{{margin-left:auto;font-size:11.5px;color:{C['ink500']};font-family:{MONO}}}
.cb{{width:14px;height:14px;border:1px solid {C['ink400']};border-radius:3px;background:#fff;flex-shrink:0}}
.cb.on{{background:{C['clay500']};border-color:{C['clay500']};position:relative}}
.cb.on::after{{content:"";position:absolute;left:4px;top:1px;width:4px;height:8px;border:solid #fff;border-width:0 2px 2px 0;transform:rotate(45deg)}}
.chip{{display:inline-flex;align-items:center;gap:6px;border:1px solid {C['clay200']};background:{C['clay50']};color:{C['clay800']};border-radius:999px;padding:2px 4px 2px 10px;font-size:11.5px;font-weight:500;white-space:nowrap}}
.chip .g{{font-family:{MONO};font-size:9px;text-transform:uppercase;letter-spacing:.04em;color:{C['clay600']}}}
.chip .x{{width:16px;height:16px;border-radius:999px;display:inline-flex;align-items:center;justify-content:center;color:{C['clay600']};border:0;background:transparent;padding:0;cursor:pointer}}
mark{{background:{C['sel']};color:inherit;border-radius:2px;padding:0 1px}}
.item{{display:flex;flex-direction:column;gap:6px;padding:16px 0;border-bottom:1px solid {C['borderSubtle']}}}
.item .src{{display:flex;align-items:center;gap:10px;font-family:{MONO};font-size:10.5px;color:{C['ink600']}}}
.item .src i{{display:inline-block;width:6px;height:6px;border-radius:999px;background:{C['emerald']}}}
.item h3{{margin:0;font-family:{SERIF};font-size:17.5px;font-weight:500;line-height:1.3;letter-spacing:-0.01em;color:{C['ink900']};display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}}
.item h3 a{{color:inherit}}.item h3 a:hover{{color:{C['clay700']}}}
.item .meta{{display:flex;flex-wrap:wrap;align-items:center;gap:4px 8px;font-size:12px;color:{C['ink600']}}}
.item .meta em{{font-family:{SERIF};font-style:italic;color:{C['ink700']}}}
.item .meta em a{{color:inherit;border-bottom:1px dotted {C['ink400']}}}
.item .badges{{display:flex;flex-wrap:wrap;align-items:center;gap:6px}}
.item .abs{{margin:0;font-size:13px;line-height:1.5;color:{C['ink600']};display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}}
.btn{{display:inline-flex;align-items:center;gap:6px;border:1px solid {C['borderStrong']};background:{C['paper50']};border-radius:6px;padding:8px 14px;font-size:13px;font-weight:600;color:{C['ink900']};cursor:pointer;font-family:inherit}}
.btn:hover{{background:{C['paper200']}}}
.pg{{display:inline-flex;align-items:center;justify-content:center;width:32px;height:32px;border:1px solid {C['border']};border-radius:4px;font-size:13px;color:{C['ink800']}}}
.pg.on{{background:{C['ink900']};color:{C['paper50']};border-color:{C['ink900']}}}
.pg.off{{opacity:.4}}
.seg{{display:inline-flex;border:1px solid {C['border']};border-radius:6px;overflow:hidden}}
.seg button{{border:0;border-right:1px solid {C['borderSubtle']};background:transparent;padding:6px 12px;font-size:13px;font-weight:500;color:{C['ink600']};cursor:pointer;font-family:inherit;white-space:nowrap}}
.seg button:last-child{{border-right:0}}
.seg button.on{{background:{C['ink900']};color:{C['paper50']}}}
.tab{{border:0;background:transparent;padding:6px 10px;font-size:12.5px;font-weight:500;color:{C['ink600']};border-radius:4px;cursor:pointer;font-family:inherit;white-space:nowrap}}
.tab.on{{background:{C['ink900']};color:{C['paper50']}}}
.fgroup{{border-bottom:1px solid {C['borderSubtle']};padding:8px 0 10px}}
.fgroup:last-child{{border-bottom:0}}
.fhead{{display:flex;align-items:center;gap:4px;padding:4px 4px 6px;font-size:13px;font-weight:600;color:{C['ink900']}}}
.fhead .cnt{{margin-left:auto;width:16px;height:16px;border-radius:999px;background:{C['clay500']};color:#fff;font-size:10px;display:inline-flex;align-items:center;justify-content:center}}
.quick{{display:inline-flex;align-items:center;border:1px solid {C['border']};border-radius:999px;padding:2px 9px;font-size:11.5px;color:{C['ink700']};background:{C['paper50']}}}
.quick.on{{background:{C['clay50']};border-color:{C['clay200']};color:{C['clay800']}}}
</style>
</helmet>"""


def chev(size=14, color=C['ink600'], rot=0):
    return (f'<svg width="{size}" height="{size}" viewBox="0 0 24 24" fill="none" stroke="{color}" stroke-width="1.75" '
            f'stroke-linecap="round" stroke-linejoin="round" style="transform:rotate({rot}deg)" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>')


def icon_search(size=16, color=C['ink600']):
    return (f'<svg width="{size}" height="{size}" viewBox="0 0 24 24" fill="none" stroke="{color}" stroke-width="1.75" '
            f'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>')


def icon_x(size=12, color="currentColor"):
    return (f'<svg width="{size}" height="{size}" viewBox="0 0 24 24" fill="none" stroke="{color}" stroke-width="2" '
            f'stroke-linecap="round" aria-hidden="true"><path d="M18 6 6 18M6 6l12 12"/></svg>')


def icon_sliders(size=14, color=C['ink900']):
    return (f'<svg width="{size}" height="{size}" viewBox="0 0 24 24" fill="none" stroke="{color}" stroke-width="1.75" '
            f'stroke-linecap="round" aria-hidden="true"><path d="M21 4h-7M10 4H3M21 12h-9M8 12H3M21 20h-5M12 20H3"/>'
            f'<circle cx="12" cy="4" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="14" cy="20" r="2"/></svg>')


def icon_menu(size=20, color=C['ink900']):
    return (f'<svg width="{size}" height="{size}" viewBox="0 0 24 24" fill="none" stroke="{color}" stroke-width="1.5" '
            f'stroke-linecap="round" aria-hidden="true"><path d="M4 6h16M4 12h16M4 18h16"/></svg>')


def mark_svg(h=36):
    # 简化的 Patra 竖条标记（真实 svg 为品牌资产，这里用同色近似）
    w = max(4, round(h * 10 / 36))
    return (f'<svg width="{w}" height="{h}" viewBox="0 0 10 36" aria-hidden="true">'
            f'<rect x="0" y="0" width="10" height="36" rx="2" fill="{C["clay500"]}"/><rect x="0" y="24" width="10" height="12" rx="2" fill="#3e1c0c"/></svg>')


# ---------- 共享片段 ----------
def topnav(desktop=True):
    if desktop:
        return f"""<header style="position:sticky;top:0;z-index:40;border-bottom:1px solid {C['border']};background:rgba(247,242,232,.85);backdrop-filter:blur(8px)">
<div style="max-width:1200px;margin:0 auto;height:56px;display:grid;grid-template-columns:auto 1fr auto;align-items:center;gap:24px;padding:0 24px">
<a href="Main.dc.html" style="display:inline-flex;align-items:center;gap:8px;color:{C['ink900']}" aria-label="Patra">{mark_svg(36)}<span class="serif" style="font-size:20px;letter-spacing:-0.01em">Patra</span><span style="margin-left:4px;border:1px solid {C['clay200']};background:{C['clay50']};border-radius:4px;padding:0 6px;font-size:10px;font-weight:500;text-transform:uppercase;letter-spacing:.08em;color:{C['clay700']}">门户</span></a>
<nav aria-label="主导航" style="justify-self:center"><ul style="list-style:none;margin:0;padding:0;display:flex;align-items:center;gap:4px">
<li><a href="#" style="display:inline-flex;padding:6px 12px;font-size:13.5px;font-weight:500;color:{C['ink700']};border-radius:4px">首页</a></li>
<li><a href="Main.dc.html" aria-current="page" style="display:inline-flex;padding:6px 12px;font-size:13.5px;font-weight:500;color:{C['ink900']};border-bottom:2px solid {C['clay500']}">文献</a></li>
<li><a href="#" style="display:inline-flex;padding:6px 12px;font-size:13.5px;font-weight:500;color:{C['ink700']};border-radius:4px">期刊</a></li>
</ul></nav>
<div style="justify-self:end;display:flex;align-items:center;gap:8px">
<button type="button" aria-label="跳转到搜索框" style="display:inline-flex;align-items:center;gap:8px;border:1px solid {C['border']};background:{C['paper50']};border-radius:6px;padding:4px 10px;font-size:13px;color:{C['ink600']};font-family:inherit;cursor:pointer">{icon_search(14)}搜索<kbd class="mono" style="margin-left:4px;border:1px solid {C['borderSubtle']};background:{C['paper100']};border-radius:4px;padding:0 4px;font-size:10px;color:{C['ink600']}">⌘K</kbd></button>
<a href="#" style="padding:6px 12px;font-size:13.5px;font-weight:500;color:{C['ink700']}">关于</a>
</div></div></header>"""
    return f"""<header style="position:sticky;top:0;z-index:40;border-bottom:1px solid {C['border']};background:rgba(247,242,232,.9)">
<div style="height:56px;display:flex;align-items:center;justify-content:space-between;padding:0 16px">
<a href="Browse-Mobile.dc.html" style="display:inline-flex;align-items:center;gap:8px;color:{C['ink900']}" aria-label="Patra">{mark_svg(32)}<span class="serif" style="font-size:19px">Patra</span><span style="margin-left:2px;border:1px solid {C['clay200']};background:{C['clay50']};border-radius:4px;padding:0 5px;font-size:10px;font-weight:500;text-transform:uppercase;letter-spacing:.08em;color:{C['clay700']}">门户</span></a>
<button type="button" aria-label="打开菜单" style="width:36px;height:36px;display:inline-flex;align-items:center;justify-content:center;border:0;background:transparent;border-radius:6px;cursor:pointer">{icon_menu()}</button>
</div></header>"""


def head(desktop=True):
    h1 = "28px" if desktop else "26px"
    return f"""<div style="border-bottom:1px solid {C['border']};padding-bottom:{'24px' if desktop else '18px'}">
<nav aria-label="面包屑" style="display:flex;align-items:center;gap:6px;font-size:11.5px;color:{C['ink600']};margin-bottom:{'16px' if desktop else '12px'}"><a href="#" style="color:{C['ink600']}">Patra</a><span aria-hidden="true">/</span><span aria-current="page">文献浏览</span></nav>
<span style="display:inline-flex;align-items:center;gap:6px;font-family:{MONO};font-size:10.5px;font-weight:600;text-transform:uppercase;letter-spacing:.08em;color:{C['ink600']}">{mark_svg(14)}按文献浏览</span>
<h1 class="serif" style="margin:4px 0 0;font-size:{h1};font-weight:500;line-height:1.15;letter-spacing:-0.02em;color:{C['ink900']}">浏览全部文献</h1>
<p style="margin:8px 0 0;max-width:560px;font-size:13.5px;line-height:1.5;color:{C['ink600']}">Patra 收录的医学文献——按关键词、PMID、DOI 或作者检索，按年份 / 文献类型 / 证据等级 / 期刊收敛，点任一篇查看完整元信息与摘要。</p>
</div>"""


TABS = ["关键词", "PMID", "DOI", "作者"]


def tabs(active=0, mobile=False):
    out = []
    for i, t in enumerate(TABS):
        cls = "tab on" if i == active else "tab"
        extra = f' <span class="caps" style="font-size:9px;opacity:.7">默认</span>' if (i == 0 and active == 0) else ""
        out.append(f'<button type="button" class="{cls}" aria-pressed="{"true" if i == active else "false"}">{t}{extra}</button>')
    gap = "2px"
    style = f"display:flex;align-items:center;gap:{gap};{'overflow-x:auto;' if mobile else ''}"
    return f'<div role="tablist" aria-label="检索方式" style="{style}">{"".join(out)}</div>'


def searchbar(desktop=True, value="", active=0, placeholder="JAK1 抑制剂 · 特应性皮炎 · 1岁以下", sort="latest", has_relevance=False, filter_count=0):
    mono = active in (1, 2)
    inp_font = MONO if mono else "inherit"
    if value:
        inner = f'<input type="search" aria-label="检索文献" value="{value}" style="min-width:0;flex:1;border:0;background:transparent;padding:10px 0;font-size:15px;color:{C["ink900"]};outline:none;font-family:{inp_font}">' \
                f'<button type="button" aria-label="清除搜索" style="width:24px;height:24px;display:inline-flex;align-items:center;justify-content:center;border:0;background:transparent;border-radius:4px;color:{C["ink600"]};cursor:pointer">{icon_x(14)}</button>'
    else:
        inner = f'<input type="search" aria-label="检索文献" placeholder="{placeholder}" style="min-width:0;flex:1;border:0;background:transparent;padding:10px 0;font-size:15px;color:{C["ink900"]};outline:none;font-family:{inp_font}">'
    box = f'<div style="display:flex;min-width:0;flex:1;align-items:center;gap:10px;border:1px solid {C["borderStrong"]};background:#fff;border-radius:6px;padding:0 12px;box-shadow:inset 0 1px 0 rgba(28,25,23,.04)">{icon_search(16)}{inner}</div>'
    submit = f'<button type="submit" class="btn" style="align-self:stretch;padding:0 14px">{icon_search(14, C["clay600"])}检索</button>'
    seg = ('<div style="display:flex;align-items:center;gap:8px;flex-shrink:0"><span class="caps" style="color:' + C['ink400'] + '">排序</span>'
           '<div class="seg" role="group" aria-label="排序方式">'
           + (f'<button type="button" class="{"on" if sort == "relevance" else ""}">相关度</button>' if has_relevance else "")
           + f'<button type="button" class="{"on" if sort == "latest" else ""}">最近更新 <span class="mono" style="font-size:10px;opacity:.7">↓</span></button>'
           + f'<button type="button" class="{"on" if sort == "year" else ""}">年份</button></div></div>')
    if desktop:
        return f"""<form style="display:flex;flex-direction:column;gap:8px;border-bottom:1px solid {C['border']};padding:14px 0">
{tabs(active)}
<div style="display:flex;align-items:center;gap:14px">
<div style="display:flex;min-width:0;flex:1;align-items:center;gap:8px">{box}{submit}</div>
{seg}
</div></form>"""
    badge = (f'<span style="position:absolute;top:-6px;right:-6px;width:16px;height:16px;border-radius:999px;background:{C["clay500"]};color:#fff;font-size:10px;font-weight:600;display:inline-flex;align-items:center;justify-content:center">{filter_count}</span>'
             if filter_count else "")
    return f"""<form style="display:flex;flex-direction:column;gap:8px;border-bottom:1px solid {C['border']};padding:12px 0">
{tabs(active, mobile=True)}
<div style="display:flex;align-items:center;gap:8px">{box}{submit}</div>
<div style="display:flex;align-items:center;gap:8px;overflow-x:auto;padding-top:2px">
<div class="seg" role="group" aria-label="排序方式"><button type="button" class="{"on" if sort == "latest" else ""}">最近更新 ↓</button><button type="button" class="{"on" if sort == "year" else ""}">年份</button></div>
<button type="button" class="btn" style="margin-left:auto;position:relative;padding:6px 12px">{icon_sliders()}筛选{badge}</button>
</div></form>"""


def info_row_browse(desktop=True):
    fs = "13px"
    return f"""<div style="display:flex;flex-wrap:wrap;align-items:center;gap:6px 10px;font-size:{fs};color:{C['ink600']};padding:{'14px' if desktop else '12px'} 0 0">
<span>共 <strong class="mono" style="font-weight:500;color:{C['ink900']}">18,807</strong> 篇</span><span aria-hidden="true">·</span>
<span style="display:inline-flex;align-items:center;gap:6px"><i style="display:inline-block;width:6px;height:6px;border-radius:999px;background:{C['emerald']}"></i>来自 PubMed</span><span aria-hidden="true">·</span>
<span>最近同步 <span class="mono">2026-08-30</span></span>
</div>"""


def chips(items, desktop=True):
    lis = "".join(
        f'<li class="chip"><span class="g">{g}</span><span>{l}</span><button type="button" class="x" aria-label="移除 {l}">{icon_x(11)}</button></li>'
        for g, l in items)
    clear = f'<li><button type="button" style="border:0;background:transparent;font-size:12px;color:{C["ink600"]};text-decoration:underline;text-underline-offset:2px;cursor:pointer;font-family:inherit;white-space:nowrap">清除全部</button></li>'
    style = "list-style:none;margin:0;padding:0;display:flex;align-items:center;gap:6px;" + ("flex-wrap:wrap" if desktop else "overflow-x:auto;padding-bottom:2px")
    return f'<ul aria-label="已选筛选条件" style="{style}">{lis}{clear}</ul>'


def result_row(total, chips_items, desktop=True):
    return f"""<div style="display:flex;flex-direction:column;gap:10px;padding:{'14px' if desktop else '12px'} 0 0">
<div style="font-size:13px;color:{C['ink600']}">共 <strong class="mono" style="font-weight:500;color:{C['ink900']}">{total}</strong> 篇</div>
{chips(chips_items, desktop)}
</div>"""


# ---------- facet 栏 ----------
def quick_years(selected=None):
    return '<div style="display:flex;flex-wrap:wrap;gap:6px;padding:2px 4px 8px">' + "".join(
        f'<span class="quick{" on" if q == selected else ""}">{q}</span>' for q in ["近 1 年", "近 3 年", "近 5 年"]) + "</div>"


def rows(opts, checked=()):
    return "".join(
        f'<label class="row"><span class="cb{" on" if v in checked else ""}"></span><span>{v}</span><span class="n">{n}</span></label>'
        for v, n in opts)


def facets(mode="browse", desktop=True):
    """mode: browse / search(GLP-1 近3年 RCT)"""
    sel_year = "近 3 年" if mode == "search" else None
    years = [("2026", "17,520"), ("2025", "1,268"), ("2024", "14")] if mode == "browse" else [("2026", "612"), ("2025", "487"), ("2024", "185")]
    types_b = [("综述 · Review", "2,040"), ("快报 · Letter", "471"), ("社论 · Editorial", "349"), ("病例报告 · Case Reports", "318"), ("系统综述 · Systematic Review", "236"),
               ("观察性研究 · Observational", "166"), ("随机对照试验 · RCT", "139"), ("Meta 分析 · Meta-Analysis", "110")]
    types_s = [("随机对照试验 · RCT", "96"), ("综述 · Review", "312"), ("系统综述 · Systematic Review", "58"), ("Meta 分析 · Meta-Analysis", "41"),
               ("观察性研究 · Observational", "77"), ("病例报告 · Case Reports", "12")]
    ev_b = [("系统综述 / Meta 分析", "346"), ("随机对照试验", "139"), ("队列 / 病例对照", "421"), ("非系统综述 / 临床研究", "2,040"), ("病例报告", "318")]
    ev_s = [("系统综述 / Meta 分析", "99"), ("随机对照试验", "96"), ("队列 / 病例对照", "133"), ("非系统综述 / 临床研究", "312"), ("病例报告", "12")]
    ev_unknown = "15,543" if mode == "browse" else "632"
    langs = [("英文 · en", "18,488"), ("德文 · de", "107"), ("中文 · zh", "93"), ("法文 · fr", "52")] if mode == "browse" else [("英文 · en", "1,271"), ("中文 · zh", "9"), ("德文 · de", "4")]
    t_checked = ("随机对照试验 · RCT",) if mode == "search" else ()
    e_checked = ("随机对照试验",) if mode == "search" else ()
    year_cnt = '<span class="cnt">1</span>' if mode == "search" else ""
    type_cnt = '<span class="cnt">1</span>' if mode == "search" else ""
    width = "240px" if desktop else "100%"
    venue_sel = ""
    if mode == "search":
        venue_sel = ""
    html = f"""<aside aria-label="筛选" style="width:{width};flex-shrink:0;display:flex;flex-direction:column">
<div class="fgroup"><div class="fhead">{chev(14)}<span>发表年份</span>{year_cnt}</div>{quick_years(sel_year)}{rows(years)}</div>
<div class="fgroup"><div class="fhead">{chev(14)}<span>文献类型</span>{type_cnt}</div>{rows(types_s if mode == 'search' else types_b, t_checked)}<button type="button" style="border:0;background:transparent;padding:4px;font-size:12px;color:{C['clay700']};cursor:pointer;font-family:inherit">更多类型 ↓</button></div>
<div class="fgroup"><div class="fhead">{chev(14)}<span>证据等级</span>{type_cnt}</div>{rows(ev_s if mode == 'search' else ev_b, e_checked)}<label class="row" style="color:{C['ink500']}"><span class="cb"></span><span>未分级</span><span class="n">{ev_unknown}</span></label></div>
<div class="fgroup"><div class="fhead">{chev(14)}<span>期刊</span></div>
<div style="display:flex;align-items:center;gap:8px;border:1px solid {C['border']};background:#fff;border-radius:6px;padding:0 8px;margin:2px 4px 6px">{icon_search(12, C['ink400'])}<input type="search" aria-label="搜刊名添加" placeholder="搜刊名添加…" style="min-width:0;flex:1;border:0;background:transparent;padding:6px 0;font-size:12px;outline:none;font-family:inherit"></div>
<p style="margin:0;padding:0 4px;font-size:11px;color:{C['ink500']}">库内 2,924 本期刊，输入刊名或缩写选择</p></div>
<div class="fgroup"><div class="fhead">{chev(14)}<span>语言</span></div>{rows(langs)}</div>
<div style="padding:10px 4px 0"><button type="button" style="border:0;background:transparent;padding:0;font-size:12px;color:{C['ink600']};text-decoration:underline;text-underline-offset:2px;cursor:pointer;font-family:inherit">清除全部筛选</button></div>
</aside>"""
    return html


# ---------- 列表 ----------
def ev_badge(rank, label):
    if rank == 0:
        return ""
    tone = "moss" if rank >= 4 else ("amber" if rank >= 2 else "slate")
    bars = "".join(f'<i style="height:{4 + i * 2}px;opacity:{1 if i < rank else .3}"></i>' for i in range(5))
    return f'<span class="ev ev-{tone}"><span class="bars" aria-hidden="true">{bars}</span>{label}</span>'


def item(p, q=None):
    title = p["title"]
    if q:
        title = title.replace(q, f"<mark>{q}</mark>")
    authors = p["authors"]
    vis = ", ".join(authors[:2])
    rest = len(authors) - 2
    meta_auth = f'<span style="color:{C["ink700"]}">{vis}{f" 等 {rest} 位作者" if rest > 0 else ""}</span>' if authors else ""
    badges = f'<span class="kind">{p["kind"]}</span>' + ev_badge(p["rank"], p["ev"])
    abs_html = f'<p class="abs">{p["abs"]}</p>' if p.get("abs") else ""
    return f"""<li class="item">
<div class="src"><span style="display:inline-flex;align-items:center;gap:6px;font-weight:500"><i></i>PubMed</span><span>{p["doi"]}</span></div>
<h3><a href="#">{title}</a></h3>
<div class="meta"><span><em><a href="#">{p["journal"]}</a></em> · {p["year"]}</span><span aria-hidden="true">·</span>{meta_auth}</div>
<div class="badges">{badges}</div>
{abs_html}
</li>"""


BROWSE_ITEMS = [
    dict(title="OSBPL6 protects against demyelination and behavioral disorder via promoting cholesterol transport in oligodendrocyte.",
         journal="Journal of advanced research", year=2026, authors=["Chang Mengni", "Zhang Kaiqi", "Li Ye", "Chen Xiao", "Lan Tian", "Zhu Yan", "Wang Wenjing", "Wang Changmin", "Zhuang Xianghua", "Chen Shihong", "Yu Shuyan"],
         doi="10.1016/j.jare.2026.01.066", kind="Journal Article", rank=0, ev="未分级",
         abs="INTRODUCTION: Demyelination is associated with behavioral disorder and cognitive impairment in neuropsychiatric diseases, including major depressive disorder (MDD). Oxysterol-binding protein-like 6 (OSBPL6) is a lipid transfer protein whose role in myelination remains unclear."),
    dict(title="The risk of latent tuberculosis infection in patients with type 2 diabetes mellitus according to use of sodium-glucose cotransporter 2 inhibitors: A national database cohort study.",
         journal="International journal of infectious diseases : IJID : official publication of the International Society for Infectious Diseases", year=2026, authors=["Lee Chung-Shu", "Ho Chung-Han", "Liao Kuang-Ming", "Wu Yu-Cih", "Shu Chin-Chung"],
         doi="10.1016/j.ijid.2026.108436", kind="Journal Article", rank=3, ev="队列 / 病例对照",
         abs="In this nationwide cohort, SGLT2 inhibitor use was associated with a lower risk of latent tuberculosis infection among patients with type 2 diabetes mellitus."),
    dict(title="Early-life BPS exposure induces reproductive toxicity in offspring mice via ferroptosis.",
         journal="Reproductive toxicology (Elmsford, N.Y.)", year=2026, authors=["Su Yan", "Guo Xinxin", "Li Meng", "Wang Hao", "Zhao Lin", "Liu Qing", "Zhang Wei"],
         doi="10.1016/j.reprotox.2026.109175", kind="Journal Article", rank=0, ev="未分级",
         abs="Bisphenol S (BPS), a widely used substitute for bisphenol A, has been detected in maternal serum and breast milk, but its transgenerational effects on reproductive development remain poorly characterised."),
    dict(title="Maternal coffee consumption during pregnancy and pubertal development in children: a cohort study.",
         journal="Reproductive toxicology (Elmsford, N.Y.)", year=2026, authors=["Lyngsø Julie", "Brix Nis", "Ernst Andreas", "Ramlau-Hansen Cecilia Høst", "Bech Bodil Hammer", "Olsen Jørn"],
         doi="10.1016/j.reprotox.2026.109174", kind="Journal Article", rank=3, ev="队列 / 病例对照", abs=""),
    dict(title="Risk factors and surveillance for post discharge surgical site infections: A prospective analysis.",
         journal="International journal of infectious diseases : IJID : official publication of the International Society for Infectious Diseases", year=2026, authors=["Eren Esma Eryilmaz", "Ture Zeynep", "Kilic Aysegul Ulu"],
         doi="10.1016/j.ijid.2026.108434", kind="Journal Article", rank=3, ev="队列 / 病例对照",
         abs="Surgical site infections (SSIs) occurring after discharge are frequently missed by hospital-based surveillance. We prospectively followed patients for 30 days after clean and clean-contaminated procedures."),
    dict(title="Prevalence and clinical spectrum of <i>KRAS</i> G12C mutations in non-small-cell lung cancer: a systematic review.",
         journal="Lung cancer (Amsterdam, Netherlands)", year=2026, authors=["Ferreira Ana", "Santos Rui", "Oliveira Marta", "Costa João"],
         doi="10.1016/j.lungcan.2026.108112", kind="Systematic Review", rank=5, ev="系统综述 / Meta 分析",
         abs="BACKGROUND: KRAS G12C is the most common targetable KRAS alteration in NSCLC. We systematically reviewed prevalence estimates across ancestries and histologies."),
]

SEARCH_ITEMS = [
    dict(title="Semaglutide and Cardiovascular Outcomes in Obesity without Diabetes.",
         journal="The New England journal of medicine", year=2023, authors=["Lincoff A Michael", "Brown-Frandsen Kirstine", "Colhoun Helen M", "Deanfield John", "Emerson Scott S", "Esbjerg Sille", "Hardt-Lindberg Søren", "Hovingh G Kees", "Kahn Steven E", "Kushner Robert F", "Lingvay Ildiko", "Oral Tugce K"],
         doi="10.1056/NEJMoa2307563", kind="Randomized Controlled Trial", rank=4, ev="随机对照试验",
         abs="BACKGROUND: Semaglutide, a GLP-1 receptor agonist, has been shown to reduce the risk of adverse cardiovascular events in patients with diabetes. Whether semaglutide can reduce cardiovascular risk associated with overweight and obesity in the absence of diabetes is unknown."),
    dict(title="Tirzepatide Once Weekly for the Treatment of Obesity.",
         journal="The New England journal of medicine", year=2022, authors=["Jastreboff Ania M", "Aronne Louis J", "Ahmad Nadia N", "Wharton Sean", "Connery Lisa", "Alves Breno", "Kiyosue Arihiro", "Zhang Shuyu", "Liu Bing", "Bunck Mathijs C", "Stefanski Adam"],
         doi="10.1056/NEJMoa2206038", kind="Randomized Controlled Trial", rank=4, ev="随机对照试验",
         abs="BACKGROUND: Obesity is a chronic disease that results in substantial global morbidity and mortality. The efficacy and safety of tirzepatide, a novel glucose-dependent insulinotropic polypeptide and GLP-1 receptor agonist, in people with obesity are not known."),
    dict(title="Once-Weekly Semaglutide in Adults with Overweight or Obesity.",
         journal="The New England journal of medicine", year=2021, authors=["Wilding John P H", "Batterham Rachel L", "Calanna Salvatore", "Davies Melanie", "Van Gaal Luc F", "Lingvay Ildiko", "McGowan Barbara M", "Rosenstock Julio", "Tran Marie T D", "Wadden Thomas A", "Wharton Sean", "Yokote Koutaro", "Zeuthen Niels", "Kushner Robert F"],
         doi="10.1056/NEJMoa2032183", kind="Randomized Controlled Trial", rank=4, ev="随机对照试验",
         abs="BACKGROUND: Obesity is a global health challenge with few pharmacologic options. Whether adults with obesity can achieve weight loss with once-weekly subcutaneous semaglutide at a dose of 2.4 mg as an adjunct to lifestyle intervention has not been confirmed."),
    dict(title="Efficacy and safety of once-weekly semaglutide versus daily liraglutide in adults with overweight or obesity: a randomised, open-label, phase 3b trial.",
         journal="Lancet (London, England)", year=2024, authors=["Rubino Domenica M", "Greenway Frank L", "Khalid Usman", "O'Neil Patrick M", "Rosenstock Julio", "Sørrig Rasmus", "Wadden Thomas A", "Wizert Alicja", "Garvey W Timothy"],
         doi="10.1016/S0140-6736(24)00121-3", kind="Randomized Controlled Trial", rank=4, ev="随机对照试验",
         abs="BACKGROUND: Head-to-head data comparing GLP-1 receptor agonists at doses approved for weight management are limited. We compared once-weekly semaglutide 2.4 mg with once-daily liraglutide 3.0 mg."),
    dict(title="GLP-1 receptor agonists and risk of suicidality: a target-trial emulation in adults with obesity.",
         journal="JAMA internal medicine", year=2025, authors=["Kang Mi-Jung", "Park Sohee", "Lee Jaewon", "Kim Hyun-Soo"],
         doi="10.1001/jamainternmed.2025.0311", kind="Randomized Controlled Trial", rank=4, ev="随机对照试验", abs=""),
]


def paper_list(items, q=None, desktop=True):
    return f'<ul style="list-style:none;margin:0;padding:0;border-top:1px solid {C["borderSubtle"]};min-width:0;flex:1">' + "".join(item(p, q) for p in items) + "</ul>"


def pagination(start, end, total, cur, last, desktop=True):
    pages = [1, 2, 3, "…", last] if cur == 1 else [1, "…", cur - 1, cur, cur + 1, "…", last]
    lis = "".join(
        f'<span class="pg" style="border:0;color:{C["ink600"]}">…</span>' if p == "…" else
        f'<a href="#" class="pg{" on" if p == cur else ""}" aria-label="第 {p} 页"{" aria-current=\"page\"" if p == cur else ""}>{p}</a>'
        for p in pages)
    return f"""<div style="display:flex;flex-direction:column;align-items:center;gap:12px;padding:24px 0 0">
<p style="margin:0;font-size:13px;color:{C['ink600']}">第 {start}–{end} 篇 · 共 {total} 篇</p>
<nav aria-label="分页" style="display:flex;align-items:center;gap:4px"><a href="#" class="pg{" off" if cur == 1 else ""}" aria-label="上一页">‹</a>{lis}<a href="#" class="pg" aria-label="下一页">›</a></nav>
</div>"""


def footer(desktop=True):
    return f"""<footer style="margin-top:{'64px' if desktop else '40px'};border-top:1px solid {C['border']};background:rgba(251,248,242,.6);padding:28px 0">
<div style="max-width:1200px;margin:0 auto;padding:0 {'24px' if desktop else '16px'};display:flex;{'align-items:center;justify-content:space-between' if desktop else 'flex-direction:column;gap:12px'};font-size:12px;color:{C['ink600']}">
<a href="#" style="display:inline-flex;align-items:center;gap:8px;color:{C['ink900']}">{mark_svg(28)}<span class="serif" style="font-size:17px">Patra</span></a>
<span>医学文献数据平台 · 数据来自 PubMed 等公开来源，仅供研究与学习</span>
</div></footer>"""


def empty_block(kind, q="", desktop=True):
    if kind == "keyword":
        t = f'未找到匹配 "{q}" 的文献'
        sub = "换个关键词试试，或放宽左侧的筛选条件。"
        btns = ['清除全部筛选', '返回首页']
    elif kind == "pmid":
        t = f"未找到 PMID {q} 对应的文献"
        sub = "该编号尚未入库。可以改用关键词检索相近文献。"
        btns = ["用关键词检索", "返回首页"]
    else:
        t = "当前筛选条件下没有文献"
        sub = "放宽或清除筛选条件后重试。"
        btns = ["清除全部筛选", "返回首页"]
    b = "".join(f'<a href="#" class="btn" style="font-weight:500">{x}</a>' for x in btns)
    return f"""<div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:16px;padding:{'80px 0' if desktop else '56px 0'};text-align:center;border-top:1px solid {C['borderSubtle']}">
<h2 class="serif" style="margin:0;font-size:{'22px' if desktop else '20px'};font-weight:500;color:{C['ink900']}">{t}</h2>
<p style="margin:0;max-width:360px;font-size:13.5px;line-height:1.5;color:{C['ink600']}">{sub}</p>
<div style="display:flex;flex-wrap:wrap;justify-content:center;gap:12px">{b}</div>
</div>"""


# ---------- 画板组装 ----------
def artboard(title, w, h, body, lang="zh-CN"):
    return f"""<!doctype html>
<html lang="{lang}">
<head>
<meta charset="utf-8">
<title>{title}</title>
<script src="./support.js"></script>
</head>
<body>
<x-dc>
{helmet()}
<div style="width: {w}px; height: {h}px; box-sizing: border-box; display: flex; flex-direction: column; background: {C['paper100']}; overflow: hidden">
{body}
</div>
</x-dc>
<script type="text/x-dc" data-dc-script data-props='{{"$preview":{{"width":{w},"height":{h}}}}}'>
class Component extends DCLogic {{
renderVals() {{ return {{}}; }}
}}
</script>
</body>
</html>
"""


def desktop_page(inner):
    return topnav(True) + f'<main style="flex:1;width:100%;max-width:1200px;margin:0 auto;box-sizing:border-box;padding:32px 24px 0;display:flex;flex-direction:column">{inner}</main>' + footer(True)


def mobile_page(inner):
    return topnav(False) + f'<main style="flex:1;box-sizing:border-box;padding:20px 16px 0;display:flex;flex-direction:column">{inner}</main>' + footer(False)


# 桌面 · 浏览态
D_BROWSE = desktop_page(
    head(True)
    + f'<div style="margin-top:8px">{searchbar(True)}</div>'
    + info_row_browse(True)
    + f'<div style="display:flex;align-items:flex-start;gap:32px;margin-top:16px">{facets("browse", True)}<div style="min-width:0;flex:1;display:flex;flex-direction:column">{paper_list(BROWSE_ITEMS)}{pagination(1, 20, "18,807", 1, 941)}</div></div>'
)
# 桌面 · 检索态
D_SEARCH = desktop_page(
    head(True)
    + f'<div style="margin-top:8px">{searchbar(True, value="GLP-1", sort="latest")}</div>'
    + result_row("1,284", [("关键词", "GLP-1"), ("年份", "近 3 年"), ("类型", "随机对照试验")], True)
    + f'<div style="display:flex;align-items:flex-start;gap:32px;margin-top:16px">{facets("search", True)}<div style="min-width:0;flex:1;display:flex;flex-direction:column">{paper_list(SEARCH_ITEMS, q="GLP-1")}{pagination(1, 20, "1,284", 1, 65)}</div></div>'
)
# 桌面 · 无结果态（关键词）
D_EMPTY = desktop_page(
    head(True)
    + f'<div style="margin-top:8px">{searchbar(True, value="oxysterol demyelination oligodendrocyte 2019")}</div>'
    + result_row("0", [("关键词", "oxysterol demyelination oligodendrocyte 2019"), ("年份", "近 1 年")], True)
    + f'<div style="display:flex;align-items:flex-start;gap:32px;margin-top:16px">{facets("browse", True)}{empty_block("keyword", "oxysterol demyelination oligodendrocyte 2019", True)}</div>'
)

# 移动 · 浏览态
M_BROWSE = mobile_page(
    head(False)
    + f'<div style="margin-top:4px">{searchbar(False)}</div>'
    + info_row_browse(False)
    + f'<div style="margin-top:12px">{paper_list(BROWSE_ITEMS[:4])}{pagination(1, 20, "18,807", 1, 941, False)}</div>'
)
# 移动 · 检索态
M_SEARCH = mobile_page(
    head(False)
    + f'<div style="margin-top:4px">{searchbar(False, value="GLP-1", filter_count=2)}</div>'
    + result_row("1,284", [("关键词", "GLP-1"), ("年份", "近 3 年"), ("类型", "随机对照试验")], False)
    + f'<div style="margin-top:12px">{paper_list(SEARCH_ITEMS[:4], q="GLP-1")}{pagination(1, 20, "1,284", 1, 65, False)}</div>'
)
# 移动 · 无结果态（PMID 未命中）
M_EMPTY = mobile_page(
    head(False)
    + f'<div style="margin-top:4px">{searchbar(False, value="38491203", active=1)}</div>'
    + result_row("0", [("PMID", "38491203")], False)
    + f'<div style="margin-top:12px;display:flex">{empty_block("pmid", "38491203", False)}</div>'
)
# 移动 · 筛选抽屉（检索态之上）
M_FILTERS = (
    topnav(False)
    + f'<div style="position:relative;flex:1;overflow:hidden">'
    + f'<div style="position:absolute;inset:0;padding:20px 16px 0;opacity:.35;filter:blur(1px)">{head(False)}<div style="margin-top:4px">{searchbar(False, value="GLP-1", filter_count=2)}</div></div>'
    + f'<div style="position:absolute;inset:0;background:rgba(28,25,23,.35)"></div>'
    + f'<section role="dialog" aria-label="筛选" style="position:absolute;left:0;right:0;bottom:0;top:72px;background:{C["paper100"]};border-radius:14px 14px 0 0;box-shadow:0 -12px 32px -8px rgba(28,25,23,.25);display:flex;flex-direction:column">'
    + f'<div style="display:flex;align-items:center;justify-content:space-between;padding:14px 16px;border-bottom:1px solid {C["border"]}"><span class="serif" style="font-size:18px;font-weight:500">筛选</span><span style="font-size:12px;color:{C["ink600"]}">已选 2 项</span><button type="button" aria-label="关闭" style="width:32px;height:32px;border:0;background:transparent;border-radius:6px;display:inline-flex;align-items:center;justify-content:center;cursor:pointer">{icon_x(16, C["ink900"])}</button></div>'
    + f'<div style="flex:1;overflow-y:auto;padding:4px 16px">{facets("search", False)}</div>'
    + f'<div style="display:flex;gap:10px;padding:12px 16px;border-top:1px solid {C["border"]};background:{C["paper50"]}"><button type="button" class="btn" style="flex:1;justify-content:center;font-weight:500">清除全部</button><button type="button" class="btn" style="flex:1;justify-content:center;background:{C["ink900"]};color:{C["paper50"]};border-color:{C["ink900"]}">查看 96 篇结果</button></div>'
    + '</section></div>'
)

BOARDS = [
    ("Main.dc.html", "文献页 · 浏览态（桌面）", 1440, 1420, D_BROWSE, 0, 0),
    ("Search-Desktop.dc.html", "文献页 · 检索态（桌面）", 1440, 1420, D_SEARCH, 1520, 0),
    ("Empty-Desktop.dc.html", "文献页 · 无结果态（桌面）", 1440, 1180, D_EMPTY, 3040, 0),
    ("Browse-Mobile.dc.html", "文献页 · 浏览态（移动）", 390, 1560, M_BROWSE, 0, 1840),
    ("Search-Mobile.dc.html", "文献页 · 检索态（移动）", 390, 1600, M_SEARCH, 470, 1840),
    ("Empty-Mobile.dc.html", "文献页 · 无结果态（移动，PMID 未命中）", 390, 1000, M_EMPTY, 940, 1840),
    ("Filters-Mobile.dc.html", "文献页 · 筛选抽屉（移动）", 390, 844, M_FILTERS, 1410, 1840),
]

boards = {}
order = []
for name, title, w, h, body, x, y in BOARDS:
    with open(os.path.join(ROOT, name), "w", encoding="utf-8") as f:
        f.write(artboard(title, w, h, body))
    boards[name] = {"x": x, "y": y, "w": w, "h": h, "title": title}
    order.append(name)

now = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
canvas = {
    "v": 3,
    "createdOnFiles": {"v": 1, "at": now},
    "title": "Patra 文献页 hi-fi",
    "launch": {"view": "canvas"},
    "pages": [],
    "boards": boards,
    "order": order,
    "notes": {
        "t-desktop": {"x": 0, "y": -300, "text": "桌面 1440 · 浏览态 → 检索态 → 无结果态", "kind": "title1", "maxW": 4480},
        "t-mobile": {"x": 0, "y": 1540, "text": "移动 390 · 浏览态 → 检索态 → 无结果态 → 筛选抽屉", "kind": "title1", "maxW": 1800},
        "n-data": {"x": 1880, "y": 1540, "w": 420, "text": "数据现状（mini 库 18,807 篇）：被引全 0 → 卡片不显被引；OA 全 false → OA facet 整组不渲染；2,924 本期刊 → 期刊 facet 为搜索添加；约 84% 未分级 → 「未分级」放末尾弱化。", "fill": "orange", "size": "s"},
    },
    "designSystems": [],
}
with open(os.path.join(ROOT, "canvas.json"), "w", encoding="utf-8") as f:
    json.dump(canvas, f, ensure_ascii=False, indent=1)
print("ok", len(order), "boards")
