# v0.19 第三方登录 · 画板快照（PAP-185）

持久画布：https://claude.ai/artifact/FC4XR8s8AVQjtJz92C8E7F　设计简报：`patra-portal/docs/design-briefs/v0.19/social-login.md`（简报页 https://claude.ai/artifact/JiULR3HNSh1segHDpZZD3g 由它生成）

| 目录 | 内容 |
|------|------|
| `project/` | 画布源文件（2026-11-04 用户定稿后从画布读回，版本 1793784542-e131）：`canvas.json`（4 页 9 块）；登录与注册 `Auth`、首次登录 `Complete`（补填、验证码、过期、并发）、设置 · 安全 `Security`（登录方式卡片、解绑确认、两种再认证），各有手机薄包装板 `X-M`；静态对比 `Entries`（入口位置，定稿 A）、`Providers`（按钮样式，定稿 1）；沿用 v0.18 的 `Nav`；`patra.css`；`ds/patra/tokens.json` |
| `assets/` | 画板里以 `/_blob/<id>` 引用的素材，见下表 |
| `scripts/` | `gen_tokens.py` 把 `patra-portal/src/styles/tokens.css` 的 `:root` 与组件类拼成 `project/patra.css`（组件类参数依次是 `components.css` 和 v014、v015、v016、v018、v019 六个文件）；`components-v019.css` 是本版新增的类；`gen_mobile.py` 生成手机板（`python3 gen_mobile.py <project> Auth Complete Security`）；`brief-page.template.html` + `build_brief_page.py` 生成简报页 |
| `harness/` | 本机自查：`support.js` 最小运行时垫片（不是画布真实运行时）；`shoot.mjs` 按清单截图（`PORTAL_PKG=<装过依赖的 patra-portal/package.json> node <harness>/shoot.mjs <快照目录> <shots.json> <输出目录> [offline]`），素材表已加本版 id；`debug.mjs` 打印页面报错堆栈 |

## 素材

| 画布 id | 文件 | 来源 |
|------|------|------|
| `58a2bdad891faa8c804400d090fea0cb` | `patra-mark.svg` | 品牌标记，从 v0.18 画布复制 |
| `cadb4bde74bc5e93b91641efbfdc5b6b` | `venation-inverse.svg` | 墨底叶脉，从 v0.18 画布复制 |
| `0ad5c50c7247ae97b698c271d1882022` | `google-g.png` | Google [`signin-assets.zip`](https://developers.google.com/static/identity/images/signin-assets.zip) 的 `Android + Web/PNG @4x/Light/Theme=Light, Show text=No, Shape=Pill` 中央 80×80 裁切 |
| `ae10fd7666b838765f6f34e9fbe7c37e` | `github-mark.svg` | GitHub [`GitHub_Logos.zip`](https://brand.github.com/GitHub_Logos.zip) 的 `GitHub_Invertocat_Black.svg` |
| `55720addab5e92efef65eb5436eac63f` | `orcid-id.svg` | ORCID [iD 图标](https://orcid.org/assets/vectors/orcid.logo.icon.svg) |

G 用 PNG 裁切，是因为官方 SVG 含 `foreignObject`，画布上传时会被剥掉。**门户落地时直接用官方 SVG。**

## 怎么看

场景在每块画板的 Tweaks 里切：「场景」是数据与身份（`host` 一项分显示入口和不显示），「服务器返回」模拟接口结果。状态 ID 与简报 §4 一一对应。示例人物是陈宇（`chen-yu`，GitHub `chenyu-med`）；邮箱用保留域名 `example.com`；ORCID iD `0000-0004-2817-6307` 是编的示例号，只保证校验位合法。

`patra.css` 下半段的组件类是画板专用的，落地时照门户现有组件与 Tailwind 写法实现，不照搬类名。

## 定稿（2026-11-04，用户「都按推荐定稿」）

入口按配置显示（线上公网和本机显示，tailnet 不显示）；入口放表单上面；按钮用门户 token，官方标识不改；ORCID 显示裸 iD 并链到记录页；卡片加「邮箱和密码」一行；没有密码时在弹框里直接发设置邮件；旧文案改成「重新登录」，门户部分归 PAP-187，邮件部分归后端。

自查范围：本机垫片渲染和 Playwright 截图。画板没有在真实画布运行时里逐项点过。
