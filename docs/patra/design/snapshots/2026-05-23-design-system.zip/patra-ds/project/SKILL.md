---
name: patra-design
description: Use this skill to generate well-branded interfaces and assets for Patra, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, and assets.
user-invocable: true
---

# Patra Design Skill

Read the `README.md` file in this skill, and explore the other available files:

- `README.md` — full visual language, content rules, iconography, type substitutions
- `colors_and_type.css` — drop-in CSS variables for color, type, spacing, radii, shadows, motion
- `assets/` — the patra mark and lockup variants
- `preview/` — small specimen cards visualizing each foundation

If creating visual artifacts (slides, mocks, throwaway prototypes, etc.), copy the
assets out and create static HTML files for the user to view. Reference
`colors_and_type.css` directly — every token is a single CSS custom property, no
build step required.

If working on production code, the system is written so the tokens drop straight
into Tailwind v4's `@theme` block. shadcn/ui components should pick up `--clay-*`,
`--paper-*`, `--ink-*`, and `--font-*` without further configuration.

If the user invokes this skill without any other guidance, ask them what they
want to build or design, ask a handful of focused questions (audience, surface,
density, length), and act as an expert designer who outputs HTML artifacts _or_
production code depending on the need.

## Core rules to honor

- **Warm, paper-like, editorial.** Cream paper backgrounds, near-black ink, one
  warm clay accent (`#CE6A37`). Never SaaS-blue, never dashboard-rainbow, never
  marketing gradients.
- **Sans for working, serif for reading, mono for facts.** Inter for chrome,
  Source Serif 4 for abstracts and display, JetBrains Mono for DOIs and code.
- **Hairline borders, restrained shadows, subtle radii (4–8px).**
- **No emoji** in product UI. Lucide icons at 1.5px stroke. Status chips use a
  6px filled dot, never an emoji.
- **Sentence case** for everything — headings, buttons, labels. Acronyms stay
  caps (DOI, PMID, NLM).
- **Quiet, precise voice.** No exclamation marks. No marketing prose. Direct
  imperative for actions. Errors state _what_ and _what to do_.
- **Dense by default.** This is a workbench for daily use. Reading surfaces
  (article view, empty states) get generous whitespace; chrome stays tight.
