# Patra Design System

A warm, paper-like, editorially-minded design language for **Patra** —
an internal medical-publication data platform. Built for researchers,
medical professionals, and data engineers who live inside the Portal
all day.

> _Patra_ (पत्र) — Sanskrit for **leaf, page, document.**

---

## What Patra is

Patra ingests, parses, and stores scholarly literature from 10+
external sources (PubMed, Europe PMC, Crossref, and more). The
**Portal** is an internal admin & research workbench where users:

- Browse harvested publications and abstracts
- Configure ingestion plans and source connectors
- Inspect parser provenance and field-level lineage
- Monitor pipelines, queues, and worker health
- Curate, dedupe, and annotate records

The product is **internal/admin grade software**. There is no
marketing surface, no public-facing landing page, no testimonials, no
glossy hero. Everything is designed for repeated daily use by domain
experts.

### Sources & materials received

| Source | What it was | Status |
|---|---|---|
| `uploads/patra-mark.svg` | Brand mark — two stacked etched leaves on clay panel | Copied to `assets/patra-mark.svg` |
| _Codebase_ | _Not yet provided_ | — |
| _Figma_ | _Not yet provided_ | — |

No prior design system, codebase, or Figma was attached. This system
is a **greenfield definition** anchored on the mark and the visual
direction in the brief. Once a codebase or Figma is attached, this
system should be reconciled against it.

---

## Index

```
README.md                  — this file
SKILL.md                   — agent-skill manifest (cross-compatible with Claude Code)
colors_and_type.css        — tokens (CSS variables) for color, type, space, motion

assets/
  patra-mark.svg           — the canonical two-leaf mark (original upload)
  patra-wordmark.svg       — horizontal lockup: mark + "patra" wordmark
  patra-monogram.svg       — single-leaf monogram variant

preview/                   — small specimen cards (rendered in the Design System tab)
  brand-mark, brand-lockups, brand-applications, brand-iconography
  color-clay, color-neutrals, color-semantic
  type-display, type-ui-scale, type-reading, type-mono
  space-radii, space-scale, space-elevation, space-focus-ring
  comp-buttons, comp-inputs, comp-table, comp-menu-palette,
  comp-cards, comp-chips-badges
```

---

## CONTENT FUNDAMENTALS

**Voice:** _quiet, precise, useful._ Patra speaks like a senior
librarian who also knows the engineering. Confident but never
performative. No exclamation marks, no marketing prose, no “amazing.”

**Tone reference points**

- Linear changelogs (terse, technical, dignified)
- Stripe error messages (specific, actionable, no apology theatre)
- A reference manual — not a chatbot, not a marketing site

**Person & address**

- Prefer **direct imperative** in UI: _"Choose a source"_, _"Set
  schedule"_, _"Inspect provenance"_.
- _You_ is used sparingly, only when the action is clearly user-owned
  (_"Your saved queries"_). Avoid _we_ entirely in product UI —
  Patra is a tool, not a personality.
- Empty states address the user directly and briefly:
  _"Nothing harvested yet. Connect a source to begin."_

**Casing**

- **Sentence case everywhere** — headings, buttons, menu items, table
  columns. Never Title Case Like This.
- Acronyms stay caps: **DOI**, **PMID**, **NLM**, **API**, **HTTP**.
- Proper names of sources keep their canonical casing: _PubMed_,
  _Europe PMC_, _Crossref_, _OpenAlex_.

**Numbers, units, identifiers**

- DOIs, PMIDs, ORCIDs, ISSNs, hashes, timestamps → **monospace**.
- Use ISO 8601 dates in tables (`2026-05-23`), human-readable in
  prose (_May 23, 2026_).
- Use SI separators: `12,431 records`, not `12431 records`.
- Relative time on recent items only (_3 min ago_), absolute beyond
  24h with hover-for-exact.

**Examples**

| Don't | Do |
|---|---|
| "Awesome! 🎉 Your ingestion was successful!" | "Ingested 1,204 records from PubMed in 2m 14s." |
| "Oops — something went wrong." | "Crossref returned 429. Retrying in 30s." |
| "Add a New Source" (button) | "Add source" |
| "Welcome back, friend!" | "Welcome back." |
| "Run AMAZING analytics" | "Run analytics" |

**Emoji & decorative glyphs**

- **No emoji in product UI.** Ever.
- Unicode glyphs may appear functionally: `↗` for external link,
  `·` as a separator, `→` for flow, `—` for em-dashes in prose.
- Status uses small bordered chips with a 6px dot, never emoji.

**Microcopy length**

- Buttons: 1–3 words.
- Empty state primary line: ≤ 8 words.
- Tooltip: one short sentence, no period.
- Error: one sentence stating _what_ + one sentence stating _what to
  do_.

---

## VISUAL FOUNDATIONS

### Palette

A short, opinionated palette. **One** warm accent (clay), warm-shifted
neutrals, muted semantic colors. Explicitly **not** SaaS-blue,
**not** dashboard-rainbow, **not** marketing-gradient.

- **Cream paper** `#FBF8F2` / `#F7F2E8` — backgrounds. Slightly warm
  ("uncoated paper"). Pure `#FFF` is reserved for elevated dialogs
  and popovers.
- **Ink** `#1C1917` — primary text and the line-art mark. Always warm
  ("near-black" with a brown bias), never `#000`.
- **Clay** `#CE6A37` — derived from the leaf-panel of the patra
  mark. The single warm accent: primary buttons, focus rings, brand
  illustration backgrounds, key data emphasis.
- **Muted semantics:** moss `#5F7A47`, amber `#B8862F`, rust
  `#B23A2E`, slate `#4A6479`. Always lower-saturation than typical
  SaaS palettes.

See [`colors_and_type.css`](./colors_and_type.css) for the full token
set.

### Typography

| Role | Family | Use |
|---|---|---|
| **UI sans** | Inter | All chrome — nav, tables, forms, toolbars, buttons |
| **Reading serif** | Source Serif 4 | Abstracts, full text, long-form prose, display headings |
| **Mono** | JetBrains Mono | DOIs, PMIDs, identifiers, code, timestamps |

- **Sans for working**, **serif for reading**, **mono for facts**.
- Display headings (H1/H2) are serif at 28–48px, weight 500, tight
  leading. Inline UI headings (H3/H4) stay sans, weight 600.
- Body UI is dense: `13.5px` baseline. Reading surfaces step up to
  `16px` serif with 1.65 leading.
- Tabular numerals on every column of numbers
  (`font-variant-numeric: tabular-nums`).
- Eyebrows are 10.5px caps, tracked +8%.

### Density & spacing

- 4px grid.
- Table row height: **32–36px** (dense), **40–44px** (comfortable),
  toggleable.
- Side rails are **220–260px**; main content gutters are 24–32px,
  never more on dense surfaces.
- Reading surfaces (article view) get **64–88px** of horizontal
  whitespace and a `~640px` measure.
- Empty states are generous: 96px+ of vertical breathing room with a
  small mark centered.

### Shape language

- **Subtle radii** — 4px (chips, inputs, small buttons), 6px (default
  buttons, menu items), 8px (cards, dialogs). Never larger except
  pill toggles.
- **Hairline borders** (`1px solid var(--border-default)`) are the
  primary separator. They sit on a warm `#DDD5C4`-ish color so they
  read as paper edges, not UI lines.
- Cards are flat: paper background, 1px border, 8px radius, **no
  drop shadow** by default. Elevation is reserved for popovers and
  modals (`--shadow-md` / `--shadow-lg`).

### Backgrounds & imagery

- **No gradients in chrome.** No marketing gradients ever. The only
  "gradient" allowed is a very subtle paper-grain texture on hero
  surfaces and login screens — pure two-stop linear at <4% delta.
- No full-bleed photography in the product. Reading surfaces stay
  paper-on-paper.
- The **botanical mark** is the only illustrative element; it appears
  small (24–48px) in nav, larger (120–240px) on empty states and
  login.
- If imagery is needed for documents/abstracts, render publication
  thumbnails as muted **B&W or duotone** (ink + clay), never full
  color.

### Borders, shadows, elevation

| Level | Use | Treatment |
|---|---|---|
| 0 — flush | Tables, list rows | hairline below only |
| 1 — paper | Cards, panels | `--bg-paper` + 1px border, no shadow |
| 2 — raised | Toolbars, sticky headers | `--bg-elevated` + 1px border + `--shadow-xs` |
| 3 — float | Popovers, menus | `--bg-elevated` + `--shadow-md` |
| 4 — modal | Dialogs | `--bg-elevated` + `--shadow-lg`, scrim `rgba(28,25,23,0.32)` |

No inner shadows except for **inset wells** (search bars, code
blocks): `inset 0 1px 0 0 rgba(28,25,23,0.04)`.

### Interaction states

- **Hover** — neutral backgrounds shift to `--paper-200` (≈4% darker);
  accent surfaces shift to `--clay-600`. Text-only buttons get a
  paper tint, never an underline-toggle.
- **Press** — small inset shift (`transform: translateY(0.5px)`) on
  buttons; accent surfaces go to `--clay-700`. No scale shrink — we
  are not a touch app.
- **Focus** — **3px clay focus ring at 28% opacity** on all
  interactive elements: `box-shadow: 0 0 0 3px rgba(206,106,55,.28)`.
  Visible for keyboard users (`:focus-visible`).
- **Selected** — paper-tinted row with a 2px clay rule on the left
  edge (not a border-color change). In menus, selected items use
  `--accent-tint` background + ink text.
- **Disabled** — 50% opacity, no events. Never gray-out the cursor;
  let the platform default handle it.

### Animation

- **Sparse, fast, never bouncy.** Patra is a tool. Animations are
  there to clarify state changes, never to delight.
- Durations: `120ms` (micro: hover, focus), `180ms` (default:
  popover, accordion), `280ms` (modal, page transition).
- Easing: `cubic-bezier(0.2, 0.6, 0.2, 1)` (standard).
- **No bounces, no springs, no spinning illustrations.** A pipeline
  status pulse is a `1.6s` opacity oscillation between 0.5 → 1.0,
  ease-in-out.
- Page transitions are crossfades only.

### Transparency & blur

- Backdrop blur is reserved for the **command palette scrim**
  (`backdrop-filter: blur(8px)` over `rgba(28,25,23,0.32)`).
- Translucent overlays do not appear in normal navigation chrome.
- Solid surfaces preferred over translucent ones — paper feel.

### Layout rules

- **Sidebar nav is fixed**, 240px wide, on the left. Collapses to
  56px (icon-only) at < 1280px viewport.
- **Top bar is fixed**, 48px tall, contains: workspace switcher (L),
  global command-K (C), user menu (R).
- Detail panes (right rail) are 360–420px and **non-fixed** — they
  scroll with content.
- Tables fill remaining width; column widths are user-resizable and
  persisted.

### Imagery tone

When imagery is unavoidable (e.g., publication figure thumbnails,
PDF previews):

- Render at **80% saturation** maximum, lifted blacks (no `#000`).
- Apply a 1px hairline border in `--border-default`.
- Avoid stock photography entirely.
- Botanical / leaf / paper textures _may_ appear at very low
  opacity (<8%) on empty states and login.

### Cards

| Variant | Border | Background | Shadow | Radius |
|---|---|---|---|---|
| List item (row) | bottom only, hairline | transparent → `--paper-200` on hover | none | 0 |
| Panel card | 1px `--border-default` | `--bg-paper` | none | 8px |
| Stat tile | 1px `--border-default` | `--bg-paper` | none | 6px |
| Popover | 1px `--border-default` | `--bg-elevated` | `--shadow-md` | 8px |
| Modal | 1px `--border-default` | `--bg-elevated` | `--shadow-lg` | 12px |

---

## ICONOGRAPHY

**System:** [Lucide](https://lucide.dev) at **1.5px stroke**,
**18–20px** default size in UI chrome, **14px** inside dense table
rows. Lucide pairs cleanly with Inter — geometric, restrained, no
filled variants.

- We load Lucide from CDN
  (`https://unpkg.com/lucide@latest`) and render via
  `lucide.createIcons()` or per-icon inline SVG. No icon font.
- **Stroke color** is the surrounding `currentColor`. Icons never
  carry their own fill or accent color, with one exception: the
  **patra leaf monogram** which uses `--clay-500` over `--ink-900`.
- Fill variants are reserved for status chips (the 6px filled dot)
  and the brand mark itself.
- **No emoji** in product UI.
- A small number of **Unicode glyphs** are used functionally:
  - `↗` external link
  - `→` flow / next
  - `·` mid-dot separator
  - `—` em-dash
  - `…` ellipsis (single glyph, never three periods)

**Substitution note:** the user has not provided an in-house icon
set. Lucide is the substitute and should be replaced if Patra later
adopts a custom set.

**Logos & marks shipped in this system**

- `assets/patra-mark.svg` — full mark, two-leaf vertical panel
  (source upload)
- `assets/patra-monogram.svg` — single-leaf monogram extracted from
  the mark; used in nav, favicon, login
- `assets/patra-wordmark.svg` — horizontal lockup: monogram +
  "patra" wordmark in Source Serif 4

---

## TYPE SUBSTITUTIONS

The user has not supplied self-hosted font files. The system imports
the following from Google Fonts as substitutes:

| Slot | Used | If replacing | Drop into |
|---|---|---|---|
| UI sans | **Inter** (Google Fonts via rsms.me) | Geist Sans, GT Walsheim | `fonts/inter/*` |
| Reading serif | **Source Serif 4** (Google Fonts) | Lora, IBM Plex Serif | `fonts/source-serif-4/*` |
| Mono | **JetBrains Mono** (Google Fonts) | iA Writer Mono, Berkeley Mono | `fonts/jetbrains-mono/*` |

**→ Please supply self-hosted font files if licensing requires** —
hosting from a CDN is fine for prototypes but should be brought
in-house before production.

---

## TARGET STACK

The Portal codebase is expected to use:

- **Next.js 15** (App Router)
- **React 19**
- **TypeScript** (strict)
- **Tailwind v4** (CSS variables / `@theme`)
- **shadcn/ui** as the component foundation

The tokens in `colors_and_type.css` are written so they can be
dropped directly into a Tailwind v4 `@theme` block — every primitive
is a single CSS custom property, no SCSS, no JS preprocessing.
