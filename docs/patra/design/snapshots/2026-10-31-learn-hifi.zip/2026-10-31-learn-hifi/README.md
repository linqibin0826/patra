# v0.17 学习站 · 画板快照（PAP-156）

持久画布：https://claude.ai/artifact/U2Fkw5KgjBuUHYBMGvi9fi　设计简报：`patra-learn/docs/design-briefs/v0.17/learn-site.md`（简报页 https://claude.ai/artifact/VX9u29hTxPvNg8Nef9Mr7y 由它生成）

| 目录 | 内容 |
|------|------|
| `project/` | 画布源文件（2026-10-31 拍板后，画布第 6 版）：`canvas.json`（4 页 21 块）；页面 `Main` `Route` `Theme` `Tag` `Search`；条目 `Concept` `Debug` `Decision` `Pitfall`；组件 `C-Diagnose` `C-Quiz` `C-Transfer` `C-Mastery` `C-Structure` `C-Sequence` `C-StateMachine` `C-Stepper` `C-Params` `C-Compare`；`Nav`、`Tokens`；`learn.css`（上半段是学习站 token，下半段是画板类名） |
| `harness/` | 本机自查：`support.js` 最小运行时垫片（同 v0.16）；`shoot.mjs` 用 portal 的 Playwright 截图，`size` 多了 `page`（1280 宽）与 `comp`（680 宽）：`PORTAL_PKG=<装过依赖的 patra-portal/package.json> node <harness>/shoot.mjs <快照目录> <shots.json> <输出目录> [offline]`；`brief-shot.mjs` 截简报页 |
| `scripts/` | `brief-page.v017.template.html`（学习站配色）+ `build_brief_page.py` 生成简报 Artifact 页 |

场景在每块画板的 Tweaks 里切，组件画板的「状态」与简报第 6 节一一对应。子组件的 `<helmet>` 里只放字体，组件样式全部在 `learn.css`（子组件 helmet 里的样式在被嵌入时不生效）。没有素材文件，图标全是行内 SVG。
