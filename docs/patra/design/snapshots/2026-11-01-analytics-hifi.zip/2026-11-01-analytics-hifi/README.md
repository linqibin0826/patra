# v0.18 行为数据 · 画板快照（PAP-166）

持久画布：https://claude.ai/artifact/CCNaRB5JeLgNCVU544NNFi　设计简报：`patra-portal/docs/design-briefs/v0.18/analytics.md`（简报页 https://claude.ai/artifact/2MFopuqyppth6pRmtNkcq8 由它生成）

| 目录 | 内容 |
|------|------|
| `project/` | 画布源文件（2026-11-01 用户拍板后定稿，与画布版本 1793523634-8574 一致）：`canvas.json`（6 页 9 块）；四处文献卡片 `Cards`（「N 人看过」、检索结果的「近期热读」，行为数据与互动两个服务各自降级）；文献页 `Paper`（事实条下方读者一行、页底「看过这篇的人还看了」/「同主题文献」五种组合）；首页文献流 `Feed`（第三个标签「热读」、「最新收录」补位三种场景）；阅读历史 `History`（按天分组、单条删除与失败恢复、清空确认、记录已关闭、三种空状态）；设置 › 隐私 `Privacy`（第四张卡片「阅读记录」）；隐私政策 `Policy`（九节 + 页脚入口）；静态对比 `Facts`（读者计数放哪，定稿 B）、`HotMark`（近期热读放哪，定稿 A）；沿用 v0.14 的 `Nav`（菜单加「阅读历史」）；`patra.css`；`ds/patra/tokens.json`。全部是桌面板，没有手机板（spec：手机只保证可读、不溢出） |
| `assets/` | 画板里以 `/_blob/<id>` 引用的素材：品牌标记（`79bc973e9bbefd1eeb061ae83991241a`）、墨底叶脉（`ed8fc9b3ecda4231e59f21d4916a4871`），均从 v0.16 画布复制 |
| `scripts/` | `gen_tokens.py` 把 `patra-portal/src/styles/tokens.css` 的 `:root` 与组件类拼成 `project/patra.css`（`python3 <scripts>/gen_tokens.py <scripts>/components.css,<scripts>/components-v014.css,<scripts>/components-v015.css,<scripts>/components-v016.css,<scripts>/components-v018.css <project>/patra.css <tokens.css>`）；`components-v018.css` 是本版新增的类；`brief-page.template.html` + `build_brief_page.py` 生成简报 Artifact 页；`gen_mobile.py` 本版没用（沿用旧版留着） |
| `harness/` | 本机自查：`support.js` 最小运行时垫片；`shoot.mjs` 用 portal 自带的 Playwright 按清单截图（`PORTAL_PKG=<装过依赖的 patra-portal/package.json> node <harness>/shoot.mjs <快照目录> <shots.json> <输出目录> [offline]`），素材表已加本版两个 id；`debug.mjs` 打印页面报错的堆栈 |

场景在每块画板的 Tweaks 里切：「场景」是数据与身份，「服务器返回」模拟接口结果，「版式」是对比用的未采用方案。状态 ID 与简报 §4 一一对应。示例人物沿用 B = 王立、C = 林知远，阅读历史是林知远的；「现在」是 11 月 1 日 16:00。文献标题、期刊、年份、第一作者是真实文献，看过数等计数是虚构的示意值。

`patra.css` 下半段的组件类是画板专用的，落地时照门户现有组件与 Tailwind 写法实现，不照搬类名。2026-11-01 用户拍板：8 个问题全部按推荐（简报 §10）；`Facts`、`HotMark` 里标「定稿」的是采用的方案，其余只作对比；计数口径定为按人长期去重。隐私政策的联系邮箱等仍是占位。
