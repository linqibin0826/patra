// =============================================================
// App — composes sections + wires Tweaks.
//
// Tweaks exposed:
//   • searchAccent   teal | clay | ink         (hero submit button)
//   • aiStyle        callout | margin | hidden (AI 速读 visual)
//   • density        comfortable | compact     (paper cards)
//   • cloudSort      heat | az                 (topic cloud)
//   • journalCover   classic | paper           (journal "covers")
//   • showOrnament   bool                      (hero right-side leaf)
// =============================================================

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "searchAccent": "teal",
  "aiStyle": "callout",
  "density": "comfortable",
  "cloudSort": "heat",
  "journalCover": "classic",
  "showOrnament": true
}/*EDITMODE-END*/;

// Context so deep children can read tweaks without prop-drilling.
const TweakCtx = React.createContext(TWEAK_DEFAULTS);
window.useTweakCtx = () => React.useContext(TweakCtx);

// Apply tweak side-effects via inline CSS variables on <html>.
function applyTweakStyles(t) {
  const root = document.documentElement;

  // search accent on hero submit
  const accent = {
    teal: { bg: "var(--teal-600)",  bgh: "var(--teal-700)", bgp: "var(--teal-800)", brd: "var(--teal-700)" },
    clay: { bg: "var(--clay-500)",  bgh: "var(--clay-600)", bgp: "var(--clay-700)", brd: "var(--clay-600)" },
    ink:  { bg: "var(--ink-900)",   bgh: "var(--ink-800)",  bgp: "var(--ink-700)",  brd: "var(--ink-900)"  },
  }[t.searchAccent] || {};
  root.style.setProperty("--tw-submit-bg",       accent.bg  || "");
  root.style.setProperty("--tw-submit-bg-hover", accent.bgh || "");
  root.style.setProperty("--tw-submit-bg-press", accent.bgp || "");
  root.style.setProperty("--tw-submit-brd",      accent.brd || "");

  // density
  const dense = t.density === "compact";
  root.style.setProperty("--tw-card-pad", dense ? "14px 16px 12px" : "20px 22px 18px");
  root.style.setProperty("--tw-card-gap", dense ? "8px" : "12px");
  root.style.setProperty("--tw-section-pad-block", dense ? "48px" : "72px");

  document.body.dataset.aiStyle    = t.aiStyle;
  document.body.dataset.density    = t.density;
  document.body.dataset.cloudSort  = t.cloudSort;
  document.body.dataset.journalCover = t.journalCover;
  document.body.dataset.showOrnament = String(t.showOrnament);
}

// One-time CSS that consumes the tweak vars / data-attrs above.
const tweakCss = `
  /* search accent */
  .composer-submit {
    background: var(--tw-submit-bg, var(--teal-600)) !important;
    border-color: var(--tw-submit-brd, var(--teal-700)) !important;
  }
  .composer-submit:hover  { background: var(--tw-submit-bg-hover, var(--teal-700)) !important; }
  .composer-submit:active { background: var(--tw-submit-bg-press, var(--teal-800)) !important; }
  .composer-tab.is-active { border-bottom-color: var(--tw-submit-bg, var(--teal-600)) !important; }

  /* density — paper card padding + gap + section rhythm */
  body[data-density="compact"] .pc { padding: var(--tw-card-pad); gap: var(--tw-card-gap); }
  body[data-density="compact"] .section-pad { padding-block: var(--tw-section-pad-block); }
  body[data-density="compact"] .section-head { margin-bottom: 20px; }
  body[data-density="compact"] .jou-cover { aspect-ratio: 4 / 5; }
  body[data-density="compact"] .feed-grid { gap: 12px; }

  /* AI 速读 — variant: margin (no fill, just a left rule) */
  body[data-ai-style="margin"] .pc-ai {
    background: transparent;
    border: 0;
    border-left: 2px solid var(--clay-400);
    border-radius: 0;
    padding: 4px 0 4px 14px;
    margin-left: 2px;
  }
  body[data-ai-style="margin"] .pc-ai-head .auto { display: none; }
  body[data-ai-style="margin"] .pc-ai-body {
    font-style: italic;
    color: var(--ink-700);
    font-size: 14px;
  }

  /* AI 速读 — variant: hidden */
  body[data-ai-style="hidden"] .pc-ai { display: none; }

  /* Journal covers — variant: paper (cream plate with serif word) */
  body[data-journal-cover="paper"] .jou-cover {
    background: var(--paper-50) !important;
    color: var(--ink-900) !important;
    border-bottom: 1px solid var(--border-default);
  }
  body[data-journal-cover="paper"] .jou-cover::before {
    border-color: var(--ink-300);
    opacity: 0.5;
  }
  body[data-journal-cover="paper"] .jou-cover-band,
  body[data-journal-cover="paper"] .jou-cover-foot { color: var(--fg-3); opacity: 1; }
  body[data-journal-cover="paper"] .jou-cover-word { color: var(--ink-900); }
  body[data-journal-cover="paper"] .jou-cover::after { opacity: 0; }

  /* Ornament off */
  body[data-show-ornament="false"] .hero-ornament { display: none; }
  body[data-show-ornament="false"] .hero-grid { grid-template-columns: 1fr; }
`;

function App() {
  styleTagOnce("tweak-bindings", tweakCss);
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  React.useEffect(() => { applyTweakStyles(t); }, [t]);

  // pass a cloud-sorted view through context (since data is module-level)
  const ctxValue = React.useMemo(() => ({
    ...t,
    cloudData: t.cloudSort === "az"
      ? [...TOPIC_CLOUD].sort((a, b) => a.term.localeCompare(b.term, "zh"))
      : TOPIC_CLOUD,
  }), [t]);

  return (
    <TweakCtx.Provider value={ctxValue}>
      <TopNav />
      <main>
        <Hero />
        <TopicCloud />
        <Journals />
        <ExploreFeed />
      </main>
      <Footer />

      <TweaksPanel title="Tweaks · Patra 首页">
        <TweakSection label="搜索" />
        <TweakRadio
          label="主按钮色"
          value={t.searchAccent}
          options={["teal", "clay", "ink"]}
          onChange={(v) => setTweak("searchAccent", v)}
        />

        <TweakSection label="文献流" />
        <TweakRadio
          label="AI 速读样式"
          value={t.aiStyle}
          options={["callout", "margin", "hidden"]}
          onChange={(v) => setTweak("aiStyle", v)}
        />
        <TweakRadio
          label="信息密度"
          value={t.density}
          options={["comfortable", "compact"]}
          onChange={(v) => setTweak("density", v)}
        />

        <TweakSection label="主题词云" />
        <TweakRadio
          label="排序"
          value={t.cloudSort}
          options={["heat", "az"]}
          onChange={(v) => setTweak("cloudSort", v)}
        />

        <TweakSection label="期刊封面" />
        <TweakRadio
          label="封面风格"
          value={t.journalCover}
          options={["classic", "paper"]}
          onChange={(v) => setTweak("journalCover", v)}
        />

        <TweakSection label="标题" />
        <TweakToggle
          label="右侧叶饰"
          value={t.showOrnament}
          onChange={(v) => setTweak("showOrnament", v)}
        />
      </TweaksPanel>
    </TweakCtx.Provider>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
