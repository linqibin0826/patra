// Auto-bundled: icons.jsx, data.jsx, topnav.jsx, hero.jsx, topic-cloud.jsx, journals.jsx, explore-feed.jsx, footer.jsx


// ─── icons.jsx ───────────────────────────────
// =============================================================
// Lucide-style icons. 1.5px stroke, currentColor, sized via prop.
// We inline a small subset rather than load the Lucide CDN to
// avoid extra latency on the homepage.
// =============================================================

// Patra brand mark — from the design system's patra-mark.svg.
// The SVG is a richly detailed multi-color illustration (~200 paths,
// gradients, baked clay-on-ink palette). We use it as <img> rather
// than inlining, since recoloring isn't desired — the brand is the
// brand. Aspect ratio is ~1:3.9 (tall narrow leaf panel).
const PATRA_MARK_RATIO = 152.21 / 593.32;
const PatraMark = ({ width, height, className, style, ...rest }) => {
  let w = width;
  let h = height;
  if (h != null && w == null) w = Math.round(h * PATRA_MARK_RATIO * 10) / 10;
  if (w != null && h == null) h = Math.round((w / PATRA_MARK_RATIO) * 10) / 10;
  if (w == null && h == null) { h = 56; w = Math.round(h * PATRA_MARK_RATIO * 10) / 10; }
  return (
    <img
      src="assets/patra-mark.svg"
      alt=""
      aria-hidden="true"
      width={w}
      height={h}
      className={className}
      style={{ display: "inline-block", verticalAlign: "middle", ...style }}
      {...rest}
    />
  );
};
const LeafGlyph = PatraMark;

const Icon = ({ children, size = 16, stroke = 1.5, ...rest }) => (
  <svg
    width={size} height={size} viewBox="0 0 24 24"
    fill="none" stroke="currentColor"
    strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round"
    aria-hidden="true"
    {...rest}
  >{children}</svg>
);

const IconSearch    = (p) => <Icon {...p}><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></Icon>;
const IconArrowR    = (p) => <Icon {...p}><path d="M5 12h14"/><path d="m13 5 7 7-7 7"/></Icon>;
const IconArrowUR   = (p) => <Icon {...p}><path d="M7 17 17 7"/><path d="M8 7h9v9"/></Icon>;
const IconStar      = (p) => <Icon {...p}><path d="m12 3 2.7 5.7 6.3.9-4.6 4.4 1.1 6.3L12 17.3 6.5 20.3l1.1-6.3L3 9.6l6.3-.9z"/></Icon>;
const IconStarFill  = (p) => <Icon {...p}><path d="m12 3 2.7 5.7 6.3.9-4.6 4.4 1.1 6.3L12 17.3 6.5 20.3l1.1-6.3L3 9.6l6.3-.9z" fill="currentColor"/></Icon>;
const IconChat      = (p) => <Icon {...p}><path d="M21 12c0 4.4-4 8-9 8-1.2 0-2.4-.2-3.5-.6L3 21l1.7-4.4C3.6 15.2 3 13.7 3 12c0-4.4 4-8 9-8s9 3.6 9 8Z"/></Icon>;
const IconBook      = (p) => <Icon {...p}><path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H20v18H6.5A2.5 2.5 0 0 0 4 22.5"/><path d="M4 4.5v18"/><path d="M8 6h8"/><path d="M8 10h6"/></Icon>;
const IconBookmark  = (p) => <Icon {...p}><path d="M19 21 12 16l-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></Icon>;
const IconChevD     = (p) => <Icon {...p}><path d="m6 9 6 6 6-6"/></Icon>;
const IconChevR     = (p) => <Icon {...p}><path d="m9 6 6 6-6 6"/></Icon>;
const IconMenu      = (p) => <Icon {...p}><path d="M4 6h16"/><path d="M4 12h16"/><path d="M4 18h16"/></Icon>;
const IconX         = (p) => <Icon {...p}><path d="M6 6l12 12"/><path d="M18 6 6 18"/></Icon>;
const IconCommand   = (p) => <Icon {...p}><path d="M9 6a3 3 0 1 0-3 3h12a3 3 0 1 0-3-3v12a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3z"/></Icon>;
const IconExternal  = (p) => <Icon {...p}><path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M21 14v5a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5"/></Icon>;
const IconTrending  = (p) => <Icon {...p}><path d="m3 17 6-6 4 4 8-8"/><path d="M14 7h7v7"/></Icon>;
const IconClock     = (p) => <Icon {...p}><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></Icon>;
const IconQuote     = (p) => <Icon {...p}><path d="M7 7h4v4H7c0 2 1 4 4 4M14 7h4v4h-4c0 2 1 4 4 4"/></Icon>;
const IconDatabase  = (p) => <Icon {...p}><ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v6c0 1.7 3.6 3 8 3s8-1.3 8-3V5"/><path d="M4 11v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6"/></Icon>;
const IconPulse     = (p) => <Icon {...p}><path d="M2 12h4l3-7 4 14 3-7h6"/></Icon>;
const IconShare     = (p) => <Icon {...p}><circle cx="18" cy="5" r="2.5"/><circle cx="6"  cy="12" r="2.5"/><circle cx="18" cy="19" r="2.5"/><path d="m8.5 10.5 7-4"/><path d="m8.5 13.5 7 4"/></Icon>;
const IconLeaf      = (p) => <Icon {...p}><path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.5 20 3c1 4-1 9-4 11s-7 2-9 0"/><path d="M2 21c2.5-7 6-11 12-13"/></Icon>;

Object.assign(window, {
  Icon, LeafGlyph, PatraMark,
  IconSearch, IconArrowR, IconArrowUR, IconStar, IconStarFill, IconChat,
  IconBook, IconBookmark, IconChevD, IconChevR, IconMenu, IconX,
  IconCommand, IconExternal, IconTrending, IconClock, IconQuote,
  IconDatabase, IconPulse, IconShare, IconLeaf,
});


// ─── data.jsx ───────────────────────────────
// =============================================================
// PATRA — mock data for the public homepage.
// All identifiers are realistic in shape but invented;
// abstracts are paraphrased / synthetic.
// =============================================================

const PATRA_STATS = {
  records: 4238917,
  sources: 10,
  lastIngestMin: 3,
  todayAdded: 12431,
  todayDelta: 8.4, // %
};

const SEARCH_MODES = [
  { id: "keyword",  label: "关键词", placeholder: "JAK1 抑制剂 · 特应性皮炎 · 1岁以下",  mono: false },
  { id: "pmid",     label: "PMID",  placeholder: "38491203",                              mono: true  },
  { id: "doi",      label: "DOI",   placeholder: "10.1016/j.jaci.2024.03.018",            mono: true  },
  { id: "author",   label: "作者",   placeholder: "Topol, Eric J.",                        mono: false },
];

const EXAMPLE_QUERIES = [
  { mode: "keyword", text: "GLP-1 长期心血管获益" },
  { mode: "keyword", text: "AlphaFold 蛋白结构预测" },
  { mode: "doi",     text: "10.1056/NEJMoa2402202" },
  { mode: "author",  text: "Karikó, Katalin" },
];

// TopicCloud ---------------------------------------------------
// `heat` is a 0..100 score; cloud uses it for size + emphasis.
// Sorted hottest-first for mobile fallback truncation.
const TOPIC_CLOUD = [
  { term: "GLP-1 受体激动剂",      heat: 100, count: 1842, delta:  "+34%" },
  { term: "mRNA 疫苗平台",         heat: 96,  count: 1521, delta:  "+18%" },
  { term: "CRISPR-Cas9 体内编辑",  heat: 92,  count: 1304, delta:  "+27%" },
  { term: "阿尔茨海默 单抗",       heat: 88,  count: 1209, delta:  "+11%" },
  { term: "肠道菌群 · IBD",        heat: 78,  count:  984 },
  { term: "PD-1 联合化疗",         heat: 76,  count:  952 },
  { term: "妊娠期糖尿病",          heat: 70,  count:  812 },
  { term: "AlphaFold",            heat: 68,  count:  790 },
  { term: "ECMO 撤机时机",         heat: 62,  count:  691 },
  { term: "睡眠呼吸暂停 · 儿童",   heat: 58,  count:  640 },
  { term: "JAK 抑制剂",            heat: 56,  count:  618 },
  { term: "肾移植 · 排异",         heat: 50,  count:  541 },
  { term: "肺动脉高压",            heat: 48,  count:  502 },
  { term: "脓毒症 · 早期识别",     heat: 46,  count:  478 },
  { term: "线粒体替代",            heat: 42,  count:  421 },
  { term: "戊型肝炎 疫苗",         heat: 40,  count:  402 },
  { term: "微塑料 · 心血管",       heat: 38,  count:  378 },
  { term: "类器官 · 药筛",         heat: 36,  count:  356 },
  { term: "ApoE4 与 痴呆",         heat: 34,  count:  330 },
  { term: "数字疗法 · 抑郁",       heat: 32,  count:  298 },
  { term: "妇科肿瘤 PARP",        heat: 30,  count:  276 },
  { term: "胰岛素抵抗 · 代谢",     heat: 28,  count:  254 },
  { term: "肠系膜缺血",            heat: 24,  count:  204 },
  { term: "EBV 与 多发性硬化",     heat: 22,  count:  187 },
  { term: "CAR-T · 实体瘤",        heat: 20,  count:  176 },
  { term: "妊娠 高血压",           heat: 18,  count:  154 },
  { term: "围术期 镇痛",           heat: 14,  count:  121 },
  { term: "肠脑轴",               heat: 12,  count:  108 },
  { term: "结核 耐药",            heat: 10,  count:   96 },
  { term: "脑机接口 · 临床",      heat:  9,  count:   88 },
  { term: "睡眠时长 · 全因死亡",   heat:  8,  count:   76 },
  { term: "心衰 · SGLT2",         heat:  6,  count:   62 },
];

// Journals -----------------------------------------------------
// Mock "covers" — each gets a paper-tinted plate with the
// journal's serif initials/wordmark. Avoiding photographic logos.
const JOURNALS = [
  {
    id: "nejm",
    name: "New England Journal of Medicine",
    abbr: "N Engl J Med",
    cover: "NEJM",
    coverStyle: { bg: "#3C1611", ink: "#F6E8DA", rule: "#7C2F22" }, // muted oxblood
    impact: 158.5,
    weekly: 312,
    founded: 1812,
  },
  {
    id: "lancet",
    name: "The Lancet",
    abbr: "Lancet",
    cover: "Lancet",
    coverStyle: { bg: "#5A1A14", ink: "#F6E8DA", rule: "#8A2A1F" },
    impact: 98.4,
    weekly: 284,
    founded: 1823,
  },
  {
    id: "jama",
    name: "Journal of the American Medical Association",
    abbr: "JAMA",
    cover: "JAMA",
    coverStyle: { bg: "#1F2E45", ink: "#E9EEF4", rule: "#3A506E" }, // navy
    impact: 63.1,
    weekly: 196,
    founded: 1883,
  },
  {
    id: "bmj",
    name: "The BMJ",
    abbr: "BMJ",
    cover: "BMJ",
    coverStyle: { bg: "#0E574F", ink: "#ECF5F3", rule: "#176B62" }, // teal
    impact: 105.7,
    weekly: 168,
    founded: 1840,
  },
  {
    id: "nature-med",
    name: "Nature Medicine",
    abbr: "Nat Med",
    cover: "Nature\nMedicine",
    coverStyle: { bg: "#1C1917", ink: "#F4D9B8", rule: "#3E1C0C" }, // ink + clay
    impact: 87.2,
    weekly: 122,
    founded: 1995,
  },
  {
    id: "cell",
    name: "Cell",
    abbr: "Cell",
    cover: "Cell",
    coverStyle: { bg: "#6E3216", ink: "#FBF1E8", rule: "#97441E" }, // clay deep
    impact: 66.9,
    weekly: 98,
    founded: 1974,
  },
];

// Explore feed -------------------------------------------------
// Three tabs, each ~6 cards. AI summaries are short — one or
// two sentences, written in the librarian voice.
const FEED = {
  "trending": [
    {
      id: "p1",
      title: "Semaglutide 在合并慢性肾病的 2 型糖尿病患者中的长期心血管转归",
      journal: "N Engl J Med",
      year: 2026,
      authors: ["Perkovic V.", "Tuttle K. R.", "Mann J. F. E.", "..."],
      authorCount: 14,
      cites: 142,
      bookmarks: 318,
      readMin: 12,
      doi: "10.1056/NEJMoa2603120",
      pmid: "39812044",
      source: "PubMed",
      ai: "在 eGFR 25–75 区间的人群中观察到主要心血管事件下降 22%（HR 0.78，95% CI 0.69–0.89），获益与基线 HbA1c 无关；肾病进展指标在 24 个月时已与对照分离。",
      kind: "RCT · phase 3",
    },
    {
      id: "p2",
      title: "针对 KRAS G12D 的口服小分子在胰腺导管腺癌中的 I 期剂量爬坡",
      journal: "Cell",
      year: 2026,
      authors: ["Yamaguchi T.", "Banerjee S.", "Cho A."],
      authorCount: 9,
      cites: 28,
      bookmarks: 92,
      readMin: 9,
      doi: "10.1016/j.cell.2026.02.011",
      pmid: "39798210",
      source: "Europe PMC",
      ai: "首报 KRAS G12D 选择性抑制在 28 例既往治疗失败患者中观察到 21% 的客观缓解；3/4 级毒性以皮疹和腹泻为主，未见剂量限制性肝毒性。",
      kind: "Phase 1",
    },
    {
      id: "p3",
      title: "Lecanemab 在前驱期 AD 中长达 36 个月的脑容积与 CDR-SB 轨迹",
      journal: "JAMA Neurology",
      year: 2026,
      authors: ["van Dyck C. H.", "Sims J.", "Cohen S."],
      authorCount: 22,
      cites: 81,
      bookmarks: 204,
      readMin: 14,
      doi: "10.1001/jamaneurol.2026.0118",
      pmid: "39795511",
      source: "PubMed",
      ai: "海马旁回与楔前叶萎缩速率较安慰剂减慢 0.18%/年，但脑室扩大反向更快；CDR-SB 差异 −0.44（p=0.003），临床意义仍受 ARIA-E 累积 12.6% 的影响。",
      kind: "Open-label extension",
    },
    {
      id: "p4",
      title: "肠道微生物组成预测 PD-1 单抗在转移性黑色素瘤中的应答",
      journal: "Nat Med",
      year: 2026,
      authors: ["Routy B.", "Gopalakrishnan V."],
      authorCount: 31,
      cites: 56,
      bookmarks: 173,
      readMin: 11,
      doi: "10.1038/s41591-026-02831-4",
      pmid: "39788412",
      source: "Crossref",
      ai: "Akkermansia muciniphila 与 Bifidobacterium longum 的相对丰度联合给出 AUC 0.78 的预测；抗生素暴露的人群即便达到阈值丰度，应答率仍下降一半。",
      kind: "Prospective cohort",
    },
    {
      id: "p5",
      title: "可穿戴心电监测筛查无症状房颤的成本效益再评估",
      journal: "BMJ",
      year: 2026,
      authors: ["Lopes R. D.", "Granger C. B."],
      authorCount: 8,
      cites: 19,
      bookmarks: 88,
      readMin: 7,
      doi: "10.1136/bmj-2026-079211",
      pmid: "39801288",
      source: "PubMed",
      ai: "在 65–74 岁人群中 ICER 为每 QALY £18,400，处于 NICE 阈值之内；但模型对依从性与抗凝起始延迟高度敏感，依从 < 60% 时该结论翻转。",
      kind: "Markov model",
    },
    {
      id: "p6",
      title: "成人脓毒症复苏中限制性 vs. 自由液体策略的 90 天死亡率",
      journal: "Lancet",
      year: 2026,
      authors: ["Meyhoff T. S.", "Hjortrup P. B."],
      authorCount: 19,
      cites: 64,
      bookmarks: 141,
      readMin: 10,
      doi: "10.1016/S0140-6736(26)00118-3",
      pmid: "39792001",
      source: "PubMed",
      ai: "限制性策略 90 天死亡 32.1% vs. 自由 33.9%，差异未达统计显著（aRR 0.95，p=0.21）；但限制组在 ICU 留观天数与肾脏替代启动率上更低。",
      kind: "RCT · pragmatic",
    },
  ],
  "recent": [
    {
      id: "r1",
      title: "EBV 抗体滴度与多发性硬化发病的前瞻嵌套病例对照",
      journal: "Science",
      year: 2026,
      authors: ["Bjornevik K.", "Cortese M."],
      authorCount: 11,
      cites: 4, bookmarks: 21, readMin: 8,
      doi: "10.1126/science.adn7421", pmid: "39820114", source: "Crossref",
      ai: "EBNA-1 IgG 升高在临床发病前中位 5.2 年即可观察到；HLA-DRB1*15:01 携带者的相对风险进一步上升约 3 倍。",
      kind: "Nested case-control",
      minutesAgo: 12,
    },
    {
      id: "r2",
      title: "新生儿败血症血培养替代的多重 PCR 床旁面板：诊断准确性",
      journal: "Clin Infect Dis", year: 2026,
      authors: ["Schlapbach L. J.", "Wynn J. L."],
      authorCount: 7, cites: 1, bookmarks: 9, readMin: 6,
      doi: "10.1093/cid/ciae0921", pmid: "39819982", source: "PubMed",
      ai: "对革兰阳性球菌敏感性 96%，对革兰阴性杆菌 89%；阴性预测值 99.1%，但对厌氧菌识别仍不足。",
      kind: "Diagnostic accuracy",
      minutesAgo: 27,
    },
    {
      id: "r3",
      title: "妊娠期甲状腺功能轻度异常对子代神经发育的 8 年随访",
      journal: "Lancet Diabetes Endocrinol", year: 2026,
      authors: ["Korevaar T. I. M."],
      authorCount: 14, cites: 0, bookmarks: 14, readMin: 9,
      doi: "10.1016/S2213-8587(26)00045-1", pmid: "39819701", source: "PubMed",
      ai: "TPO 抗体阳性母亲的子代 WISC-V 言语理解评分低 2.4 分（95% CI −3.8 到 −1.0）；左旋甲状腺素干预的亚组未见受益。",
      kind: "Cohort · 8y",
      minutesAgo: 44,
    },
    {
      id: "r4",
      title: "围术期低温对结直肠手术伤口感染率的多中心非劣效",
      journal: "Ann Surg", year: 2026,
      authors: ["Sessler D. I."],
      authorCount: 17, cites: 0, bookmarks: 6, readMin: 7,
      doi: "10.1097/SLA.0000000000007121", pmid: "39819444", source: "Europe PMC",
      ai: "强制升温至 36.5 ℃ vs. 标准 36.0 ℃ 在 SSI 上未见差异（5.8% vs. 6.1%）；提示常规更积极升温在该术式中可能并无额外获益。",
      kind: "RCT · non-inferiority",
      minutesAgo: 68,
    },
  ],
  "cited": [
    {
      id: "c1",
      title: "GLP-1 受体激动剂在心衰保留射血分数患者中的运动耐量与症状改善",
      journal: "N Engl J Med", year: 2025,
      authors: ["Kosiborod M. N.", "Petrie M. C."],
      authorCount: 24, cites: 1842, bookmarks: 1129, readMin: 13,
      doi: "10.1056/NEJMoa2505121", pmid: "39624111", source: "PubMed",
      ai: "KCCQ-CSS 12 周改善 8.6 分（vs. 安慰剂 +3.1），6MWT 多 21 米；BMI ≥ 35 亚组获益最大，提示去脂效应可能并非唯一通路。",
      kind: "RCT · phase 3",
    },
    {
      id: "c2",
      title: "AlphaMissense：在蛋白质组规模预测错义变异的致病性",
      journal: "Science", year: 2025,
      authors: ["Cheng J.", "Novati G."],
      authorCount: 19, cites: 1521, bookmarks: 904, readMin: 11,
      doi: "10.1126/science.adg7492", pmid: "39312041", source: "Crossref",
      ai: "对 7100 万错义变异给出致病性评分；在 ClinVar 上以 0.94 AUROC 区分良性与致病，对 VUS 的归类提供了量化先验。",
      kind: "Methods",
    },
    {
      id: "c3",
      title: "Lecanemab 在前驱期 AD 的 18 个月临床与生物标志物结局",
      journal: "N Engl J Med", year: 2025,
      authors: ["van Dyck C. H.", "Swanson C. J."],
      authorCount: 27, cites: 1304, bookmarks: 712, readMin: 12,
      doi: "10.1056/NEJMoa2212948", pmid: "36449413", source: "PubMed",
      ai: "CDR-SB 减缓 27%；ARIA-E 累积发生率 12.6%，APOE ε4 纯合子人群中升至约 33%，影响安全监测策略的设计。",
      kind: "RCT · phase 3",
    },
    {
      id: "c4",
      title: "微塑料在颈动脉斑块组织中的检出与心血管事件关联",
      journal: "N Engl J Med", year: 2025,
      authors: ["Marfella R."],
      authorCount: 15, cites: 1209, bookmarks: 588, readMin: 8,
      doi: "10.1056/NEJMoa2309822", pmid: "38477987", source: "PubMed",
      ai: "在 304 例样本中 58% 检出 PE/PVC，对应 34 个月内 MACE 风险 HR 4.53；样本量限于一家中心，机制仍需独立验证。",
      kind: "Prospective",
    },
  ],
};

Object.assign(window, {
  PATRA_STATS, SEARCH_MODES, EXAMPLE_QUERIES,
  TOPIC_CLOUD, JOURNALS, FEED,
});


// ─── topnav.jsx ───────────────────────────────
// =============================================================
// TopNav — fixed 56px top bar.
//   left:   wordmark
//   center: primary nav (home active; literature/journals/topics
//           shown as disabled "soon" placeholders per brief)
//   right:  about + small command-K hint, GitHub mark.
// On < 880px the center nav collapses into a drawer behind a
// menu button; the wordmark stays.
// =============================================================

const navStyles = `
  .topnav {
    position: sticky; top: 0; z-index: 40;
    background: rgba(247, 242, 232, 0.86);
    backdrop-filter: saturate(1.1) blur(8px);
    -webkit-backdrop-filter: saturate(1.1) blur(8px);
    border-bottom: 1px solid var(--border-default);
  }
  .topnav-row {
    display: grid;
    grid-template-columns: auto 1fr auto;
    align-items: center;
    height: 56px;
    gap: 24px;
  }
  .brand {
    display: inline-flex; align-items: center; gap: 10px;
    text-decoration: none; color: var(--fg-1);
    line-height: 1;
  }
  .brand-mark {
    color: var(--ink-900);
    display: inline-flex;
  }
  .brand-word {
    font-family: var(--font-serif);
    font-weight: 500;
    font-size: 22px;
    letter-spacing: -0.02em;
    color: var(--ink-900);
  }
  .brand-badge {
    font-family: var(--font-sans);
    font-size: 10px;
    font-weight: 500;
    color: var(--clay-700);
    padding: 1px 6px;
    border: 1px solid var(--clay-200);
    border-radius: 3px;
    background: var(--clay-50);
    margin-left: 2px;
    line-height: 1.4;
    letter-spacing: 0.06em;
  }

  .nav-primary {
    justify-self: center;
    display: flex; align-items: center; gap: 2px;
  }
  .nav-link {
    font-family: var(--font-sans);
    font-size: var(--text-base);
    font-weight: 500;
    color: var(--fg-2);
    text-decoration: none;
    padding: 6px 12px;
    border-radius: var(--radius-sm);
    cursor: pointer;
    display: inline-flex; align-items: center; gap: 6px;
    line-height: 1.4;
    transition: color var(--dur-fast), background var(--dur-fast);
  }
  .nav-link:hover { color: var(--fg-1); background: var(--paper-200); }
  .nav-link.is-active {
    color: var(--fg-1);
    background: transparent;
    box-shadow: inset 0 -2px 0 0 var(--clay-500);
    border-radius: 0;
  }
  .nav-link.is-disabled {
    color: var(--fg-4); cursor: default; pointer-events: none;
  }
  .nav-link .soon {
    font-family: var(--font-mono);
    font-size: 9.5px;
    letter-spacing: 0.04em;
    color: var(--fg-4);
    border: 1px solid var(--border-subtle);
    border-radius: 3px;
    padding: 0 4px;
    text-transform: uppercase;
    background: var(--paper-100);
  }

  .nav-trail {
    justify-self: end;
    display: flex; align-items: center; gap: 8px;
  }
  .cmdk {
    display: inline-flex; align-items: center; gap: 8px;
    background: var(--bg-paper);
    border: 1px solid var(--border-default);
    border-radius: var(--radius-md);
    padding: 4px 8px 4px 10px;
    color: var(--fg-3);
    font-size: var(--text-sm);
    cursor: pointer;
    transition: background var(--dur-fast);
  }
  .cmdk:hover { background: var(--paper-200); }

  .menu-btn {
    width: 36px; height: 36px;
    display: none; align-items: center; justify-content: center;
    background: transparent; border: 1px solid transparent;
    border-radius: var(--radius-sm);
    cursor: pointer; color: var(--fg-1);
  }
  .menu-btn:hover { background: var(--paper-200); }

  /* mobile drawer */
  .mobile-drawer {
    position: fixed; inset: 56px 0 0 0;
    background: var(--bg-canvas);
    z-index: 35;
    padding: 16px 20px 32px;
    display: flex; flex-direction: column;
    gap: 6px;
    border-top: 1px solid var(--border-default);
  }
  .mobile-drawer .nav-link {
    padding: 14px 8px;
    font-size: 16px;
    border-bottom: 1px solid var(--border-subtle);
    border-radius: 0;
    justify-content: space-between;
  }
  .mobile-drawer .nav-link.is-active { box-shadow: inset 4px 0 0 0 var(--clay-500); padding-left: 16px; }

  @media (max-width: 880px) {
    .topnav-row { grid-template-columns: auto 1fr auto; gap: 12px; }
    .nav-primary { display: none; }
    .nav-trail .cmdk { display: none; }
    .nav-trail .about-link { display: none; }
    .menu-btn { display: inline-flex; }
  }
`;

const styleTagOnce = (id, css) => {
  if (typeof document === "undefined") return;
  if (document.getElementById(id)) return;
  const tag = document.createElement("style");
  tag.id = id; tag.textContent = css;
  document.head.appendChild(tag);
};

function TopNav() {
  styleTagOnce("topnav-styles", navStyles);
  const [open, setOpen] = React.useState(false);

  React.useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [open]);

  const NavLinks = ({ inDrawer = false }) => (
    <>
      <a className="nav-link is-active" href="#top" onClick={() => setOpen(false)}>首页</a>
      <a className="nav-link is-disabled" aria-disabled="true">
        文献 <span className="soon">soon</span>
      </a>
      <a className="nav-link is-disabled" aria-disabled="true">
        期刊 <span className="soon">soon</span>
      </a>
      <a className="nav-link is-disabled" aria-disabled="true">
        主题 <span className="soon">soon</span>
      </a>
      {inDrawer && (
        <>
          <div style={{ height: 16 }} />
          <a className="nav-link" href="#about">关于</a>
          <a className="nav-link" href="#" onClick={(e) => e.preventDefault()}>
            GitHub <IconExternal size={14}/>
          </a>
        </>
      )}
    </>
  );

  return (
    <header className="topnav" data-screen-label="00 TopNav">
      <div className="container topnav-row">
        <a className="brand" href="#top" aria-label="Patra 首页">
          <span className="brand-mark"><PatraMark height={30} /></span>
          <span className="brand-word">Patra</span>
          <span className="brand-badge">门户</span>
        </a>

        <nav className="nav-primary" aria-label="主导航">
          <NavLinks />
        </nav>

        <div className="nav-trail">
          <button className="cmdk" type="button" onClick={() => document.querySelector('#hero-input')?.focus()}>
            <IconSearch size={14}/> 搜索 <span className="kbd">⌘K</span>
          </button>
          <a className="nav-link about-link" href="#about">关于</a>
          <button
            className="menu-btn"
            type="button"
            aria-label={open ? "关闭菜单" : "打开菜单"}
            aria-expanded={open}
            onClick={() => setOpen(o => !o)}
          >
            {open ? <IconX size={20}/> : <IconMenu size={20}/>}
          </button>
        </div>
      </div>

      {open && (
        <div className="mobile-drawer" role="dialog" aria-label="导航菜单">
          <NavLinks inDrawer />
        </div>
      )}
    </header>
  );
}

window.TopNav = TopNav;


// ─── hero.jsx ───────────────────────────────
// =============================================================
// Hero — page-opening block.
//   masthead row (paper-style statline) ──────────────────────
//   serif display headline (left)        right ornament (mark)
//   sans body subtitle
//   search composer (mode chips + input + submit)
//   example queries
// =============================================================

const heroStyles = `
  .hero {
    padding: 64px 0 56px;
    position: relative;
    overflow: hidden;
  }
  @media (max-width: 880px) { .hero { padding: 32px 0 40px; } }

  /* masthead — a thin rule + statline like a newspaper masthead */
  .masthead {
    display: flex; align-items: center; justify-content: space-between;
    gap: 16px;
    border-top: 1px solid var(--ink-900);
    border-bottom: 1px solid var(--border-default);
    padding: 8px 0;
    margin-bottom: 40px;
  }
  .masthead .stats {
    display: flex; gap: 22px; flex-wrap: wrap;
    font-family: var(--font-sans);
    font-size: 11.5px;
    color: var(--fg-3);
    letter-spacing: 0;
  }
  .masthead .stats > span {
    display: inline-flex; align-items: baseline; gap: 6px;
    white-space: nowrap;
  }
  .masthead .stats b {
    font-family: var(--font-mono);
    color: var(--ink-900); font-weight: 600;
    font-variant-numeric: tabular-nums;
    font-size: 12px;
    letter-spacing: 0;
  }
  .masthead .live {
    display: inline-flex; align-items: center; gap: 6px;
    color: var(--moss-500);
    font-family: var(--font-mono);
    font-size: 10.5px;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    white-space: nowrap;
  }
  .masthead .live::before {
    content: ""; width: 6px; height: 6px; border-radius: 50%;
    background: var(--moss-500);
    animation: live-pulse 1.6s var(--ease-standard) infinite;
  }
  @keyframes live-pulse {
    0%, 100% { opacity: 0.45; }
    50%      { opacity: 1; }
  }
  @media (max-width: 640px) {
    .masthead { font-size: 10px; padding: 6px 0; margin-bottom: 28px; }
    .masthead .stats { gap: 10px; }
    .masthead .stats > span:nth-child(3) { display: none; }
  }

  /* headline grid */
  .hero-grid {
    display: grid;
    grid-template-columns: minmax(0, 1fr) auto;
    align-items: end;
    gap: 32px;
    margin-bottom: 28px;
  }
  .hero-display {
    font-family: var(--font-serif);
    font-weight: 500;
    font-size: clamp(36px, 5.4vw, 60px);
    line-height: 1.04;
    letter-spacing: -0.025em;
    color: var(--fg-1);
    margin: 0;
    text-wrap: balance;
  }
  .hero-display em {
    font-style: italic;
    color: var(--clay-700);
    font-weight: 500;
  }
  .hero-display .nb {
    /* keep "可被检索." together */
    white-space: nowrap;
  }
  .hero-ornament {
    color: var(--ink-900);
    opacity: 0.88;
    flex-shrink: 0;
    align-self: end;
  }
  @media (max-width: 880px) {
    .hero-grid { grid-template-columns: 1fr; gap: 8px; }
    .hero-ornament { display: none; }
  }

  .hero-sub {
    font-family: var(--font-serif);
    font-size: clamp(16px, 1.6vw, 18px);
    line-height: 1.55;
    color: var(--fg-2);
    max-width: 640px;
    margin: 0 0 36px;
    text-wrap: pretty;
  }
  @media (max-width: 880px) { .hero-sub { margin-bottom: 24px; } }

  /* composer ------------------------------------------------- */
  .composer {
    background: #fff;
    border: 1px solid var(--ink-800);
    border-radius: var(--radius-lg);
    box-shadow: 0 1px 0 0 var(--paper-300), var(--shadow-sm);
    overflow: hidden;
  }
  .composer-tabs {
    display: flex; align-items: center; gap: 0;
    border-bottom: 1px solid var(--border-default);
    background: var(--paper-50);
    padding: 0 6px;
    overflow-x: auto;
    scrollbar-width: none;
  }
  .composer-tabs::-webkit-scrollbar { display: none; }
  .composer-tab {
    font-family: var(--font-sans);
    font-size: var(--text-sm);
    font-weight: 500;
    color: var(--fg-3);
    background: transparent;
    border: 0;
    padding: 10px 14px;
    cursor: pointer;
    border-bottom: 2px solid transparent;
    margin-bottom: -1px;
    white-space: nowrap;
    line-height: 1.2;
    transition: color var(--dur-fast), border-color var(--dur-fast);
  }
  .composer-tab:hover { color: var(--fg-1); }
  .composer-tab.is-active {
    color: var(--ink-900);
    border-bottom-color: var(--teal-600);
  }
  .composer-tab .hint {
    margin-left: 6px;
    font-family: var(--font-mono);
    font-size: 10.5px;
    color: var(--fg-4);
  }

  .composer-input-row {
    display: flex; align-items: center;
    padding: 6px 6px 6px 18px;
    gap: 12px;
  }
  .composer-icon { color: var(--fg-3); flex-shrink: 0; }
  .composer-input {
    flex: 1;
    border: 0; outline: none; background: transparent;
    font-family: var(--font-sans);
    font-size: 18px;
    line-height: 1.4;
    color: var(--ink-900);
    padding: 14px 0;
    min-width: 0;
  }
  .composer-input.is-mono {
    font-family: var(--font-mono);
    font-size: 16px;
    letter-spacing: 0.01em;
  }
  .composer-input::placeholder { color: var(--fg-4); }
  .composer-submit {
    flex-shrink: 0;
    background: var(--teal-600);
    color: var(--fg-on-clay);
    border: 1px solid var(--teal-700);
    border-radius: var(--radius-md);
    padding: 10px 16px;
    font-family: var(--font-sans);
    font-weight: 600;
    font-size: var(--text-base);
    cursor: pointer;
    display: inline-flex; align-items: center; gap: 6px;
    transition: background var(--dur-fast);
  }
  .composer-submit:hover { background: var(--teal-700); }
  .composer-submit:active { background: var(--teal-800); }
  .composer-submit .kbd {
    background: rgba(255,255,255,0.16);
    border-color: rgba(255,255,255,0.25);
    color: rgba(255,255,255,0.9);
  }
  @media (max-width: 640px) {
    .composer-input-row { padding-left: 12px; }
    .composer-input { font-size: 16px; padding: 12px 0; }
    .composer-input.is-mono { font-size: 14px; }
    .composer-submit { padding: 9px 12px; }
    .composer-submit .submit-label { display: none; }
  }

  .composer-foot {
    padding: 10px 14px;
    background: var(--paper-50);
    border-top: 1px solid var(--border-subtle);
    display: flex; gap: 8px; align-items: center;
    flex-wrap: wrap;
    font-size: var(--text-xs);
    color: var(--fg-3);
  }
  .composer-foot .try-label {
    font-family: var(--font-mono);
    text-transform: uppercase;
    letter-spacing: 0.06em;
    font-size: 10px;
    color: var(--fg-3);
    margin-right: 2px;
  }
  .ex-chip {
    background: #fff;
    border: 1px solid var(--border-default);
    border-radius: var(--radius-pill);
    padding: 3px 10px;
    font-size: var(--text-xs);
    color: var(--fg-2);
    cursor: pointer;
    transition: background var(--dur-fast), border-color var(--dur-fast), color var(--dur-fast);
    display: inline-flex; align-items: center; gap: 5px;
    font-family: var(--font-sans);
    white-space: nowrap;
  }
  .ex-chip:hover { background: var(--paper-200); border-color: var(--ink-300); color: var(--ink-900); }
  .ex-chip .ex-mode {
    font-family: var(--font-mono);
    font-size: 10px;
    color: var(--fg-4);
    text-transform: uppercase;
    letter-spacing: 0.04em;
    border-right: 1px solid var(--border-default);
    padding-right: 6px;
    margin-right: 2px;
  }
  .ex-chip.is-mono { font-family: var(--font-mono); font-size: 11px; }
`;

function Hero() {
  styleTagOnce("hero-styles", heroStyles);
  const [mode, setMode] = React.useState("keyword");
  const [value, setValue] = React.useState("");
  const inputRef = React.useRef(null);

  const current = SEARCH_MODES.find(m => m.id === mode) || SEARCH_MODES[0];

  const submit = (e) => {
    e?.preventDefault?.();
    // Demo only — flash the input to acknowledge the action.
    if (!value.trim()) {
      inputRef.current?.focus();
      return;
    }
    const el = inputRef.current;
    if (el) {
      el.style.transition = "background var(--dur-fast)";
      el.parentElement.style.background = "var(--teal-50)";
      setTimeout(() => { el.parentElement.style.background = ""; }, 180);
    }
  };

  const applyExample = (ex) => {
    setMode(ex.mode);
    setValue(ex.text);
    setTimeout(() => inputRef.current?.focus(), 0);
  };

  return (
    <section className="hero" id="top" data-screen-label="01 Hero">
      <div className="container">
        <div className="masthead">
          <div className="stats">
            <span><b>{PATRA_STATS.records.toLocaleString()}</b> 条文献</span>
            <span><b>{PATRA_STATS.sources}</b> 数据源</span>
            <span>更新于 <b>{PATRA_STATS.lastIngestMin} 分钟前</b></span>
          </div>
          <div className="live">实时同步</div>
        </div>

        <div className="hero-grid">
          <h1 className="hero-display">
            医学文献，<br/>
            <em>可被检索</em>，可被引用。
          </h1>
          <div className="hero-ornament" aria-hidden="true"><PatraMark height={280} /></div>
        </div>

        <p className="hero-sub">
          Patra 汇集 PubMed、Europe PMC、Crossref 等 10 个来源的学术文献，提供统一检索、出处追溯与 AI 辅助速读。门户对所有访客开放浏览。
        </p>

        <form className="composer" onSubmit={submit}>
          <div className="composer-tabs" role="tablist">
            {SEARCH_MODES.map(m => (
              <button
                key={m.id}
                role="tab"
                aria-selected={mode === m.id}
                className={`composer-tab ${mode === m.id ? "is-active" : ""}`}
                onClick={(e) => { e.preventDefault(); setMode(m.id); setValue(""); setTimeout(() => inputRef.current?.focus(), 0); }}
                type="button"
              >
                {m.label}
                {m.id === "keyword" && <span className="hint">默认</span>}
              </button>
            ))}
          </div>
          <div className="composer-input-row">
            <span className="composer-icon"><IconSearch size={20}/></span>
            <input
              id="hero-input"
              ref={inputRef}
              className={`composer-input ${current.mono ? "is-mono" : ""}`}
              placeholder={current.placeholder}
              value={value}
              onChange={(e) => setValue(e.target.value)}
              autoComplete="off"
              spellCheck="false"
              aria-label={`按${current.label}搜索`}
            />
            <button className="composer-submit" type="submit">
              <span className="submit-label">搜索</span>
              <span className="kbd">⌘↵</span>
            </button>
          </div>
          <div className="composer-foot">
            <span className="try-label">试试</span>
            {EXAMPLE_QUERIES.map((ex, i) => {
              const m = SEARCH_MODES.find(s => s.id === ex.mode);
              return (
                <button
                  key={i}
                  type="button"
                  className={`ex-chip ${m?.mono ? "is-mono" : ""}`}
                  onClick={() => applyExample(ex)}
                >
                  <span className="ex-mode">{m?.label}</span>
                  {ex.text}
                </button>
              );
            })}
          </div>
        </form>
      </div>
    </section>
  );
}

window.Hero = Hero;


// ─── topic-cloud.jsx ───────────────────────────────
// =============================================================
// TopicCloud — the homepage centerpiece.
// A weighted keyword cloud, sized & colored by heat. Top items
// also surface a small +Δ% delta badge so the "what's accelerating
// right now" signal isn't lost on either form factor.
// Sits in a clay-50 tinted band to give it editorial weight.
// =============================================================

const cloudStyles = `
  .cloud-meta {
    display: flex; align-items: baseline; gap: 12px; flex-wrap: wrap;
  }
  .cloud-meta .num {
    font-family: var(--font-mono);
    font-variant-numeric: tabular-nums;
    font-size: var(--text-xs);
    color: var(--fg-3);
  }

  .cloud-wrap {
    margin-top: 8px;
    column-rule: 1px solid var(--paper-300);
    border-top: 1px solid #EBDDC7;
    border-bottom: 1px solid #EBDDC7;
    padding: 32px 0 28px;
  }
  .cloud {
    display: flex; flex-wrap: wrap;
    align-items: baseline;
    gap: 22px 22px;
    line-height: 1.1;
  }
  @media (max-width: 880px) { .cloud { gap: 16px 16px; } }

  .topic {
    display: inline-flex;
    align-items: baseline;
    gap: 6px;
    color: inherit;
    text-decoration: none;
    cursor: pointer;
    border-radius: var(--radius-sm);
    padding: 1px 4px;
    margin: -1px -4px;
    transition: background var(--dur-fast), color var(--dur-fast);
    line-height: 1;
    font-feature-settings: "ss01", "cv11";
    white-space: nowrap;
  }
  .topic:hover { background: var(--paper-200); }
  .topic:focus-visible {
    outline: none; box-shadow: var(--ring-focus);
  }
  .topic .delta {
    font-family: var(--font-mono);
    font-size: 12px;
    font-weight: 600;
    color: var(--clay-600);
    letter-spacing: 0;
    white-space: nowrap;
  }
  .topic .arr {
    font-family: var(--font-mono);
    color: var(--clay-600);
    font-size: 0.7em;
    transform: translateY(-0.05em);
  }

  /* Heat tiers */
  .topic.t-1 {
    font-family: var(--font-serif);
    font-style: italic;
    font-weight: 500;
    font-size: clamp(28px, 3.4vw, 38px);
    color: var(--clay-800);
    letter-spacing: -0.015em;
    line-height: 1;
  }
  .topic.t-2 {
    font-family: var(--font-serif);
    font-weight: 500;
    font-size: clamp(22px, 2.4vw, 28px);
    color: var(--ink-900);
    letter-spacing: -0.01em;
    line-height: 1;
  }
  .topic.t-3 {
    font-family: var(--font-sans);
    font-weight: 600;
    font-size: clamp(17px, 1.6vw, 20px);
    color: var(--ink-800);
    letter-spacing: -0.005em;
  }
  .topic.t-4 {
    font-family: var(--font-sans);
    font-weight: 500;
    font-size: 15px;
    color: var(--ink-700);
  }
  .topic.t-5 {
    font-family: var(--font-sans);
    font-weight: 400;
    font-size: 13px;
    color: var(--ink-600);
  }

  .cloud-foot {
    margin-top: 32px;
    display: flex; align-items: center; justify-content: space-between;
    gap: 12px;
    flex-wrap: wrap;
  }
  .cloud-legend {
    display: flex; gap: 18px; align-items: center;
    font-family: var(--font-mono);
    font-size: var(--text-2xs);
    color: var(--fg-3);
    text-transform: uppercase;
    letter-spacing: 0.06em;
    flex-wrap: wrap;
  }
  .cloud-legend > span {
    display: inline-flex; align-items: center; gap: 6px;
    white-space: nowrap;
  }
  .legend-bar {
    display: inline-flex; align-items: stretch; height: 8px; border-radius: 2px; overflow: hidden;
    border: 1px solid var(--paper-300);
    margin-right: 6px;
    width: 96px;
  }
  .legend-bar > span { flex: 1; }
`;

function topicTier(heat) {
  if (heat >= 88) return 1;
  if (heat >= 70) return 2;
  if (heat >= 45) return 3;
  if (heat >= 25) return 4;
  return 5;
}

function TopicCloud() {
  styleTagOnce("topic-cloud-styles", cloudStyles);
  // Read sorted view from tweak context (defaults to heat-sorted).
  const ctx = (typeof useTweakCtx === "function" ? useTweakCtx() : null);
  const topics = (ctx && ctx.cloudData) ? ctx.cloudData : TOPIC_CLOUD;

  return (
    <section className="band-tint" data-screen-label="02 TopicCloud">
      <div className="container section-pad">
        <div className="section-head">
          <div className="lhs">
            <span className="eyebrow"><span className="leaf"><PatraMark height={16} /></span> 此刻热议 · trending now</span>
            <h2 className="section-title">医学界正在讨论<em style={{ fontStyle: "italic", color: "var(--clay-700)" }}>什么</em></h2>
            <p className="section-sub">
              基于过去 72 小时的检索、被引与抓取频次合成的关键词热度。点选任一词条进入文献检索。
            </p>
          </div>
          <div className="rhs cloud-meta">
            <span className="num">截至 17:42 · 滑动 72h</span>
          </div>
        </div>

        <div className="cloud-wrap">
          <div className="cloud" role="list">
            {topics.map((t) => {
              const tier = topicTier(t.heat);
              return (
                <a
                  key={t.term}
                  role="listitem"
                  href="#"
                  onClick={(e) => e.preventDefault()}
                  className={`topic t-${tier}`}
                  title={`${t.count.toLocaleString()} 条相关文献`}
                >
                  <span>{t.term}</span>
                  {tier === 1 && t.delta && (
                    <span className="delta"><span className="arr">↗</span> {t.delta}</span>
                  )}
                </a>
              );
            })}
          </div>
        </div>

        <div className="cloud-foot">
          <div className="cloud-legend">
            <span>
              <span className="legend-bar">
                <span style={{ background: "var(--ink-600)" }} />
                <span style={{ background: "var(--ink-700)" }} />
                <span style={{ background: "var(--ink-800)" }} />
                <span style={{ background: "var(--clay-700)" }} />
                <span style={{ background: "var(--clay-800)" }} />
              </span>
              冷 → 热
            </span>
            <span>↗ Δ 较上周</span>
          </div>
          <a href="#" className="link-arrow" onClick={(e) => e.preventDefault()}>
            浏览全部主题 <IconArrowR size={14}/>
          </a>
        </div>
      </div>
    </section>
  );
}

window.TopicCloud = TopicCloud;


// ─── journals.jsx ───────────────────────────────
// =============================================================
// Journals — high-impact entry points by journal.
// Each entry shows a mocked "cover plate" with the journal's
// serif wordmark on a muted color (oxblood / navy / clay deep
// — pulled darker so the cards still feel paper-y on the
// canvas). Below: full name, impact factor, recent count.
// =============================================================

const journalStyles = `
  .jou-grid {
    display: grid;
    grid-template-columns: repeat(6, minmax(0, 1fr));
    gap: 16px;
  }
  @media (max-width: 1200px) { .jou-grid { grid-template-columns: repeat(3, 1fr); } }
  @media (max-width: 720px)  {
    /* horizontal scroll-snap row on phone keeps density */
    .jou-grid {
      grid-template-columns: none;
      display: flex;
      gap: 12px;
      overflow-x: auto;
      scroll-snap-type: x mandatory;
      margin: 0 -20px;
      padding: 4px 20px 16px;
      scrollbar-width: none;
    }
    .jou-grid::-webkit-scrollbar { display: none; }
    .jou-card { flex: 0 0 56vw; min-width: 200px; scroll-snap-align: start; }
  }

  .jou-card {
    background: var(--bg-paper);
    border: 1px solid var(--border-default);
    border-radius: var(--radius-lg);
    overflow: hidden;
    display: flex; flex-direction: column;
    text-decoration: none;
    color: inherit;
    transition: transform var(--dur-fast) var(--ease-standard),
                box-shadow var(--dur-fast) var(--ease-standard),
                border-color var(--dur-fast);
  }
  .jou-card:hover {
    border-color: var(--ink-300);
    box-shadow: var(--shadow-xs), 0 6px 16px -10px rgba(28,25,23,0.18);
    transform: translateY(-1px);
  }

  .jou-cover {
    aspect-ratio: 3 / 4;
    position: relative;
    display: flex; align-items: center; justify-content: center;
    text-align: center;
    padding: 16px 14px;
    overflow: hidden;
  }
  .jou-cover::before {
    content: "";
    position: absolute; inset: 8px 8px 8px 8px;
    border: 1px solid currentColor;
    opacity: 0.22;
    pointer-events: none;
  }
  .jou-cover::after {
    content: "";
    position: absolute;
    inset: 0;
    pointer-events: none;
    background:
      repeating-linear-gradient(
        135deg,
        rgba(255,255,255,0.02) 0 1px,
        transparent 1px 6px
      );
    opacity: 0.4;
  }
  .jou-cover-band {
    position: absolute;
    top: 16px; left: 8px; right: 8px;
    text-align: center;
    font-family: var(--font-mono);
    font-size: 9.5px;
    letter-spacing: 0.18em;
    text-transform: uppercase;
    opacity: 0.65;
    z-index: 1;
  }
  .jou-cover-word {
    font-family: var(--font-serif);
    font-weight: 500;
    font-size: clamp(20px, 2.2vw, 26px);
    line-height: 1.05;
    letter-spacing: -0.01em;
    white-space: pre-line;
    z-index: 1;
  }
  .jou-cover-foot {
    position: absolute;
    bottom: 14px; left: 8px; right: 8px;
    text-align: center;
    font-family: var(--font-mono);
    font-size: 9px;
    letter-spacing: 0.14em;
    opacity: 0.55;
  }

  .jou-meta {
    padding: 12px 14px 14px;
    display: flex; flex-direction: column; gap: 6px;
    border-top: 1px solid var(--border-default);
    background: var(--bg-paper);
  }
  .jou-name {
    font-family: var(--font-sans);
    font-size: var(--text-sm);
    font-weight: 600;
    color: var(--fg-1);
    line-height: 1.3;
  }
  .jou-abbr {
    font-family: var(--font-mono);
    font-size: 10.5px;
    color: var(--fg-3);
    text-transform: uppercase;
    letter-spacing: 0.04em;
  }
  .jou-stats {
    display: flex; align-items: baseline; justify-content: space-between;
    gap: 8px;
    margin-top: 4px;
  }
  .jou-if {
    display: flex; flex-direction: column;
  }
  .jou-if .num {
    font-family: var(--font-serif);
    font-size: 20px;
    font-weight: 500;
    color: var(--ink-900);
    font-variant-numeric: tabular-nums;
    line-height: 1.05;
    letter-spacing: -0.01em;
  }
  .jou-if .lbl {
    font-family: var(--font-mono);
    font-size: 9.5px;
    color: var(--fg-3);
    text-transform: uppercase;
    letter-spacing: 0.06em;
  }
  .jou-week {
    text-align: right;
    font-family: var(--font-mono);
    font-size: 11px;
    color: var(--fg-2);
    font-variant-numeric: tabular-nums;
    line-height: 1.35;
  }
  .jou-week .lbl {
    font-size: 9.5px; color: var(--fg-3);
    text-transform: uppercase; letter-spacing: 0.06em;
    display: block;
  }

  .jou-foot {
    margin-top: 24px;
    display: flex; align-items: center; justify-content: space-between;
    gap: 12px; flex-wrap: wrap;
  }
  .jou-counter {
    font-family: var(--font-mono);
    font-size: var(--text-xs);
    color: var(--fg-3);
  }
  .jou-counter b { color: var(--ink-900); font-weight: 600; font-variant-numeric: tabular-nums; }
`;

function JournalCard({ j }) {
  const { bg, ink, rule } = j.coverStyle;
  return (
    <a className="jou-card" href="#" onClick={(e) => e.preventDefault()}>
      <div className="jou-cover" style={{ background: bg, color: ink }}>
        <div className="jou-cover-band">est. {j.founded}</div>
        <div className="jou-cover-word">{j.cover}</div>
        <div className="jou-cover-foot">vol · 2026</div>
      </div>
      <div className="jou-meta">
        <div className="jou-name">{j.name}</div>
        <div className="jou-abbr">{j.abbr}</div>
        <div className="jou-stats">
          <div className="jou-if">
            <span className="num">{j.impact.toFixed(1)}</span>
            <span className="lbl">影响因子</span>
          </div>
          <div className="jou-week">
            <span className="lbl">本周收录</span>
            {j.weekly}
          </div>
        </div>
      </div>
    </a>
  );
}

function Journals() {
  styleTagOnce("journals-styles", journalStyles);
  return (
    <section className="container section-pad" data-screen-label="03 Journals">
      <div className="section-head">
        <div className="lhs">
          <span className="eyebrow"><span className="leaf"><PatraMark height={16} /></span> 按期刊浏览</span>
          <h2 className="section-title">高影响力期刊</h2>
          <p className="section-sub">
            从信赖的来源切入。Patra 持续追踪 1,247 本同行评审期刊；以下为本周收录最活跃的 6 本。
          </p>
        </div>
        <div className="rhs">
          <a href="#" className="link-arrow" onClick={(e) => e.preventDefault()}>
            浏览全部 1,247 本 <IconArrowR size={14}/>
          </a>
        </div>
      </div>

      <div className="jou-grid">
        {JOURNALS.map(j => <JournalCard key={j.id} j={j} />)}
      </div>

      <div className="jou-foot">
        <div className="jou-counter">
          覆盖 <b>1,247</b> 本期刊 · 其中 <b>184</b> 本本周有新刊
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button type="button" className="btn btn-sec btn-sm">按主题筛选</button>
          <button type="button" className="btn btn-sec btn-sm">按影响因子排序</button>
        </div>
      </div>
    </section>
  );
}

window.Journals = Journals;


// ─── explore-feed.jsx ───────────────────────────────
// =============================================================
// ExploreFeed — discovery card stream with tab switcher.
// PaperCard is the workhorse. AI 速读 sits inside the card as a
// tinted callout with a 2px clay left edge — explicitly styled
// to read like a librarian's margin annotation, not part of the
// abstract.
// =============================================================

const feedStyles = `
  .feed-tabs {
    display: flex; align-items: center; gap: 4px;
    border-bottom: 1px solid var(--border-default);
    margin-bottom: 28px;
    overflow-x: auto;
    scrollbar-width: none;
  }
  .feed-tabs::-webkit-scrollbar { display: none; }
  .feed-tab {
    background: transparent;
    border: 0;
    padding: 12px 14px;
    font-family: var(--font-sans);
    font-size: var(--text-md);
    font-weight: 500;
    color: var(--fg-3);
    cursor: pointer;
    border-bottom: 2px solid transparent;
    margin-bottom: -1px;
    display: inline-flex; align-items: center; gap: 8px;
    white-space: nowrap;
    line-height: 1.3;
    transition: color var(--dur-fast), border-color var(--dur-fast);
  }
  .feed-tab:hover { color: var(--ink-900); }
  .feed-tab.is-active {
    color: var(--ink-900);
    border-bottom-color: var(--clay-500);
  }
  .feed-tab .tab-num {
    font-family: var(--font-mono);
    font-size: 11px;
    background: var(--paper-200);
    color: var(--fg-3);
    padding: 1px 5px;
    border-radius: 3px;
    font-variant-numeric: tabular-nums;
  }
  .feed-tab.is-active .tab-num {
    background: var(--clay-100); color: var(--clay-800);
  }

  .feed-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 16px;
  }
  @media (max-width: 880px) {
    .feed-grid { grid-template-columns: 1fr; gap: 14px; }
  }

  .pc {
    background: var(--bg-paper);
    border: 1px solid var(--border-default);
    border-radius: var(--radius-lg);
    padding: 20px 22px 18px;
    display: flex; flex-direction: column;
    gap: 12px;
    transition: border-color var(--dur-fast), box-shadow var(--dur-fast);
  }
  .pc:hover {
    border-color: var(--ink-300);
    box-shadow: var(--shadow-xs);
  }
  @media (max-width: 880px) {
    .pc { padding: 16px 16px 14px; gap: 10px; }
  }

  .pc-head {
    display: flex; align-items: center; justify-content: space-between;
    gap: 12px;
  }
  .pc-source {
    display: inline-flex; align-items: center; gap: 6px;
    font-family: var(--font-sans);
    font-size: 11px;
    font-weight: 500;
    color: var(--fg-2);
    padding: 2px 8px 2px 6px;
    border: 1px solid var(--border-default);
    border-radius: var(--radius-pill);
    background: #fff;
    white-space: nowrap;
    flex-shrink: 0;
  }
  .pc-source .dot {
    width: 6px; height: 6px; border-radius: 50%;
    background: var(--moss-500);
  }
  .pc-doi {
    font-family: var(--font-mono);
    font-size: 10.5px;
    color: var(--fg-3);
    letter-spacing: 0;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    min-width: 0;
  }
  @media (max-width: 540px) {
    .pc-doi { display: none; }
  }

  .pc-title {
    font-family: var(--font-serif);
    font-weight: 500;
    font-size: 21px;
    line-height: 1.22;
    letter-spacing: -0.015em;
    color: var(--fg-1);
    margin: 0;
    text-wrap: pretty;
  }
  @media (max-width: 880px) { .pc-title { font-size: 18px; } }
  .pc-title a { color: inherit; text-decoration: none; }
  .pc-title a:hover { color: var(--clay-800); text-decoration: underline; text-decoration-color: var(--clay-300); text-underline-offset: 3px; }

  .pc-meta {
    display: flex; align-items: center; gap: 10px; flex-wrap: wrap;
    font-family: var(--font-sans);
    font-size: var(--text-sm);
    color: var(--fg-3);
    line-height: 1.4;
  }
  .pc-meta > * { white-space: nowrap; }
  .pc-meta .auth { white-space: normal; }
  .pc-meta .jou {
    font-family: var(--font-serif);
    font-style: italic;
    font-weight: 500;
    color: var(--ink-800);
    font-size: 13.5px;
  }
  .pc-meta .yr { color: var(--fg-2); }
  .pc-meta .auth { color: var(--fg-2); }
  .pc-meta .auth em { font-style: italic; color: var(--fg-3); }
  .pc-meta .kind {
    font-family: var(--font-mono);
    font-size: 10px;
    color: var(--fg-3);
    background: var(--paper-200);
    padding: 1px 6px;
    border-radius: var(--radius-xs);
    text-transform: uppercase;
    letter-spacing: 0.04em;
  }
  .pc-meta .sep {
    width: 3px; height: 3px; border-radius: 50%;
    background: var(--ink-300);
    display: inline-block;
  }

  /* AI 速读 callout — the "annotation" block */
  .pc-ai {
    position: relative;
    margin-top: 2px;
    padding: 12px 14px 12px 18px;
    background: var(--clay-50);
    border: 1px solid #EBDDC7;
    border-radius: var(--radius-md);
    border-left: 2px solid var(--clay-500);
  }
  .pc-ai-head {
    display: flex; align-items: center; gap: 8px;
    margin-bottom: 6px;
    font-family: var(--font-sans);
    font-size: 10px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    color: var(--clay-800);
    flex-wrap: wrap;
    row-gap: 4px;
  }
  .pc-ai-head > * { white-space: nowrap; }
  .pc-ai-head .lbl { letter-spacing: 0.1em; }
  .pc-ai-head .leaf {
    color: var(--clay-700);
    flex-shrink: 0;
    display: inline-flex;
  }
  .pc-ai-head .auto {
    margin-left: 2px;
    font-family: var(--font-mono);
    font-weight: 400;
    font-size: 9.5px;
    color: var(--clay-700);
    letter-spacing: 0.04em;
    text-transform: none;
    padding: 0 5px;
    border: 1px solid #E9D2BC;
    border-radius: 3px;
    background: rgba(255,255,255,0.5);
  }
  .pc-ai-head .read-min {
    margin-left: auto;
    font-family: var(--font-mono);
    font-weight: 400;
    font-size: 10px;
    color: var(--clay-700);
    text-transform: none;
    letter-spacing: 0;
  }
  .pc-ai-body {
    font-family: var(--font-serif);
    font-size: 14.5px;
    line-height: 1.55;
    color: var(--ink-800);
    text-wrap: pretty;
    margin: 0;
  }

  .pc-foot {
    display: flex; align-items: center; justify-content: space-between;
    gap: 10px;
    margin-top: 4px;
    padding-top: 12px;
    border-top: 1px solid var(--border-subtle);
  }
  .pc-actions {
    display: flex; align-items: center; gap: 4px;
  }
  .pc-act {
    background: transparent;
    border: 0;
    color: var(--fg-2);
    padding: 5px 9px;
    border-radius: var(--radius-sm);
    font-family: var(--font-sans);
    font-size: var(--text-sm);
    font-weight: 500;
    cursor: pointer;
    display: inline-flex; align-items: center; gap: 5px;
    transition: background var(--dur-fast), color var(--dur-fast);
    line-height: 1.2;
  }
  .pc-act:hover { background: var(--paper-200); color: var(--ink-900); }
  .pc-act.is-on { color: var(--clay-700); }
  .pc-act.detail { color: var(--ink-900); font-weight: 600; }
  .pc-act .num { font-variant-numeric: tabular-nums; font-family: var(--font-mono); font-size: 11px; color: var(--fg-3); }

  .pc-cites {
    display: inline-flex; align-items: center; gap: 6px;
    font-family: var(--font-mono);
    font-size: 11px;
    color: var(--fg-3);
    font-variant-numeric: tabular-nums;
  }
  .pc-cites b { color: var(--ink-900); font-weight: 600; }

  @media (max-width: 540px) {
    .pc-foot { flex-direction: row; }
    .pc-actions { gap: 0; }
    .pc-act { padding: 5px 6px; }
    .pc-act .lbl { display: none; }
  }

  .feed-loadmore {
    margin-top: 28px;
    text-align: center;
  }
  .feed-empty {
    grid-column: 1 / -1;
    padding: 64px 24px;
    text-align: center;
    color: var(--fg-3);
  }
`;

const TABS = [
  { id: "trending", label: "今日热门",   icon: IconTrending },
  { id: "recent",   label: "最近更新",   icon: IconClock    },
  { id: "cited",    label: "本周高引",   icon: IconQuote    },
];

function formatAuthors(authors, total) {
  if (!authors || !authors.length) return "";
  const head = authors.slice(0, 2).join(", ");
  const extra = total > 2 ? ` 等 ${total - 2} 位作者` : "";
  return head + extra;
}

function PaperCard({ paper }) {
  const [bookmarked, setBookmarked] = React.useState(false);
  return (
    <article className="pc">
      <div className="pc-head">
        <span className="pc-source">
          <span className="dot" /> {paper.source}
        </span>
        <span className="pc-doi" title={`DOI: ${paper.doi}`}>{paper.doi}</span>
      </div>

      <h3 className="pc-title">
        <a href="#" onClick={(e) => e.preventDefault()}>{paper.title}</a>
      </h3>

      <div className="pc-meta">
        <span className="jou">{paper.journal}</span>
        <span className="sep" />
        <span className="yr">{paper.year}</span>
        <span className="sep" />
        <span className="auth">{formatAuthors(paper.authors, paper.authorCount)}</span>
        {paper.kind && <span className="kind">{paper.kind}</span>}
      </div>

      <div className="pc-ai">
        <div className="pc-ai-head">
          <span className="leaf"><PatraMark height={20} /></span>
          <span className="lbl">AI 速读</span>
          <span className="auto">自动生成</span>
          <span className="read-min">≈ {paper.readMin} 分钟原文</span>
        </div>
        <p className="pc-ai-body">{paper.ai}</p>
      </div>

      <div className="pc-foot">
        <div className="pc-actions">
          <button className="pc-act detail" type="button">
            <span className="lbl">详情</span> <IconChevR size={14}/>
          </button>
          <button
            className={`pc-act ${bookmarked ? "is-on" : ""}`}
            type="button"
            onClick={() => setBookmarked(b => !b)}
            aria-pressed={bookmarked}
          >
            {bookmarked ? <IconStarFill size={14}/> : <IconStar size={14}/>}
            <span className="lbl">收藏</span>
            <span className="num">{(paper.bookmarks + (bookmarked ? 1 : 0)).toLocaleString()}</span>
          </button>
          <button className="pc-act" type="button">
            <IconChat size={14}/> <span className="lbl">评论</span>
          </button>
          <button className="pc-act" type="button" aria-label="分享">
            <IconShare size={14}/>
          </button>
        </div>
        <div className="pc-cites">
          <IconQuote size={12}/> <b>{paper.cites.toLocaleString()}</b> 引用
        </div>
      </div>
    </article>
  );
}

function ExploreFeed() {
  styleTagOnce("feed-styles", feedStyles);
  const [tab, setTab] = React.useState("trending");
  const items = FEED[tab] || [];

  return (
    <section className="container section-pad" data-screen-label="04 ExploreFeed">
      <div className="section-head">
        <div className="lhs">
          <span className="eyebrow"><span className="leaf"><PatraMark height={16} /></span> 文献流</span>
          <h2 className="section-title">值得读一读的文献</h2>
          <p className="section-sub">
            每篇都带一段 AI 速读 —— 由 Patra 在采集时生成，仅作为线索，不能替代阅读原文。
          </p>
        </div>
      </div>

      <div className="feed-tabs" role="tablist">
        {TABS.map(t => {
          const Ic = t.icon;
          const count = FEED[t.id]?.length || 0;
          const active = tab === t.id;
          return (
            <button
              key={t.id}
              role="tab"
              aria-selected={active}
              className={`feed-tab ${active ? "is-active" : ""}`}
              onClick={() => setTab(t.id)}
              type="button"
            >
              <Ic size={15}/> {t.label}
              <span className="tab-num">{count}</span>
            </button>
          );
        })}
      </div>

      <div className="feed-grid">
        {items.map(p => <PaperCard key={p.id} paper={p} />)}
        {items.length === 0 && (
          <div className="feed-empty">暂无内容</div>
        )}
      </div>

      <div className="feed-loadmore">
        <button type="button" className="btn btn-sec">
          展开更多 <IconChevD size={14}/>
        </button>
      </div>
    </section>
  );
}

window.PaperCard = PaperCard;
window.ExploreFeed = ExploreFeed;


// ─── footer.jsx ───────────────────────────────
// =============================================================
// Footer — single horizontal line. No marketing prose.
// =============================================================

const footerStyles = `
  .ft {
    border-top: 1px solid var(--border-default);
    background: var(--paper-100);
    padding: 22px 0 26px;
    margin-top: 24px;
  }
  .ft-row {
    display: flex; align-items: center; justify-content: space-between;
    gap: 16px;
    flex-wrap: wrap;
    font-family: var(--font-sans);
    font-size: var(--text-sm);
    color: var(--fg-3);
  }
  .ft-brand {
    display: inline-flex; align-items: center; gap: 8px;
    color: var(--fg-2);
    font-family: var(--font-serif);
    font-weight: 500;
    font-size: 16px;
    letter-spacing: -0.01em;
  }
  .ft-brand .mark {
    color: var(--clay-900);
    display: inline-flex;
  }
  .ft-nav { display: flex; gap: 4px; flex-wrap: wrap; }
  .ft-link {
    color: var(--fg-2);
    text-decoration: none;
    padding: 4px 8px;
    border-radius: var(--radius-sm);
    display: inline-flex; align-items: center; gap: 5px;
    transition: color var(--dur-fast), background var(--dur-fast);
  }
  .ft-link:hover { color: var(--ink-900); background: var(--paper-200); }
  .ft-meta {
    font-family: var(--font-mono);
    font-size: 10.5px;
    color: var(--fg-4);
    text-transform: uppercase;
    letter-spacing: 0.06em;
  }
`;

function Footer() {
  styleTagOnce("footer-styles", footerStyles);
  return (
    <footer className="ft" data-screen-label="05 Footer" id="about">
      <div className="container ft-row">
        <div className="ft-brand">
          <span className="mark"><PatraMark height={22} /></span> Patra
        </div>
        <nav className="ft-nav" aria-label="页脚">
          <a className="ft-link" href="#" onClick={(e) => e.preventDefault()}>数据源</a>
          <a className="ft-link" href="#" onClick={(e) => e.preventDefault()}>关于</a>
          <a className="ft-link" href="#" onClick={(e) => e.preventDefault()}>更新日志</a>
          <a className="ft-link" href="#" onClick={(e) => e.preventDefault()}>
            GitHub <IconExternal size={12}/>
          </a>
        </nav>
        <div className="ft-meta">
          v2.4 · 索引快照 17:42 UTC+8
        </div>
      </div>
    </footer>
  );
}

window.Footer = Footer;

