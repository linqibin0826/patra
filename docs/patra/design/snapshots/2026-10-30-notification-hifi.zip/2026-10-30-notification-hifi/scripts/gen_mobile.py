# 由桌面画板生成手机薄包装板（X-M.dc.html）：dc-import 桌面板 + narrow，透传桌面板的全部 Tweaks。
# 用法：python3 gen_mobile.py <project 目录>
# v0.15：python3 gen_mobile.py <project 目录> [桌面板名…]，不给名字就生成全部五块。
# v0.16：默认生成 Inbox / Notify / Unsub 三块。
import html
import json
import os
import re
import sys

HEAD = '''<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>{title}</title>
<script src="./support.js"></script>
<link rel="stylesheet" href="patra.css">
</head>
<body>
<x-dc>
<helmet>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500&amp;family=Inter:opsz,wght@14..32,400..600&amp;family=Newsreader:ital,opsz,wght@0,6..72,400..600;1,6..72,400..500&amp;family=Noto+Serif+SC:wght@400;500&amp;display=swap">
<style>
body{{margin:0}}
</style>
</helmet>
<div style="width: 375px; min-height: 812px; background: var(--bg-canvas); overflow-x: clip; position: relative">
<dc-import name="{name}" {attrs} narrow="{{{{yes}}}}" hint-size="375px,{h}px"></dc-import>
</div>
</x-dc>
<script type="text/x-dc" data-dc-script data-props='{props}'>
class Component extends DCLogic {{
  renderVals() {{
    return {{
      yes: true,
      v: {{
{vals}
      }},
    }};
  }}
}}
</script>
</body>
</html>
'''


def kebab(k):
    return re.sub(r'([A-Z])', lambda m: '-' + m.group(1).lower(), k)


def make(root, desk, out, title, h, skip=()):
    src = open(os.path.join(root, desk + '.dc.html'), encoding='utf-8').read()
    props = json.loads(html.unescape(re.search(r"data-props='(.*?)'>", src, re.S).group(1)))
    keep = {k: v for k, v in props.items() if not k.startswith('$') and v.get('editor') and k != 'narrow' and k not in skip}
    keep_out = dict(keep)
    keep_out['$preview'] = {'width': 375, 'height': h}
    attrs = ' '.join('%s="{{v.%s}}"' % (kebab(k), k) for k in keep)
    vals = ',\n'.join('        %s: this.props.%s ?? %s' % (k, k, json.dumps(v['default'], ensure_ascii=False)) for k, v in keep.items())
    pj = json.dumps(keep_out, ensure_ascii=False).replace("'", '&#39;')
    with open(os.path.join(root, out + '.dc.html'), 'w', encoding='utf-8') as f:
        f.write(HEAD.format(title=title, name=desk, attrs=attrs, h=h, props=pj, vals=vals))


if __name__ == '__main__':
    root = sys.argv[1]
    which = sys.argv[2:] or ['Inbox', 'Notify', 'Unsub']
    T = {
        'Inbox': ('Inbox-M', '提醒页（移动）', 1300),
        'Notify': ('Notify-M', '设置 · 通知（移动）', 1900),
        'Unsub': ('Unsub-M', '退订落地页（移动）', 812),
        'Mail': ('Mail-M', '提醒邮件 · 手机邮件客户端', 1460),
        'Digest': ('Digest-M', '每日汇总邮件 · 手机邮件客户端', 2040),
    }
    for d in which:
        out, title, h = T[d]
        make(root, d, out, title, h)
