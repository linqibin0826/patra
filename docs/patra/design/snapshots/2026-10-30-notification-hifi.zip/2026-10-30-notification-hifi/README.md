# v0.16 通知中心 · 画板快照（PAP-140）

持久画布：https://claude.ai/artifact/8Ff2pvLjosq8sfdRV4PDBP　设计简报：`patra-portal/docs/design-briefs/v0.16/notification.md`（简报页 https://claude.ai/artifact/JoW5Xq7uqqKjG6riHJGBYN 由它生成）

| 目录 | 内容 |
|------|------|
| `project/` | 画布源文件（2026-10-30 用户确认后从画布读回，版本 1793373874-aa18）：`canvas.json`（5 页 11 块）；提醒页 `Inbox` / `Inbox-M`（「有帮助」标签与合并条目、铃铛不含有帮助、实时推送进来的新条目）；设置 › 通知 `Notify` / `Notify-M`（「回复我的」「@ 我的」各三档即时保存、有帮助只在站内、账号安全邮件说明、邮箱未验证提示）；退订落地页 `Unsub` / `Unsub-M`（先确认再退订：已退订这一类、已关闭全部、已经退订过、链接无效、提交失败）；提醒邮件 `Mail` / `Mail-M`（离站时逐条：单条回复 / 评论经验 / @，同一类到点多条合成一封）与每日汇总 `Digest` / `Digest-M`（两节、只有一类、超过 10 条），邮件正文照 identity `layout.html` 的 table + 行内样式，桌面板是 600px 卡片、`-M` 是 375 宽的手机邮件客户端，板顶「信封」区是主题、预览文字与邮件头；沿用 v0.14 不变的 `Nav`；`patra.css`；`ds/patra/tokens.json` |
| `assets/` | 画板里以 `/_blob/<id>` 引用的素材：品牌标记（`4914ffc26db57baff3e374df628025a4`，从 v0.15 画布复制）、墨底叶脉（`cb76cec0e84e223c365fa3a85dd205e6`，从 v0.12 画布复制）。本机自查副本里写的是占位 `__MARK__` / `__VEIN__` |
| `scripts/` | `gen_tokens.py` 把 `patra-portal/src/styles/tokens.css` 的 `:root` 与组件类拼成 `project/patra.css`（`python3 <scripts>/gen_tokens.py <scripts>/components.css,<scripts>/components-v014.css,<scripts>/components-v015.css,<scripts>/components-v016.css <project>/patra.css <tokens.css>`）；`components-v016.css` 是本版新增的类；`gen_mobile.py` 由桌面板生成手机薄包装板（`python3 gen_mobile.py <project> [Inbox Notify Unsub Mail Digest]`）；`brief-page.template.html` + `build_brief_page.py` 生成简报 Artifact 页 |
| `harness/` | 本机自查：`support.js` 是最小运行时垫片（同 v0.15）；`shoot.mjs` 用 portal 自带的 Playwright 按清单截图（`PORTAL_PKG=<装过依赖的 patra-portal/package.json> node <harness>/shoot.mjs <快照目录> <shots.json> <输出目录> [offline]`），素材表已加本版两个 id；`debug.mjs` 打印页面报错的堆栈 |

场景在每块画板的 Tweaks 里切：「场景」是数据与身份，「服务器返回」模拟接口结果，「版式」的窄屏只给桌面板用。状态 ID 与简报 §4 一一对应。示例人物 A = 陈宇、B = 王立、C = 林知远、D = 周敏，「现在」是 10 月 30 日 16:00，汇总在 10 月 31 日 8:00 发出。

邮件画板的交接：画板里的邮件正文可以直接对照搬成 Thymeleaf 模板（`{{…}}` 换模板变量、`<sc-for>` 换 `th:each`、`narrow` 分支的行内值就是 `@media (max-width: 520px)` 那一组）。`patra.css` 下半段的组件类是画板专用的，落地时照门户现有组件与 Tailwind 写法实现，不照搬类名。

2026-10-30 用户确认画板与简报 §10：逐条合并只在同一类里；每日汇总自成一个退订类别；退订页先确认再生效（邮件客户端的一键退订直接生效）；邮箱未验证不发提醒邮件；有帮助条目的名字与头像写最近一位点的人；单条邮件摘录 300 字、列表每条 140 字、一封最多列 10 条（站内仍 120 字）。
