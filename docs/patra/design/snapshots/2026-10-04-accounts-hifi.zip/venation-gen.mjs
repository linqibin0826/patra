import { generateVenation } from "/Users/linqibin/Projects/Products/patra/patra-portal/src/lib/venation.ts";
import { writeFileSync } from "node:fs";
const STROKE = { margin: [1.1, 0.9], midrib: [2, 0.95], secondary: [1, 0.8], loop: [0.75, 0.6], tertiary: [0.5, 0.45] };
const TONE = { paper: ["#97441e", "#1c1917"], inverse: ["#dc9d6a", "#fbf8f2"] };
const { width, height, paths } = generateVenation({});
for (const [tone, [base, tip]] of Object.entries(TONE)) {
  const body = paths.map((p) => `<path d="${p.d}" stroke-width="${STROKE[p.kind][0]}" opacity="${STROKE[p.kind][1]}" vector-effect="non-scaling-stroke"/>`).join("");
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" fill="none"><defs><linearGradient id="g" gradientUnits="userSpaceOnUse" x1="0" y1="${height}" x2="0" y2="0"><stop offset="0" stop-color="${base}"/><stop offset="1" stop-color="${tip}"/></linearGradient></defs><g stroke="url(#g)" stroke-linecap="round" stroke-linejoin="round">${body}</g></svg>`;
  writeFileSync(new URL(`./assets/venation-${tone}.svg`, import.meta.url), svg);
  console.log(tone, paths.length, "paths", svg.length, "bytes");
}
