#!/usr/bin/env python3
"""生成 Patra v0.8 账号登录 hi-fi（PAP-61）的全部 .dc.html 画板、canvas.json 与 patra.css。

输入：设计简报 patra-portal/docs/design-briefs/v0.8/accounts.md（PAP-60）。
token 直接取自 patra-portal/src/styles/tokens.css，画板里一律写 var(--token)，不写裸色值。
用法：python3 gen.py            生成 project/
      python3 gen.py --preview  另生成 preview/（素材指向本地文件，仅供本机渲染检查）
注意：project/canvas.json 只在不存在时生成。画布发布后索引由画布编辑器接管，快照里的那份是画布上的最终版本。
"""
import json
import os
import re
import sys
from datetime import datetime, timezone
from html.parser import HTMLParser

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "project")
# token 源：默认取本机 portal 仓库，换机器时用环境变量 PATRA_TOKENS_CSS 指到 patra-portal/src/styles/tokens.css
TOKENS_SRC = os.environ.get(
    "PATRA_TOKENS_CSS", "/Users/linqibin/Projects/Products/patra/patra-portal/src/styles/tokens.css"
)
DS_ADDRESS = "https://claude.ai/code/artifact/825d67c8-7178-432b-b798-4b6563b313b0"
DS_VERSION = "1791110666-aaf2"

# 画布上的素材（已上传）：品牌标记是 portal 的 public/brand/patra-mark.svg；
# 叶脉由 portal 的 src/lib/venation.ts 生成（seed 默认 11），描边渐变两端色与 <Venation tone> 一致
MARK = "/_blob/62141f001d9677d8d530452e62eaeceb"
VEN_PAPER = "/_blob/f628dc564499e51c54c0b9bd76992555"
VEN_INVERSE = "/_blob/56e94536e0c132977b72b8a092671077"
LOCAL_ASSETS = {
    MARK: "../assets/patra-mark.svg",
    VEN_PAPER: "../assets/venation-paper.svg",
    VEN_INVERSE: "../assets/venation-inverse.svg",
}

FONT_LINK = (
    '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?'
    "family=IBM+Plex+Mono:wght@400;500;600"
    "&family=Inter:opsz,wght@14..32,400..600"
    "&family=Newsreader:ital,opsz,wght@0,6..72,400..600;1,6..72,400..600"
    "&family=Noto+Serif+SC:wght@400;500;600"
    '&display=swap">'
)

SANS = "var(--patra-font-sans)"
SERIF = "var(--patra-font-serif)"
MONO = "var(--patra-font-mono)"

EMAIL = "chen.yu@example.com"
EMAIL_LONG = "postdoctoral.researcher.zhang@cardiovascular-research.university-hospital.example.org"
EMAIL_DIGIT = "2024cohort@example.org"
EMAIL_BAD = "chen.yu@example"
PW = "leaf-and-vein-26"
PW_SHORT = "abc123"
PW_COMMON = "password123"
PW_LONG = "the-quick-brown-fox-jumps-over-the-lazy-dog-and-keeps-running-2026"
assert len(PW_LONG) > 64 and len(PW) >= 8 and len(PW_SHORT) < 8

# ============================================================
# patra.css：token（取自 portal）+ 随状态变化的组件样式
# ============================================================
COMPONENT_CSS = r"""
/* ============================================================
   以下是 v0.8 账号登录设计稿的组件样式。
   只放「随状态变化」的属性（hover / focus / 错误 / 只读 / 禁用）；布局与排版写在画板的行内样式里。
   .is-* 是把伪类状态画成静态画面用的修饰类，落地时对应真实的 :hover / :focus-within / aria-* / :disabled。
   每条规则后的注释是对应的 Tailwind 写法。
   ============================================================ */
*, *::before, *::after { box-sizing: border-box; }
body { margin: 0; }

/* 页面根：纸色 + 纸纹（同 globals.css 的 body） */
.pt-root {
  background-color: var(--bg-canvas);
  background-image: var(--grain);
  background-blend-mode: overlay;
  color: var(--fg-1);
  font-family: var(--patra-font-sans);
  font-size: var(--text-base);
  line-height: var(--leading-normal);
  font-feature-settings: "ss01", "cv11", "cv02";
  -webkit-font-smoothing: antialiased;
  text-rendering: optimizelegibility;
}
.pt-root ::selection { background: var(--selection-bg); color: var(--selection-fg); }

/* 链接下划线自左绘出（同 globals.css 的 @utility link-draw） */
.link-draw {
  background-image: linear-gradient(currentColor, currentColor);
  background-position: 0 100%;
  background-repeat: no-repeat;
  background-size: 0% 1px;
  padding-bottom: 1px;
  transition: background-size var(--dur-slow) var(--ease-out-expo), color var(--dur-normal) var(--ease-out-expo);
}
.link-draw:hover, .link-draw:focus-visible, .link-draw.is-hover, .link-draw.is-drawn { background-size: 100% 1px; }

/* 非文本可交互元素统一焦点环（同 globals.css） */
:where(a[href], button, [tabindex]):focus-visible, .is-focus-ring { outline: none; box-shadow: var(--ring-focus); }

/* 文字链接：正文里的「注册」「登录」「去登录」 —— text-link hover:text-link-hover */
.pt-link { color: var(--link); }
.pt-link:hover, .pt-link.is-hover { color: var(--link-hover); }

/* 次级文字入口：「返回」「关于」、导航项 —— text-fg-2 hover:text-ink-900 */
.pt-navlink { color: var(--fg-2); transition: color 150ms cubic-bezier(0.4, 0, 0.2, 1); }
.pt-navlink:hover, .pt-navlink.is-hover, .pt-navlink[aria-current="page"] { color: var(--ink-900); }

/* 主按钮（portal-ui 的 btnPrimary） */
.pt-btn-primary {
  border-color: var(--action-primary);
  background: var(--action-primary);
  color: var(--fg-on-clay);
  cursor: pointer;
  transition: background-color 200ms var(--ease-out-expo), border-color 200ms var(--ease-out-expo);
}
.pt-btn-primary:not(:disabled):hover, .pt-btn-primary.is-hover { border-color: var(--action-primary-hover); background: var(--action-primary-hover); }
/* 按下只换底色，描边停在 hover 色（同 btnPrimary：not-disabled:active:bg-action-primary-press） */
.pt-btn-primary:not(:disabled):active, .pt-btn-primary.is-press { background: var(--action-primary-press); border-color: var(--action-primary-hover); }

/* 次按钮（portal-ui 的 btnSecondary）：导航栏「登录」、移动菜单账号块 */
.pt-btn-secondary {
  border-color: var(--border-default);
  background: var(--paper-50);
  color: var(--fg-1);
  cursor: pointer;
  transition: background-color 200ms var(--ease-out-expo), border-color 200ms var(--ease-out-expo);
}
.pt-btn-secondary:not(:disabled):hover, .pt-btn-secondary.is-hover { border-color: var(--border-hover); background: var(--paper-200); }
.pt-btn-secondary:not(:disabled):active, .pt-btn-secondary.is-press { border-color: var(--border-hover); background: var(--paper-200); }
/* 按下下沉 1px 只在未要求减弱动效时发生 —— motion-safe:not-disabled:active:translate-y-px */
@media (prefers-reduced-motion: no-preference) {
  .pt-btn-primary, .pt-btn-secondary { transition: background-color 200ms var(--ease-out-expo), border-color 200ms var(--ease-out-expo), translate 200ms var(--ease-out-expo); }
  .pt-btn-primary:not(:disabled):active, .pt-btn-primary.is-press, .pt-btn-secondary:not(:disabled):active, .pt-btn-secondary.is-press { translate: 0 1px; }
}

/* 禁用：按钮 55% 不透明度，不响应 hover 与按下 —— disabled:cursor-not-allowed disabled:opacity-55 */
.pt-btn-primary:disabled, .pt-btn-secondary:disabled, .pt-menuitem:disabled { cursor: not-allowed; opacity: 0.55; }

/* 输入井（FormField / PasswordInput 的外框；与 PaperSearchBar 的内凹检索框同一套）
   border-border-strong bg-bg-elevated shadow-inset hover:border-ink-500
   focus-within:border-border-focus focus-within:ring-4 ring-clay-500/15（光晕与 Composer 相同） */
.pt-field {
  border-color: var(--border-strong);
  background: var(--bg-elevated);
  box-shadow: var(--shadow-inset);
  transition: border-color 200ms cubic-bezier(0.4, 0, 0.2, 1), box-shadow 200ms cubic-bezier(0.4, 0, 0.2, 1), background-color 200ms cubic-bezier(0.4, 0, 0.2, 1);
}
.pt-field:hover, .pt-field.is-hover { border-color: var(--ink-500); }
.pt-field:focus-within, .pt-field.is-focus { border-color: var(--border-focus); box-shadow: var(--shadow-inset), 0 0 0 4px rgba(206, 106, 55, 0.15); }
/* 错误：has-[[aria-invalid=true]]:border-status-danger；错误态下聚焦换成 ring-rust-500/15 */
.pt-field.is-invalid, .pt-field.is-invalid:hover { border-color: var(--status-danger); }
.pt-field.is-invalid:focus-within, .pt-field.is-invalid.is-focus { border-color: var(--status-danger); box-shadow: var(--shadow-inset), 0 0 0 4px rgba(178, 58, 46, 0.15); }
/* 只读（提交中）：has-[:read-only]:border-border-default has-[:read-only]:bg-bg-sunken has-[:read-only]:shadow-none */
.pt-field.is-readonly, .pt-field.is-readonly:hover { border-color: var(--border-default); background: var(--bg-sunken); box-shadow: none; }
.pt-field.is-readonly input { color: var(--fg-2); }
.pt-field input::placeholder { color: var(--fg-4); }
/* 浏览器自动填充后保持输入面底色，不出现浏览器自带的黄 / 蓝底 */
.pt-field input:-webkit-autofill {
  -webkit-box-shadow: 0 0 0 1000px var(--bg-elevated) inset;
  -webkit-text-fill-color: var(--ink-900);
  caret-color: var(--ink-900);
}

/* 输入框内的图标按钮：密码显示 / 隐藏（配色同检索框的清除按钮；图标 15px、描边 2）—— text-fg-3 hover:bg-paper-200 hover:text-ink-900 */
.pt-iconbtn { background: transparent; color: var(--fg-3); cursor: pointer; transition: background-color 150ms cubic-bezier(0.4, 0, 0.2, 1), color 150ms cubic-bezier(0.4, 0, 0.2, 1); }
.pt-iconbtn:hover, .pt-iconbtn.is-hover { background: var(--paper-200); color: var(--ink-900); }

/* 导航栏「快速检索」（现有 TopNav） */
.pt-quick { border-color: var(--border-default); background: var(--paper-50); color: var(--fg-2); cursor: pointer; transition: border-color 150ms cubic-bezier(0.4, 0, 0.2, 1), color 150ms cubic-bezier(0.4, 0, 0.2, 1); }
.pt-quick:hover { border-color: var(--border-hover); color: var(--ink-900); }
.pt-quick-kbd { border-color: var(--border-subtle); transition: border-color 150ms cubic-bezier(0.4, 0, 0.2, 1); }
.pt-quick:hover .pt-quick-kbd { border-color: var(--border-default); }
.pt-ghost { background: transparent; color: var(--ink-900); cursor: pointer; }
.pt-ghost:hover { background: var(--paper-200); }

/* 圆形标识（NavAccount 登录态）：bg-ink-900 text-paper-50 hover:bg-ink-800 aria-expanded:bg-ink-800 */
.pt-avatar { background: var(--ink-900); color: var(--paper-50); cursor: pointer; transition: background-color 150ms cubic-bezier(0.4, 0, 0.2, 1); }
.pt-avatar:hover, .pt-avatar.is-hover, .pt-avatar[aria-expanded="true"] { background: var(--ink-800); }

/* 菜单项（新增原语 menu）：高亮（悬停或方向键）用 bg-bg-sunken —— data-highlighted:bg-bg-sunken */
.pt-menuitem { background: transparent; color: var(--fg-1); cursor: pointer; transition: background-color 150ms cubic-bezier(0.4, 0, 0.2, 1); }
.pt-menuitem:not(:disabled):hover, .pt-menuitem.is-hover { background: var(--bg-sunken); }

/* 骨架占位（现有 loading.tsx 的 Block；落地时带 shimmer） */
.pt-skel { background: var(--paper-200); border-radius: var(--radius-lg); }

/* 专注布局：窗口不足 880px 时收掉品牌面板，只留表单 —— max-[880px]:hidden */
@media (max-width: 880px) { .pt-auth-panel { display: none !important; } }
"""


def build_css():
    with open(TOKENS_SRC, encoding="utf-8") as f:
        tokens = f.read()
    # next/font 注入的字体变量在画布里不存在，换成 Google Fonts 的字体名
    for var, family in {
        "var(--font-inter)": '"Inter"',
        "var(--font-newsreader)": '"Newsreader"',
        '"Noto Serif SC Variable"': '"Noto Serif SC"',
        "var(--font-plex-mono)": '"IBM Plex Mono"',
    }.items():
        tokens = tokens.replace(var, family)
    assert "var(--font-" not in tokens
    head = (
        "/* 本文件上半段原样取自 patra-portal/src/styles/tokens.css（只把 next/font 的字体变量换成字体名）；\n"
        "   下半段是 v0.8 账号登录设计稿的组件样式。画板里的颜色、字号、圆角、阴影一律引用这里的 token。 */\n"
    )
    return head + tokens + COMPONENT_CSS


# ============================================================
# 基础片段
# ============================================================
ICONS = {
    "arrow-left": '<path d="m12 19-7-7 7-7"></path><path d="M19 12H5"></path>',
    "eye": '<path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"></path><circle cx="12" cy="12" r="3"></circle>',
    "eye-off": '<path d="M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49"></path><path d="M14.084 14.158a3 3 0 0 1-4.242-4.242"></path><path d="M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143"></path><path d="m2 2 20 20"></path>',
    "circle-alert": '<circle cx="12" cy="12" r="10"></circle><line x1="12" x2="12" y1="8" y2="12"></line><line x1="12" x2="12.01" y1="16" y2="16"></line>',
    "log-out": '<path d="m16 17 5-5-5-5"></path><path d="M21 12H9"></path><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>',
    "search": '<path d="m21 21-4.34-4.34"></path><circle cx="11" cy="11" r="8"></circle>',
    "menu": '<path d="M4 5h16"></path><path d="M4 12h16"></path><path d="M4 19h16"></path>',
    "x": '<path d="M18 6 6 18"></path><path d="m6 6 12 12"></path>',
    "circle-check": '<circle cx="12" cy="12" r="10"></circle><path d="m16 9-5.5 5.5L8 12"></path>',
    "arrow-up-right": '<path d="M7 7h10v10"></path><path d="M7 17 17 7"></path>',
}


def icon(name, size=16, sw=2, style=""):
    """Lucide 图标（路径取自 lucide-react），颜色跟随 currentColor。"""
    st = "flex-shrink:0" + (f"; {style}" if style else "")
    return (
        f'<svg width="{size}" height="{size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" '
        f'stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" '
        f'style="{st}">{ICONS[name]}</svg>'
    )


def esc(s):
    return s.replace("&", "&amp;").replace('"', "&quot;").replace("<", "&lt;").replace(">", "&gt;")


def dash(text):
    """破折号交给中文字体渲染（同 CjkDashText）。"""
    return text.replace("——", '<span style="font-family:var(--patra-font-cjk-sans); letter-spacing:0">——</span>')


def brand(sub=True):
    """导航栏左侧那一组：BrandMark 9 × 35 + 字标 + 等宽副标。"""
    sub_html = (
        f'<span style="border-left:1px solid var(--border-strong); padding-left:10px; font-family:{MONO}; '
        'font-size:var(--text-3xs); letter-spacing:var(--tracking-caps); color:var(--fg-3); white-space:nowrap">医学文献门户</span>'
        if sub
        else ""
    )
    return (
        '<a href="#" aria-label="Patra 首页" style="display:inline-flex; align-items:center; gap:10px; color:var(--ink-900); text-decoration:none">'
        f'<img src="{MARK}" alt="" width="9" height="35" style="display:block; width:9px; height:35px; flex-shrink:0">'
        f'<span style="font-family:{SERIF}; font-size:var(--text-2xl); line-height:1; font-weight:500; letter-spacing:var(--tracking-tight)">Patra</span>'
        f"{sub_html}</a>"
    )


def back_link(href, touch=False, extra_cls=""):
    pad = "12px 0" if touch else "8px 0"
    return (
        f'<a href="{href}" class="pt-navlink{extra_cls}" style="display:inline-flex; align-items:center; gap:6px; padding:{pad}; '
        'font-size:var(--text-sm); line-height:20px; font-weight:500; text-decoration:none">'
        f'{icon("arrow-left", 14, 1.75)}<span class="link-draw">返回</span></a>'
    )


def field(fid, label, *, kind="text", value="", placeholder="", hint="", error="", error_html="",
          state="", toggle=False, shown=False, autocomplete="", readonly=False, touch=False,
          toggle_cls=""):
    """FormField：标签 + 输入井 + 常驻提示 / 错误文案。错误出现时替换常驻提示。"""
    invalid = bool(error or error_html)
    cls = ["pt-field"]
    if invalid:
        cls.append("is-invalid")
    if readonly:
        cls.append("is-readonly")
    if state:
        cls.append(state)
    itype = "text" if (kind == "password" and shown) else kind
    attrs = [f'id="{fid}"', f'name="{fid}"', f'type="{itype}"']
    if value:
        attrs.append(f'value="{esc(value)}"')
    if placeholder:
        attrs.append(f'placeholder="{esc(placeholder)}"')
    if autocomplete:
        attrs.append(f'autocomplete="{autocomplete}"')
    if kind != "text":
        attrs.append('spellcheck="false"')
    if readonly:
        attrs.append('readonly="true"')
    if invalid:
        attrs.append('aria-invalid="true"')
        attrs.append(f'aria-describedby="{fid}-error"')
    elif hint:
        attrs.append(f'aria-describedby="{fid}-hint"')
    fsize = "var(--text-lg)" if touch else "var(--text-md)"
    input_html = (
        f'<input {" ".join(attrs)} style="flex:1 1 0; min-width:0; height:100%; padding:0; border:0; outline:0; '
        f'background:transparent; font-family:inherit; font-size:{fsize}; line-height:24px; color:var(--ink-900)">'
    )
    toggle_html = ""
    pad = "0 16px"
    if toggle:
        lab, ic = ("隐藏密码", "eye-off") if shown else ("显示密码", "eye")
        size = 44 if touch else 32
        pad = "0 2px 0 16px" if touch else "0 8px 0 16px"
        toggle_html = (
            f'<button type="button" class="pt-iconbtn{toggle_cls}" aria-label="{lab}" '
            f'style="display:inline-flex; align-items:center; justify-content:center; flex-shrink:0; width:{size}px; height:{size}px; '
            f'padding:0; border:0; border-radius:var(--radius-pill)">{icon(ic, 15)}</button>'
        )
    below = ""
    if invalid:
        msg = error_html or esc(error)
        below = (
            f'<p id="{fid}-error" style="margin:0; display:flex; align-items:flex-start; gap:6px; font-size:var(--text-sm); '
            f'line-height:20px; color:var(--status-danger)">{icon("circle-alert", 14, 2, "margin-top:3px")}<span>{msg}</span></p>'
        )
    elif hint:
        below = f'<p id="{fid}-hint" style="margin:0; font-size:var(--text-sm); line-height:20px; color:var(--fg-3)">{esc(hint)}</p>'
    return (
        '<div style="display:flex; flex-direction:column; gap:8px; min-width:0">'
        f'<label for="{fid}" style="font-size:var(--text-sm); line-height:20px; font-weight:500; color:var(--fg-1)">{label}</label>'
        f'<div class="{" ".join(cls)}" style="display:flex; align-items:center; gap:4px; height:48px; padding:{pad}; '
        f'border-width:1px; border-style:solid; border-radius:var(--radius-xl)">{input_html}{toggle_html}</div>'
        f"{below}</div>"
    )


def alert(text):
    """FormAlert：表单级提示条（本版只有错误一种语气）。"""
    return (
        '<div role="alert" style="display:flex; align-items:flex-start; gap:10px; padding:12px 14px; '
        'border-radius:var(--radius-lg); background:var(--status-danger-bg); color:var(--fg-1); '
        'font-size:var(--text-base); line-height:20px">'
        f'{icon("circle-alert", 16, 2, "margin-top:2px; color:var(--status-danger)")}'
        f'<span style="min-width:0">{text}</span></div>'
    )


def submit_btn(label, disabled=False, extra_cls="", reason=""):
    """主按钮：btnPrimary + btnBlock。"""
    dis = f' disabled="true" aria-disabled="true" title="{reason}"' if disabled else ""
    return (
        f'<button type="submit" class="pt-btn-primary{extra_cls}"{dis} style="display:flex; align-items:center; justify-content:center; '
        'gap:6px; width:100%; padding:12px 16px; border-width:1px; border-style:solid; border-radius:var(--radius-pill); '
        f'font-family:inherit; font-size:var(--text-base); line-height:1.5; font-weight:600; white-space:nowrap">{label}</button>'
    )


def switch_line(prefix, label, href, touch=False, extra_cls=""):
    pad = "padding:12px 0; margin:-12px 0; display:inline-block; " if touch else ""
    return (
        f'<p style="margin:0; font-size:var(--text-base); line-height:20px; color:var(--fg-2)">{prefix}'
        f'<a href="{href}" class="pt-link{extra_cls}" style="{pad}font-weight:500; text-decoration:none"><span class="link-draw{" is-hover" if "is-hover" in extra_cls else ""}">{label}</span></a></p>'
    )


def form_head(title, sub):
    return (
        f'<h1 style="margin:0; font-family:{SERIF}; font-size:var(--text-display-3); line-height:var(--leading-heading); '
        f'font-weight:500; letter-spacing:var(--tracking-tight); color:var(--fg-1)">{title}</h1>'
        f'<p style="margin:var(--space-3) 0 0; font-size:var(--text-md); line-height:var(--leading-relaxed); color:var(--fg-2)">{sub}</p>'
    )


# ============================================================
# 登录 / 注册表单
# ============================================================
def login_form(st, touch, links):
    sub = st.get("submitting", False)
    fe, fp = dict(st.get("f_email", {})), dict(st.get("f_pw", {}))
    body = [form_head("登录", "用邮箱和密码登录 Patra")]
    gap_after_head = "var(--space-8)"
    alert_html = ""
    if st.get("alert"):
        gap_after_head = "var(--space-6)"
        alert_html = f'<div style="margin-bottom:var(--space-5)">{alert(st["alert"])}</div>'
    fields = (
        field("email", "邮箱", kind="email", placeholder="name@example.com", autocomplete="username",
              readonly=sub, touch=touch, **fe)
        + field("password", "密码", kind="password", toggle=True, autocomplete="current-password",
                readonly=sub, touch=touch, **fp)
    )
    body.append(
        f'<div style="margin-top:{gap_after_head}">{alert_html}'
        '<form onSubmit="{{ noSubmit }}" style="display:flex; flex-direction:column; gap:var(--space-5); margin:0">'
        f'{fields}<div style="margin-top:var(--space-2)">{submit_btn("登录中…" if sub else "登录", disabled=sub, reason="正在登录")}</div></form></div>'
    )
    body.append(f'<div style="margin-top:var(--space-5)">{switch_line("还没有账号？", "注册", links["register"], touch)}</div>')
    return "".join(body)


def register_form(st, touch, links):
    sub = st.get("submitting", False)
    fe, fp, fc = dict(st.get("f_email", {})), dict(st.get("f_pw", {})), dict(st.get("f_pw2", {}))
    body = [form_head("注册", "用邮箱建一个 Patra 账号")]
    gap_after_head = "var(--space-8)"
    alert_html = ""
    if st.get("alert"):
        gap_after_head = "var(--space-6)"
        alert_html = f'<div style="margin-bottom:var(--space-5)">{alert(st["alert"])}</div>'
    if fe.pop("taken", False):
        fe["error_html"] = (
            f'该邮箱已注册，<a href="{links["login"]}" class="pt-link" style="font-weight:500; text-decoration:none">'
            '<span class="link-draw is-drawn">去登录</span></a>'
        )
    fields = (
        field("email", "邮箱", kind="email", placeholder="name@example.com", autocomplete="email",
              readonly=sub, touch=touch, **fe)
        + field("password", "密码", kind="password", toggle=True, hint="至少 8 位", autocomplete="new-password",
                readonly=sub, touch=touch, **fp)
        + field("password-confirm", "确认密码", kind="password", toggle=True, autocomplete="new-password",
                readonly=sub, touch=touch, **fc)
    )
    note = '<p style="margin:0; font-size:var(--text-sm); line-height:20px; color:var(--fg-3)">请牢记密码，目前不支持找回密码。</p>'
    body.append(
        f'<div style="margin-top:{gap_after_head}">{alert_html}'
        '<form onSubmit="{{ noSubmit }}" style="display:flex; flex-direction:column; gap:var(--space-5); margin:0">'
        f'{fields}<div style="display:flex; flex-direction:column; gap:var(--space-4)">{note}'
        f'{submit_btn("注册中…" if sub else "注册", disabled=sub, reason="正在注册")}</div></form></div>'
    )
    body.append(f'<div style="margin-top:var(--space-5)">{switch_line("已有账号？", "登录", links["login"], touch)}</div>')
    return "".join(body)


FOCUS = {"state": "is-focus"}
LOGIN_STATES = [
    dict(key="Default", name="默认", f_email=FOCUS),
    dict(key="Submitting", name="提交中", submitting=True, f_email=dict(value=EMAIL), f_pw=dict(value=PW)),
    dict(key="Empty", name="字段校验 · 空提交", f_email=dict(error="请输入邮箱", **FOCUS), f_pw=dict(error="请输入密码")),
    dict(key="EmailFormat", name="字段校验 · 邮箱格式不对", f_email=dict(value=EMAIL_BAD, error="邮箱格式不正确"), f_pw=FOCUS),
    dict(key="BadCredentials", name="邮箱或密码错误", alert="邮箱或密码错误", f_email=dict(value=EMAIL), f_pw=FOCUS),
    dict(key="RateLimited", name="被暂时限制", alert="尝试次数过多，请 15 分钟后再试", f_email=dict(value=EMAIL), f_pw=FOCUS),
    dict(key="Banned", name="账号已被封禁", alert="该账号已被封禁，无法登录", f_email=dict(value=EMAIL), f_pw=FOCUS),
    dict(key="ServiceError", name="网络或服务错误", alert="登录没有成功，请稍后再试", f_email=dict(value=EMAIL), f_pw=FOCUS),
]
REGISTER_STATES = [
    dict(key="Default", name="默认", f_email=FOCUS),
    dict(key="Submitting", name="提交中（长邮箱在框内横向滚动）", submitting=True,
         f_email=dict(value=EMAIL_LONG), f_pw=dict(value=PW), f_pw2=dict(value=PW)),
    dict(key="Empty", name="字段校验 · 空提交", f_email=dict(error="请输入邮箱", **FOCUS),
         f_pw=dict(error="请输入密码"), f_pw2=dict(error="请再输入一次密码")),
    dict(key="Invalid", name="字段校验 · 格式与长度", f_email=dict(value=EMAIL_BAD, error="邮箱格式不正确", **FOCUS),
         f_pw=dict(value=PW_SHORT, error="密码至少 8 位"), f_pw2=dict(value="abc124", error="两次输入的密码不一致")),
    dict(key="TooLong", name="字段校验 · 密码超过 64 位（密码已显示）", f_email=dict(value=EMAIL),
         f_pw=dict(value=PW_LONG, shown=True, error="密码最长 64 位", **FOCUS), f_pw2=dict(value=PW_LONG)),
    dict(key="EmailTaken", name="邮箱已注册", f_email=dict(value=EMAIL, taken=True, **FOCUS),
         f_pw=dict(value=PW), f_pw2=dict(value=PW)),
    dict(key="CommonPassword", name="密码太常见", f_email=dict(value=EMAIL),
         f_pw=dict(value=PW_COMMON, error="这个密码太常见，容易被猜到，请换一个", **FOCUS), f_pw2=dict(value=PW_COMMON)),
    dict(key="ServiceError", name="网络或服务错误", alert="注册没有成功，请稍后再试",
         f_email=dict(value=EMAIL), f_pw=dict(value=PW), f_pw2=dict(value=PW)),
]


# ============================================================
# AuthShell：专注布局外壳
# ============================================================
def brand_panel():
    """品牌面板（纸墨分栏）：墨色底上的叶脉图形 + 一句定位语。"""
    skin = "background:var(--bg-inverse); color:var(--fg-inverse-2)"
    ven, rule = VEN_INVERSE, "var(--border-inverse-strong)"
    meta, fig, big, em = "var(--fg-inverse-3)", "var(--accent-on-inverse)", "var(--fg-inverse-1)", "var(--accent-on-inverse)"
    return (
        f'<aside class="pt-auth-panel" style="flex:1 1 50%; min-width:0; min-height:100vh; position:relative; overflow:hidden; '
        f'display:flex; flex-direction:column; justify-content:flex-end; padding:var(--space-16); {skin}">'
        f'<img src="{ven}" alt="" aria-hidden="true" style="position:absolute; top:7vh; right:13%; height:66vh; width:auto; '
        'transform:rotate(-16deg); pointer-events:none">'
        f'<div style="position:relative; border-top:1px solid {rule}; padding-top:var(--space-5)">'
        f'<p style="margin:0; font-family:{MONO}; font-size:var(--text-2xs); line-height:var(--leading-relaxed); '
        f'letter-spacing:var(--tracking-mono); color:{meta}"><span style="color:{fig}">图 1</span>　叶脉</p>'
        f'<p style="margin:var(--space-3) 0 0; font-family:{SERIF}; font-size:var(--text-display-3); line-height:var(--leading-heading); '
        f'font-weight:500; letter-spacing:var(--tracking-tight); white-space:nowrap; color:{big}">十个来源，<br>汇入同一根<span style="color:{em}">主脉</span>。</p>'
        "</div></aside>"
    )


def auth_desktop(form_html, back_href):
    return (
        f'<div class="pt-root" style="display:flex; min-height:100vh; font-family:{SANS}; color:var(--fg-1)">'
        '<div style="flex:1 1 50%; min-width:0; min-height:100vh; display:flex; flex-direction:column; '
        'padding-left:max(var(--gutter), calc((100vw - var(--page-max)) / 2 + var(--gutter))); padding-right:var(--gutter)">'
        '<header style="display:flex; align-items:center; justify-content:space-between; gap:var(--space-6); height:56px; flex-shrink:0">'
        f"{brand()}{back_link(back_href)}</header>"
        '<main style="flex:1 1 auto; display:flex; flex-direction:column; padding:var(--space-6) 0">'
        '<div aria-hidden="true" style="flex:2 1 0"></div>'
        f'<div style="width:100%; max-width:400px">{form_html}</div>'
        '<div aria-hidden="true" style="flex:3 1 0"></div></main></div>'
        f"{brand_panel()}</div>"
    )


def auth_mobile(form_html, back_href):
    return (
        f'<div class="pt-root" style="width:375px; min-height:812px; display:flex; flex-direction:column; padding:0 20px var(--space-10); '
        f'font-family:{SANS}; color:var(--fg-1)">'
        '<header style="display:flex; align-items:center; justify-content:space-between; gap:var(--space-4); height:56px; flex-shrink:0">'
        f"{brand(sub=False)}{back_link(back_href, touch=True)}</header>"
        f'<main style="padding-top:var(--space-10)">{form_html}</main></div>'
    )


# ============================================================
# 导航栏
# ============================================================
def initial(email):
    """圆形标识里的字符：邮箱第一个字符，字母转大写，数字或符号原样。"""
    return email[0].upper()


def avatar(email, expanded=False, extra_cls="", interactive=True):
    tag_open = (
        f'<button type="button" class="pt-avatar{extra_cls}" aria-label="账号菜单" aria-haspopup="menu" '
        f'aria-expanded="{"true" if expanded else "false"}"'
        if interactive
        else '<span aria-hidden="true"'
    )
    skin = "" if interactive else " background:var(--ink-900); color:var(--paper-50);"
    return (
        f'{tag_open} style="display:inline-flex; align-items:center; justify-content:center; flex-shrink:0; width:36px; height:36px; '
        f'padding:0; border:0; border-radius:var(--radius-pill);{skin} font-family:{SERIF}; font-size:var(--text-md); line-height:1; '
        f'font-weight:500; font-variant-numeric:tabular-nums">{esc(initial(email))}{"</button>" if interactive else "</span>"}'
    )


def avatar_placeholder():
    return ('<span role="status" aria-label="正在确认登录状态" style="display:block; flex-shrink:0; width:36px; height:36px; '
            'border-radius:var(--radius-pill); background:var(--bg-sunken)"></span>')


def nav_login_btn(href="Main.dc.html", extra_cls=""):
    return (
        f'<a href="{href}" class="pt-btn-secondary{extra_cls}" style="display:inline-flex; align-items:center; height:36px; padding:0 16px; '
        'border-width:1px; border-style:solid; border-radius:var(--radius-pill); font-size:var(--text-sm); line-height:20px; '
        'font-weight:500; text-decoration:none; white-space:nowrap">登录</a>'
    )


def user_menu(email, logging_out=False, static=False, item_cls="", uid="um"):
    """UserMenu：圆形标识点开的下拉菜单（新增原语 menu）。

    浮起表面（bg-elevated）与入场缓动同 QuickSearch；阴影和圆角按设计系统的下拉规则用 shadow-lg / radius-lg，
    不用 QuickSearch 的 shadow-xl（那是压在深色遮罩上的对话框阴影）。
    邮箱行是菜单分组的标签（对应 base-ui 的 Menu.Group + Menu.GroupLabel）：方向键移到「退出登录」时读屏会读出当前账号。
    """
    pos = "position:relative" if static else "position:absolute; top:calc(100% + 8px); right:0; z-index:5"
    max_w = "min(320px, 100%)" if static else "320px"
    dis = ' disabled="true" aria-disabled="true" title="正在退出登录"' if logging_out else ""
    return (
        f'<div role="menu" aria-label="账号菜单" style="{pos}; width:max-content; min-width:240px; max-width:{max_w}; padding:6px; '
        'border-radius:var(--radius-lg); background:var(--bg-elevated); box-shadow:var(--shadow-lg)">'
        f'<div role="group" aria-labelledby="{uid}-cap {uid}-email">'
        '<div style="padding:8px 10px 10px; min-width:0">'
        f'<div id="{uid}-cap" style="font-family:{MONO}; font-size:var(--text-3xs); line-height:16px; letter-spacing:var(--tracking-caps); '
        'color:var(--fg-3)">当前账号</div>'
        f'<div id="{uid}-email" title="{esc(email)}" style="margin:2px 0 0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; '
        f'font-size:var(--text-sm); line-height:20px; font-weight:500; color:var(--fg-1)">{esc(email)}</div></div>'
        '<div role="separator" style="height:1px; margin:0 -6px 6px; background:var(--border-subtle)"></div>'
        f'<button type="button" role="menuitem" class="pt-menuitem{item_cls}"{dis} style="display:flex; align-items:center; gap:10px; '
        'width:100%; height:36px; padding:0 10px; border:0; border-radius:var(--radius-md); font-family:inherit; '
        f'font-size:var(--text-base); line-height:20px; text-align:left">{icon("log-out", 15, 2, "color:var(--fg-3)")}退出登录</button>'
        "</div></div>"
    )


def nav_account(mode, email=EMAIL, logging_out=False):
    """NavAccount：导航栏右上角的账号区，三种形态。"""
    if mode == "out":
        return nav_login_btn()
    if mode == "pending":
        return f'<div style="margin-left:6px; display:flex">{avatar_placeholder()}</div>'
    if mode == "in":
        return f'<div style="position:relative; margin-left:6px; display:flex">{avatar(email)}</div>'
    return (
        f'<div style="position:relative; margin-left:6px; display:flex">{avatar(email, expanded=True)}'
        f"{user_menu(email, logging_out=logging_out)}</div>"
    )


def nav_item(label, current=False):
    cur = ' aria-current="page"' if current else ""
    dot = (
        '<span aria-hidden="true" style="position:absolute; bottom:-2px; left:50%; width:4px; height:4px; margin-left:-2px; '
        'border-radius:var(--radius-pill); background:var(--clay-500)"></span>'
        if current
        else ""
    )
    return (
        f'<li><a href="#" class="pt-navlink"{cur} style="position:relative; display:inline-flex; align-items:center; '
        'border-radius:var(--radius-pill); padding:8px 14px; font-size:var(--text-sm); line-height:1.4286; font-weight:500; '
        f'text-decoration:none"><span class="link-draw">{label}</span>{dot}</a></li>'
    )


def topnav_desktop(account_html):
    """现有 TopNav（src/components/portal/TopNav.tsx）原样复刻，只在最右加账号区。"""
    items = nav_item("首页") + nav_item("文献", current=True) + nav_item("期刊")
    quick = (
        '<button type="button" class="pt-quick" style="display:inline-flex; align-items:center; gap:8px; height:36px; padding:0 6px 0 12px; '
        'border-width:1px; border-style:solid; border-radius:var(--radius-pill); font-family:inherit; font-size:var(--text-sm); line-height:1.4286">'
        f'{icon("search", 14, 1.75)}<span>快速检索</span>'
        '<kbd aria-hidden="true" class="pt-quick-kbd" style="border-width:1px; border-style:solid; border-radius:var(--radius-pill); background:var(--paper-100); '
        f'padding:2px 8px; font-family:{MONO}; font-size:var(--text-3xs); line-height:1.4286; color:var(--fg-3)">⌘K</kbd></button>'
    )
    about = (
        '<a href="#" class="pt-navlink" style="border-radius:var(--radius-pill); padding:8px 12px; font-size:var(--text-sm); '
        'line-height:1.4286; font-weight:500; text-decoration:none"><span class="link-draw">关于</span></a>'
    )
    return (
        '<header style="position:relative; z-index:2; border-bottom:1px solid transparent">'
        '<div style="margin:0 auto; max-width:var(--page-max); height:56px; padding:0 var(--gutter); display:grid; '
        'grid-template-columns:1fr auto 1fr; align-items:center; column-gap:24px">'
        f'<div style="justify-self:start; display:flex">{brand()}</div>'
        f'<nav aria-label="主导航"><ul style="display:flex; align-items:center; gap:4px; margin:0; padding:0; list-style:none">{items}</ul></nav>'
        f'<div style="justify-self:end; display:flex; align-items:center; gap:6px">{quick}{about}{account_html}</div>'
        "</div></header>"
    )


def topnav_mobile():
    return (
        '<header style="position:relative; z-index:2; border-bottom:1px solid transparent">'
        '<div style="height:56px; padding:0 20px; display:grid; grid-template-columns:1fr auto; align-items:center; column-gap:24px">'
        f'<div style="justify-self:start; display:flex">{brand(sub=False)}</div>'
        '<div style="display:flex; align-items:center; gap:6px">'
        '<button type="button" class="pt-quick" aria-label="快速检索" style="display:inline-flex; align-items:center; justify-content:center; '
        f'width:36px; height:36px; padding:0; border-width:1px; border-style:solid; border-radius:var(--radius-pill)">{icon("search", 14, 1.75)}</button>'
        '<button type="button" class="pt-ghost" aria-label="打开菜单" style="display:inline-flex; align-items:center; justify-content:center; '
        f'width:36px; height:36px; padding:0; border:0; border-radius:var(--radius-pill)">{icon("menu", 20, 1.5)}</button>'
        "</div></div></header>"
    )


def skel(style):
    return f'<div class="pt-skel" style="{style}"></div>'


def papers_stub(mobile=False):
    """导航栏下方的页面内容：/papers 的真实页头 + 现有 loading.tsx 的骨架（列表本身不在本稿范围）。"""
    pt, mb_crumb, pb = ("24px", "20px", "28px") if mobile else ("40px", "28px", "32px")
    gutter = "20px" if mobile else "var(--gutter)"
    head = (
        f'<div style="border-bottom:1px solid var(--border-default); padding-bottom:{pb}">'
        f'<nav aria-label="面包屑" style="display:flex; align-items:center; gap:8px; margin-bottom:{mb_crumb}; font-family:{MONO}; '
        'font-size:var(--text-2xs); letter-spacing:var(--tracking-mono); color:var(--fg-3)">'
        '<a href="#" style="color:inherit; text-decoration:none"><span class="link-draw">Patra</span></a><span aria-hidden="true">/</span>'
        '<span aria-current="page" style="color:var(--fg-2)">文献浏览</span></nav>'
        '<p style="margin:0 0 16px; display:flex; align-items:center; gap:8px; font-size:var(--text-2xs); font-weight:600; '
        'letter-spacing:var(--tracking-caps); color:var(--fg-3)"><span aria-hidden="true" style="display:block; width:4px; height:14px; '
        'border-radius:1px; background:var(--clay-600)"></span>按文献浏览</p>'
        f'<h1 style="margin:0; font-family:{SERIF}; font-size:var(--text-display-3); line-height:var(--leading-heading); font-weight:500; '
        'letter-spacing:var(--tracking-tight); color:var(--ink-900)">浏览全部文献</h1>'
        '<p style="margin:16px 0 0; max-width:46em; font-size:var(--text-md); line-height:var(--leading-relaxed); color:var(--fg-2)">'
        + dash("Patra 收录的医学文献——按关键词、PMID、DOI 或作者检索，按年份 / 文献类型 / 证据等级 / 期刊收敛，点任一篇查看完整元信息与摘要。")
        + "</p></div>"
    )
    bar = (
        '<div aria-hidden="true" style="margin-top:32px; display:flex; flex-direction:column; gap:16px">'
        f'<div style="display:flex; gap:4px">{skel("height:28px; width:80px")}{skel("height:28px; width:56px")}'
        f'{skel("height:28px; width:48px")}{skel("height:28px; width:48px")}</div>'
        f'{skel("height:44px; width:100%")}{skel("height:20px; width:224px")}</div>'
    )
    rows = "".join(
        '<div style="display:flex; flex-direction:column; gap:10px; padding:20px 0; border-bottom:1px solid var(--border-subtle)">'
        f'{skel("height:12px; width:160px")}{skel(f"height:20px; width:{w}%")}{skel("height:16px; width:52%")}</div>'
        for w in ((82, 68, 76) if mobile else (72, 58, 66, 49))
    )
    if mobile:
        body = f'<div aria-hidden="true" style="margin-top:24px">{rows}</div>'
    else:
        facet = "".join(skel(f"height:{h}px; width:{w}px") for h, w in ((16, 96), (14, 200), (14, 168), (14, 184), (16, 80), (14, 192), (14, 152)))
        body = (
            '<div aria-hidden="true" style="margin-top:40px; display:flex; align-items:flex-start; gap:48px">'
            f'<div style="width:240px; flex-shrink:0; display:flex; flex-direction:column; gap:14px">{facet}</div>'
            f'<div style="flex:1 1 0; min-width:0">{rows}</div></div>'
        )
    return (
        f'<main style="margin:0 auto; max-width:var(--page-max); padding:{pt} {gutter} 32px">{head}{bar}{body}</main>'
    )


def toast(text, mobile=False, static=False):
    """成功提示：沿用现有右下角的 sonner toast。"""
    if static:
        pos = "position:relative; width:356px; max-width:100%"
    elif mobile:
        pos = "position:absolute; left:16px; right:16px; bottom:16px; z-index:6"
    else:
        pos = "position:absolute; right:24px; bottom:24px; z-index:6; width:356px"
    return (
        f'<div role="status" style="{pos}; display:flex; align-items:center; gap:6px; padding:16px; border:1px solid var(--border-default); '
        'border-radius:var(--radius-lg); background:var(--bg-elevated); box-shadow:var(--shadow-lg); font-size:var(--text-sm); '
        f'line-height:1.5; font-weight:500; color:var(--fg-1)">{icon("circle-check", 16, 2, "margin-left:-3px; margin-right:4px; color:var(--status-success)")}'
        f"<span>{text}</span></div>"
    )


def nav_desktop_board(st):
    acct = nav_account(st["account"], st.get("email", EMAIL), st.get("logging_out", False))
    t = toast(st["toast"]) if st.get("toast") else ""
    return (
        f'<div class="pt-root" style="position:relative; width:1440px; height:900px; overflow:hidden; font-family:{SANS}; color:var(--fg-1)">'
        f"{topnav_desktop(acct)}{papers_stub()}{t}</div>"
    )


def mobile_account_block(mode, email=EMAIL, logging_out=False, links=None, static=False):
    """移动端全屏菜单里的账号块：未登录 / 登录态 / 占位，三种形态同高（80px）。"""
    links = links or {"login": "Login-M-Default.dc.html", "register": "Register-M-Default.dc.html"}
    top = "" if static else "margin-top:auto; "
    wrap = (f'<div style="{top}border-top:1px solid var(--border-default); padding-top:20px; display:flex; flex-direction:column; '
            'gap:12px; min-width:0">')
    btn_style = (
        "display:flex; align-items:center; justify-content:center; gap:8px; width:100%; height:48px; padding:0 20px; border-width:1px; "
        "border-style:solid; border-radius:var(--radius-pill); font-family:inherit; font-size:var(--text-base); line-height:1.5; "
        "font-weight:600; text-decoration:none; white-space:nowrap"
    )
    if mode == "out":
        return (
            f'{wrap}<a href="{links["login"]}" class="pt-btn-secondary" style="{btn_style}">登录</a>'
            '<p style="margin:0; text-align:center; font-size:var(--text-base); line-height:20px; color:var(--fg-2)">还没有账号？'
            f'<a href="{links["register"]}" class="pt-link" style="display:inline-block; padding:12px 0; margin:-12px 0; font-weight:500; '
            'text-decoration:none"><span class="link-draw">注册</span></a></p></div>'
        )
    if mode == "pending":
        return (
            f'{wrap}<span role="status" aria-label="正在确认登录状态" style="display:block; height:80px; border-radius:var(--radius-sm); '
            'background:var(--bg-sunken)"></span></div>'
        ).replace("gap:12px", "gap:0")
    dis = ' disabled="true" aria-disabled="true" title="正在退出登录"' if logging_out else ""
    return (
        f'{wrap}<p style="margin:0; display:flex; align-items:baseline; gap:10px; min-width:0; font-size:var(--text-base); line-height:20px">'
        f'<span style="flex-shrink:0; font-family:{MONO}; font-size:var(--text-3xs); line-height:16px; letter-spacing:var(--tracking-caps); color:var(--fg-3)">当前账号</span>'
        f'<span title="{esc(email)}" style="min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; font-weight:500; '
        f'color:var(--fg-1)">{esc(email)}</span></p>'
        f'<button type="button" class="pt-btn-secondary"{dis} style="{btn_style}">{icon("log-out", 15)}退出登录</button></div>'
    )


def mobile_menu_board(st):
    """现有移动端全屏菜单（TopNav 里的 Sheet）原样复刻，底部加账号块。"""
    lis = ""
    for i, (label, cur) in enumerate((("首页", False), ("文献", True), ("期刊", False))):
        color = "var(--clay-700)" if cur else "var(--ink-900)"
        ac = ' aria-current="page"' if cur else ""
        lis += (
            f'<li><a href="#"{ac} style="display:flex; align-items:baseline; gap:20px; border-bottom:1px solid var(--border-default); '
            f'padding:20px 0; text-decoration:none"><span aria-hidden="true" style="width:24px; font-family:{MONO}; font-size:var(--text-xs); '
            f'color:var(--fg-3)">{i + 1:02d}</span><span style="font-family:{SERIF}; font-size:var(--text-display-3); '
            f'line-height:var(--leading-heading); color:{color}">{label}</span></a></li>'
        )
    return (
        f'<div class="pt-root" style="position:relative; isolation:isolate; width:375px; height:812px; overflow:hidden; display:flex; '
        f'flex-direction:column; padding:0 20px 40px; border-bottom:1px solid var(--border-default); background-image:none; '
        f'font-family:{SANS}; font-size:var(--text-sm); line-height:1.4286; color:var(--fg-1)">'
        f'<img src="{VEN_PAPER}" alt="" aria-hidden="true" style="position:absolute; right:-14%; bottom:-10%; z-index:-1; height:62%; '
        'width:auto; transform:rotate(24deg); opacity:0.18; pointer-events:none">'
        '<div style="height:56px; flex-shrink:0; display:flex; flex-direction:column; justify-content:center">'
        f'<h2 style="margin:0; font-family:{MONO}; font-size:var(--text-2xs); font-weight:400; letter-spacing:var(--tracking-caps); '
        'color:var(--fg-3)">导航菜单</h2></div>'
        '<button type="button" class="pt-ghost" aria-label="关闭" style="position:absolute; top:12px; right:12px; display:inline-flex; '
        f'align-items:center; justify-content:center; width:28px; height:28px; padding:0; border:0; border-radius:var(--radius-md)">{icon("x", 16, 2)}</button>'
        f'<ul style="margin:16px 0 0; padding:0; list-style:none; display:flex; flex-direction:column; border-top:1px solid var(--border-default)">{lis}</ul>'
        '<div style="margin-top:32px; display:flex; flex-direction:column; gap:16px">'
        '<button type="button" style="display:flex; align-items:center; gap:12px; height:48px; padding:0 20px; border:1px solid var(--border-default); '
        'border-radius:var(--radius-pill); background:var(--paper-50); font-family:inherit; font-size:var(--text-base); line-height:1.5; '
        f'color:var(--fg-2); cursor:pointer">{icon("search", 16, 1.75)}检索文献、PMID、DOI 或作者</button>'
        '<div style="display:flex; align-items:center; gap:24px; padding:0 4px; font-size:var(--text-sm); line-height:1.4286; color:var(--fg-2)">'
        '<a href="#" style="color:inherit; text-decoration:none">关于 Patra</a>'
        f'<a href="#" style="display:inline-flex; align-items:center; gap:4px; color:inherit; text-decoration:none">GitHub{icon("arrow-up-right", 14, 1.5)}</a>'
        "</div></div>"
        f'{mobile_account_block(st["account"], st.get("email", EMAIL), st.get("logging_out", False))}</div>'
    )


def mobile_page_board(st):
    t = toast(st["toast"], mobile=True) if st.get("toast") else ""
    return (
        f'<div class="pt-root" style="position:relative; width:375px; height:812px; overflow:hidden; font-family:{SANS}; color:var(--fg-1)">'
        f"{topnav_mobile()}{papers_stub(mobile=True)}{t}</div>"
    )


NAV_DESKTOP = [
    dict(key="LoggedOut", name="未登录态", account="out"),
    dict(key="Pending", name="登录态未定（占位）", account="pending"),
    dict(key="LoggedIn", name="登录态 · 菜单收起 · 提示「已登录」", account="in", email=EMAIL, toast="已登录"),
    dict(key="Registered", name="登录态 · 首字符是数字 · 提示「注册成功，已登录」", account="in", email=EMAIL_DIGIT, toast="注册成功，已登录"),
    dict(key="MenuOpen", name="登录态 · 菜单展开", account="open", email=EMAIL),
    dict(key="MenuLongEmail", name="登录态 · 菜单展开 · 长邮箱截断", account="open", email=EMAIL_LONG),
    dict(key="LoggingOut", name="退出进行中", account="open", email=EMAIL, logging_out=True),
    dict(key="SignedOut", name="已退出 · 提示「已退出登录」", account="out", toast="已退出登录"),
]
NAV_MOBILE = [
    dict(key="TopBar", name="顶栏（不显示登录状态）", kind="page"),
    dict(key="MenuLoggedOut", name="全屏菜单 · 未登录", kind="menu", account="out"),
    dict(key="MenuPending", name="全屏菜单 · 登录态未定（占位）", kind="menu", account="pending"),
    dict(key="MenuLoggedIn", name="全屏菜单 · 登录态", kind="menu", account="in", email=EMAIL),
    dict(key="MenuLongEmail", name="全屏菜单 · 登录态 · 长邮箱截断", kind="menu", account="in", email=EMAIL_LONG),
    dict(key="MenuLoggingOut", name="全屏菜单 · 退出进行中", kind="menu", account="in", email=EMAIL, logging_out=True),
    dict(key="SignedOut", name="已退出 · 菜单已关闭，留在当前页 · 提示「已退出登录」", kind="page", toast="已退出登录"),
    dict(key="Toast", name="页面 · 提示「已登录」", kind="page", toast="已登录"),
    dict(key="Registered", name="页面 · 提示「注册成功，已登录」", kind="page", toast="注册成功，已登录"),
]


# ============================================================
# 组件规范画板
# ============================================================
def cell(caption, note, body, span=1):
    sp = f"grid-column:span {span}; " if span > 1 else ""
    note_html = f'<span style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap; color:var(--fg-3)">{note}</span>' if note else ""
    return (
        f'<div style="{sp}display:flex; flex-direction:column; gap:12px; min-width:0">'
        f'<p style="margin:0; display:flex; flex-direction:column; min-height:32px; font-family:{MONO}; font-size:var(--text-2xs); '
        f'line-height:16px; letter-spacing:var(--tracking-mono); color:var(--fg-1)"><span>{caption}</span>{note_html}</p>{body}</div>'
    )


def section(index, title, body, cols=4, gap="32px"):
    return (
        '<section style="display:flex; flex-direction:column; gap:24px">'
        '<h2 style="margin:0; display:flex; align-items:center; gap:8px; padding-bottom:12px; border-bottom:1px solid var(--border-default); '
        f'font-family:{SANS}; font-size:var(--text-2xs); font-weight:600; letter-spacing:var(--tracking-caps); color:var(--fg-3)">'
        f'<span style="font-family:{MONO}; font-weight:500; letter-spacing:var(--tracking-mono); color:var(--accent-strong)">{index}</span>'
        f'<span aria-hidden="true" style="display:block; width:24px; height:1px; background:currentColor; opacity:0.5"></span>{title}</h2>'
        f'<div style="display:grid; grid-template-columns:repeat({cols}, minmax(0, 1fr)); gap:{gap}; align-items:start">{body}</div></section>'
    )


def spec_shell(crumb, title, desc, sections, height):
    return (
        f'<div class="pt-root" style="width:1440px; min-height:{height}px; padding:64px 80px 80px; display:flex; flex-direction:column; gap:56px; '
        f'font-family:{SANS}; color:var(--fg-1)">'
        '<header style="display:flex; flex-direction:column; gap:16px">'
        f'<p style="margin:0; font-family:{MONO}; font-size:var(--text-2xs); letter-spacing:var(--tracking-mono); color:var(--fg-3)">{crumb}</p>'
        f'<h1 style="margin:0; font-family:{SERIF}; font-size:var(--text-4xl); line-height:var(--leading-heading); font-weight:500; '
        f'letter-spacing:var(--tracking-tight); color:var(--fg-1)">{title}</h1>'
        f'<p style="margin:0; max-width:52em; font-size:var(--text-md); line-height:var(--leading-relaxed); color:var(--fg-2)">{dash(desc)}</p></header>'
        f'{"".join(sections)}</div>'
    )


def kv(rows):
    out = ""
    for k, v in rows:
        out += (
            '<div style="display:grid; grid-template-columns:160px minmax(0, 1fr); gap:16px; padding:10px 0; border-bottom:1px solid var(--border-subtle)">'
            f'<span style="font-family:{MONO}; font-size:var(--text-2xs); line-height:20px; letter-spacing:var(--tracking-mono); color:var(--fg-3)">{k}</span>'
            f'<span style="font-size:var(--text-sm); line-height:20px; color:var(--fg-1)">{dash(v)}</span></div>'
        )
    return f'<div style="display:flex; flex-direction:column; min-width:0">{out}</div>'


def msg_list(title, rows):
    out = ""
    for where, text in rows:
        out += (
            '<div style="display:grid; grid-template-columns:120px minmax(0, 1fr); gap:16px; padding:10px 0; border-bottom:1px solid var(--border-subtle)">'
            f'<span style="font-family:{MONO}; font-size:var(--text-2xs); line-height:20px; letter-spacing:var(--tracking-mono); color:var(--fg-3)">{where}</span>'
            f'<span style="display:flex; align-items:flex-start; gap:6px; font-size:var(--text-sm); line-height:20px; color:var(--status-danger)">'
            f'{icon("circle-alert", 14, 2, "margin-top:3px")}<span>{text}</span></span></div>'
        )
    return cell(title, "", f'<div style="display:flex; flex-direction:column">{out}</div>', span=2)


def spec_form_board(height):
    f = lambda i, **kw: field(f"spec-{i}", kw.pop("label", "邮箱"), **kw)  # noqa: E731
    s1 = section("01", "FormField · 输入框状态", "".join([
        cell("默认", "border-strong · bg-elevated", f(1, kind="email", placeholder="name@example.com")),
        cell("悬停", "ink-500", f(2, kind="email", placeholder="name@example.com", state="is-hover")),
        cell("聚焦", "border-focus + 光晕 clay-500 15%", f(3, kind="email", placeholder="name@example.com", state="is-focus")),
        cell("已填 / 浏览器自动填充", "底色保持 bg-elevated", f(4, kind="email", value=EMAIL)),
        cell("错误", "status-danger 描边 + 图标 + 文字", f(5, kind="email", value=EMAIL_BAD, error="邮箱格式不正确")),
        cell("错误 + 聚焦", "status-danger + 光晕 rust-500 15%", f(6, kind="email", value=EMAIL_BAD, error="邮箱格式不正确", state="is-focus")),
        cell("只读（提交中）", "border-default · bg-sunken", f(7, kind="email", value=EMAIL, readonly=True)),
        cell("内容超长", "框内横向滚动，不截断", f(8, kind="email", value=EMAIL_LONG)),
    ]))
    p = lambda i, **kw: field(f"spec-pw-{i}", "密码", kind="password", toggle=True, **kw)  # noqa: E731
    s2 = section("02", "PasswordInput · 显示 / 隐藏切换", "".join([
        cell("隐藏（默认）+ 常驻提示", "aria-label「显示密码」", p(1, value=PW, hint="至少 8 位")),
        cell("显示", "aria-label「隐藏密码」", p(2, value=PW, shown=True, hint="至少 8 位")),
        cell("切换按钮 · 悬停", "paper-200 · ink-900", p(3, value=PW, hint="至少 8 位", toggle_cls=" is-hover")),
        cell("切换按钮 · 键盘聚焦", "ring-focus", p(4, value=PW, hint="至少 8 位", toggle_cls=" is-focus-ring")),
    ]))
    s3 = section("03", "FormAlert · 表单级提示条（role=alert）", "".join([
        cell("登录", "401", alert("邮箱或密码错误")),
        cell("登录", "429 · 分钟数取自后端的剩余秒数", alert("尝试次数过多，请 15 分钟后再试")),
        cell("登录", "429 · 后端没给剩余时间", alert("尝试次数过多，请稍后再试")),
        cell("登录", "403", alert("该账号已被封禁，无法登录")),
        cell("登录", "超时 · 网络错误 · 5xx", alert("登录没有成功，请稍后再试")),
        cell("注册", "超时 · 网络错误 · 5xx", alert("注册没有成功，请稍后再试")),
    ]), cols=3)
    s4 = section("04", "主按钮 · btnPrimary + btnBlock", "".join([
        cell("默认", "action-primary", submit_btn("登录")),
        cell("悬停", "action-primary-hover", submit_btn("登录", extra_cls=" is-hover")),
        cell("按下 · 下沉 1px", "底色 press，描边保持 hover", submit_btn("登录", extra_cls=" is-press")),
        cell("键盘聚焦", "ring-focus", submit_btn("登录", extra_cls=" is-focus-ring")),
        cell("提交中（禁用）", "55% 不透明度，换文案，title 说明原因", submit_btn("登录中…", disabled=True, reason="正在登录")),
    ]), cols=5, gap="24px")
    back_focus = (
        '<span class="is-focus-ring" style="display:inline-flex; border-radius:var(--radius-sm)">'
        + back_link("#") + "</span>"
    )
    link_focus = (
        '<p style="margin:0; font-size:var(--text-base); line-height:20px; color:var(--fg-2)">还没有账号？'
        '<a href="#" class="pt-link is-focus-ring" style="border-radius:var(--radius-xs); font-weight:500; text-decoration:none">'
        '<span class="link-draw is-hover">注册</span></a></p>'
    )
    s5 = section("05", "文字链接", "".join([
        cell("互跳 · 默认", "link", switch_line("还没有账号？", "注册", "#")),
        cell("互跳 · 悬停", "link-hover + 下划线自左绘出", switch_line("还没有账号？", "注册", "#", extra_cls=" is-hover")),
        cell("互跳 · 键盘聚焦", "ring-focus", link_focus),
        cell("「返回」· 默认", "fg-2", f'<div style="display:flex">{back_link("#")}</div>'),
        cell("「返回」· 悬停", "ink-900 + 下划线", f'<div style="display:flex">{back_link("#", extra_cls=" is-hover").replace("link-draw", "link-draw is-hover")}</div>'),
        cell("「返回」· 键盘聚焦", "ring-focus", f'<div style="display:flex">{back_focus}</div>'),
    ]), cols=3)
    taken = '该邮箱已注册，<a href="#" class="pt-link" style="font-weight:500; text-decoration:none"><span class="link-draw is-drawn">去登录</span></a>'
    s6 = section("06", "字段级错误文案一览（写在该字段下方，替换常驻提示）", "".join([
        msg_list("登录页", [("邮箱", "请输入邮箱"), ("邮箱", "邮箱格式不正确"), ("密码", "请输入密码")]),
        msg_list("注册页", [
            ("邮箱", "请输入邮箱"), ("邮箱", "邮箱格式不正确"), ("邮箱", taken),
            ("密码", "请输入密码"), ("密码", "密码至少 8 位"), ("密码", "密码最长 64 位"),
            ("密码", "这个密码太常见，容易被猜到，请换一个"),
            ("确认密码", "请再输入一次密码"), ("确认密码", "两次输入的密码不一致"),
        ]),
    ]))
    s7 = section("07", "尺寸、动效与可访问性", "".join([
        cell("尺寸", "", kv([
            ("输入井", "高 48px · radius-xl · 左右内边距 16px"),
            ("输入字号", "桌面 text-md（15px）；移动 text-lg（17px），不小于 16px，避免 iOS 聚焦时放大页面"),
            ("标签", "text-sm · 500 · fg-1，与输入井间距 8px"),
            ("提示 / 错误", "text-sm · 行高 20px；提示 fg-3，错误 status-danger"),
            ("字段间距", "space-5（20px）；表单最宽 400px"),
            ("切换按钮", "桌面 32px；移动 44px 点按区；图标 15px、描边 2"),
        ]), span=2),
        cell("动效与可访问性", "", kv([
            ("提示条出现", "淡入 ease-out-quart，下落 4px ease-out-expo，都是 dur-slow（同折叠区）"),
            ("错误文案出现", "同上；改对即消，不做位移退场"),
            ("减弱动效", "零位移，直接显示"),
            ("错误关联", "aria-invalid + aria-describedby 指向错误文案；常驻提示同样关联"),
            ("提交中", "按钮禁用并换文案，字段只读；不加转圈（全站只有两个循环动画）"),
            ("自动填充", "autocomplete：登录 username / current-password；注册 email / new-password"),
        ]), span=2),
    ]))
    return spec_shell(
        "v0.8 Accounts / 组件规范 / 表单",
        "表单组件",
        "FormField、PasswordInput、FormAlert、主按钮与文字链接——全站第一组带标签和错误态的表单，以后的表单沿用这里的规范。",
        [s1, s2, s3, s4, s5, s6, s7],
        height,
    )


def spec_nav_board(height):
    center = lambda html: f'<div style="display:flex; align-items:center; min-height:44px">{html}</div>'  # noqa: E731
    s1 = section("01", "NavAccount ·「登录」入口（btnSecondary 的导航尺寸）", "".join([
        cell("默认", "border-default · paper-50 · fg-1", center(nav_login_btn("#"))),
        cell("悬停", "border-hover · paper-200", center(nav_login_btn("#", " is-hover"))),
        cell("按下", "下沉 1px", center(nav_login_btn("#", " is-press"))),
        cell("键盘聚焦", "ring-focus", center(nav_login_btn("#", " is-focus-ring"))),
    ]))
    exp = avatar(EMAIL, expanded=True)
    s2 = section("02", "NavAccount · 圆形标识（36px，邮箱首字符；aria-label「账号菜单」）", "".join([
        cell("默认", "ink-900 · paper-50", center(avatar(EMAIL))),
        cell("悬停 / 展开", "ink-800", center(avatar(EMAIL, extra_cls=" is-hover") + '<span style="width:12px"></span>' + exp)),
        cell("键盘聚焦", "ring-focus", center(avatar(EMAIL, extra_cls=" is-focus-ring"))),
        cell("登录态未定（占位）", "bg-sunken，同尺寸", center(avatar_placeholder())),
        cell("字母转大写", EMAIL, center(avatar(EMAIL))),
        cell("超长邮箱", "只取首字符", center(avatar(EMAIL_LONG))),
        cell("数字或符号原样", EMAIL_DIGIT, center(avatar(EMAIL_DIGIT))),
    ]))
    s3 = section("03", "UserMenu · 下拉菜单（新增原语 menu）", "".join([
        cell("默认", "bg-elevated · radius-lg · shadow-lg", user_menu(EMAIL, static=True, uid="um-default")),
        cell("菜单项高亮", "悬停或方向键 · bg-sunken", user_menu(EMAIL, static=True, item_cls=" is-hover", uid="um-hover")),
        cell("退出进行中", "菜单项禁用，title 说明原因", user_menu(EMAIL, static=True, logging_out=True, uid="um-busy")),
        cell("长邮箱", "最宽 320px，截断，悬停显示完整", user_menu(EMAIL_LONG, static=True, uid="um-long")),
    ]))
    s4 = section("04", "成功提示 · 右下角 toast（错误不用 toast；外观按设计系统：bg-elevated · border-default · radius-lg · shadow-lg · moss 图标）", "".join([
        cell("登录成功", "", toast("已登录", static=True)),
        cell("注册成功", "", toast("注册成功，已登录", static=True)),
        cell("已退出", "", toast("已退出登录", static=True)),
    ]), cols=3)
    frame = lambda html: f'<div style="width:100%; max-width:335px">{html}</div>'  # noqa: E731
    s5 = section("05", "移动端全屏菜单 · 账号块（三种形态同高 80px）", "".join([
        cell("未登录", "", frame(mobile_account_block("out", static=True, links={"login": "#", "register": "#"}))),
        cell("登录态", "", frame(mobile_account_block("in", EMAIL, static=True))),
        cell("登录态 · 长邮箱", "截断", frame(mobile_account_block("in", EMAIL_LONG, static=True))),
        cell("登录态未定（占位）", "bg-sunken · radius-sm", frame(mobile_account_block("pending", static=True))),
    ]))
    s6 = section("06", "交互、动效与可访问性", "".join([
        cell("用户菜单", "", kv([
            ("开合", "点圆形标识开合；点菜单外、按 Esc、选中菜单项都会关闭"),
            ("键盘", "方向键在菜单项之间移动；关闭后焦点回到圆形标识"),
            ("弹出", "淡入 + 自上 8px 落位 + 0.98 → 1 缩放 · 300ms · ease-out-expo（同快速检索）"),
            ("位置", "圆形标识下方 8px，右缘对齐；最窄 240px、最宽 320px"),
            ("表面", "bg-elevated · radius-lg · shadow-lg，按设计系统的下拉规则；快速检索的 shadow-xl 是对话框阴影，这里不用"),
            ("邮箱行", "不可点；过长截断，title 给出完整邮箱"),
        ]), span=2),
        cell("状态与提示", "", kv([
            ("登录态未定", "先出占位，不先显示「登录」再跳成圆形标识"),
            ("退出", "点了立即执行，不二次确认；完成后留在当前页"),
            ("会话失效", "下次打开或刷新时静默回到未登录态，不弹提示"),
            ("移动端", "顶栏不显示登录状态；账号块在全屏菜单底部"),
            ("移动端退出", "在全屏菜单里点「退出登录」立即执行；完成后菜单关闭，留在当前页，底部提示「已退出登录」"),
            ("减弱动效", "菜单只淡入，不位移"),
        ]), span=2),
    ]))
    return spec_shell(
        "v0.8 Accounts / 组件规范 / 导航栏账号区",
        "导航栏账号区",
        "NavAccount 的三种形态、UserMenu、成功提示与移动端账号块——登录前后页面上唯一的差别就在这里。",
        [s1, s2, s3, s4, s5, s6],
        height,
    )


# ============================================================
# 画板文件与画布索引
# ============================================================
def page(title, body, w, h):
    props = json.dumps({"$preview": {"width": w, "height": h}}, separators=(",", ":"))
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>{title}</title>
<script src="./support.js"></script>
<link rel="stylesheet" href="patra.css">
</head>
<body>
<x-dc>
<helmet>
{FONT_LINK}
<style>
body{{margin:0}}
</style>
</helmet>
{body}
</x-dc>
<script type="text/x-dc" data-dc-script data-props='{props}'>
class Component extends DCLogic {{
  renderVals() {{
    return {{ noSubmit: (e) => e.preventDefault() }};
  }}
}}
</script>
</body>
</html>
"""


VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "source", "track", "wbr"}


class Balance(HTMLParser):
    """生成后的自检：非空元素都闭合、嵌套不交叉。"""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.stack, self.errors = [], []

    def handle_starttag(self, tag, attrs):
        if tag not in VOID:
            self.stack.append(tag)

    def handle_endtag(self, tag):
        if tag in VOID:
            return
        if not self.stack or self.stack[-1] != tag:
            self.errors.append(f"</{tag}> 与 {self.stack[-3:]} 不匹配")
        else:
            self.stack.pop()


def check(name, html):
    p = Balance()
    p.feed(html)
    if p.errors or p.stack:
        raise SystemExit(f"{name}: 标签不平衡 {p.errors[:3]} 未闭合 {p.stack[-3:]}")
    for m in re.finditer(r'style="([^"]*)"', html):
        for hexv in re.findall(r"#[0-9a-fA-F]{3,8}\b", m.group(1)):
            raise SystemExit(f"{name}: 行内样式里有裸色值 {hexv}")


def main():
    preview = "--preview" in sys.argv
    os.makedirs(ROOT, exist_ok=True)
    heights = {"Spec-Form.dc.html": 2600, "Spec-Nav.dc.html": 1900}
    hp = os.path.join(HERE, "heights.json")
    if os.path.exists(hp):
        with open(hp, encoding="utf-8") as f:
            heights.update(json.load(f))

    boards, order, files = {}, [], {}
    INTERACTIVE = {"Main.dc.html", "Register-Default.dc.html", "Nav-LoggedOut.dc.html",
                   "Login-M-Default.dc.html", "Register-M-Default.dc.html", "Nav-M-MenuLoggedOut.dc.html"}

    def add(name, title, body, w, h, x, y, pg, fill=False):
        files[name] = page(title, body, w, h)
        entry = {"x": x, "y": y, "w": w, "h": h, "title": title, "page": pg}
        if fill:
            entry["expand"] = "fill"
        if name in INTERACTIVE:
            entry["is_interactive"] = True
        boards[name] = entry
        order.append(name)

    DW, DH, MW, MH = 1440, 900, 375, 812
    DSTEP, MSTEP, MROW = DW + 80, MW + 80, DH + 120 + 300

    d_links = {"login": "Main.dc.html", "register": "Register-Default.dc.html"}
    m_links = {"login": "Login-M-Default.dc.html", "register": "Register-M-Default.dc.html"}
    d_back, m_back = "Nav-LoggedOut.dc.html", "Nav-M-TopBar.dc.html"

    # ---- 登录页
    for i, st in enumerate(LOGIN_STATES):
        name = "Main.dc.html" if st["key"] == "Default" else f'Login-{st["key"]}.dc.html'
        add(name, f'登录 · {st["name"]}（桌面）', auth_desktop(login_form(st, False, d_links), d_back), DW, DH, i * DSTEP, 0, "login", fill=True)
    for i, st in enumerate(LOGIN_STATES):
        add(f'Login-M-{st["key"]}.dc.html', f'登录 · {st["name"]}（移动）', auth_mobile(login_form(st, True, m_links), m_back),
            MW, MH, i * MSTEP, MROW, "login")

    # ---- 注册页
    for i, st in enumerate(REGISTER_STATES):
        add(f'Register-{st["key"]}.dc.html', f'注册 · {st["name"]}（桌面）', auth_desktop(register_form(st, False, d_links), d_back),
            DW, DH, i * DSTEP, 0, "register", fill=True)
    for i, st in enumerate(REGISTER_STATES):
        add(f'Register-M-{st["key"]}.dc.html', f'注册 · {st["name"]}（移动）', auth_mobile(register_form(st, True, m_links), m_back),
            MW, MH, i * MSTEP, MROW, "register")

    # ---- 导航栏
    for i, st in enumerate(NAV_DESKTOP):
        add(f'Nav-{st["key"]}.dc.html', f'导航栏 · {st["name"]}（桌面）', nav_desktop_board(st), DW, DH, i * DSTEP, 0, "nav")
    for i, st in enumerate(NAV_MOBILE):
        body = mobile_menu_board(st) if st["kind"] == "menu" else mobile_page_board(st)
        add(f'Nav-M-{st["key"]}.dc.html', f'导航栏 · {st["name"]}（移动）', body, MW, MH, i * MSTEP, MROW, "nav")

    # ---- 组件规范
    hf, hn = heights["Spec-Form.dc.html"], heights["Spec-Nav.dc.html"]
    add("Spec-Form.dc.html", "组件规范 · 表单", spec_form_board(hf), DW, hf, 0, 0, "spec")
    add("Spec-Nav.dc.html", "组件规范 · 导航栏账号区", spec_nav_board(hn), DW, hn, DSTEP, 0, "spec")

    def title(nid, text, y, w, pg):
        return nid, {"x": 0, "y": y, "text": text, "kind": "title1", "maxW": w, "page": pg}

    notes = dict([
        title("t-login-d", "登录页 · 桌面 1440 × 900", -300, 8 * DSTEP - 80, "login"),
        title("t-login-m", "登录页 · 移动 375 × 812", MROW - 300, 8 * MSTEP - 80, "login"),
        title("t-register-d", "注册页 · 桌面 1440 × 900", -300, 8 * DSTEP - 80, "register"),
        title("t-register-m", "注册页 · 移动 375 × 812", MROW - 300, 8 * MSTEP - 80, "register"),
        title("t-nav-d", "导航栏 · 桌面 1440 × 900", -300, 8 * DSTEP - 80, "nav"),
        title("t-nav-m", "导航栏 · 移动 375 × 812", MROW - 300, len(NAV_MOBILE) * MSTEP - 80, "nav"),
        title("t-spec", "组件规范 · 新增组件的状态与尺寸", -300, 2 * DSTEP - 80, "spec"),
    ])
    notes["n-stub"] = {
        "x": 8 * DSTEP, "y": 0, "w": 420, "page": "nav", "fill": "gray", "size": "s",
        "text": "导航栏以下是 /papers 的真实页头加现有骨架，只为给导航栏一个真实语境；列表内容不在本稿范围。",
    }

    canvas = {
        "v": 3,
        "createdOnFiles": {"v": 1, "at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")},
        "title": "用户系统 v0.8 账号登录设计",
        "launch": {"view": "canvas", "page": "login"},
        "pages": [
            {"id": "login", "name": "登录页"},
            {"id": "register", "name": "注册页"},
            {"id": "nav", "name": "导航栏"},
            {"id": "spec", "name": "组件规范"},
        ],
        "boards": boards,
        "order": order,
        "notes": notes,
        "designSystems": [
            {"title": "Patra Design System", "namespace": "patra", "artifact": DS_ADDRESS, "version": DS_VERSION,
             "copiedAt": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}
        ],
    }
    cp = os.path.join(ROOT, "canvas.json")
    if os.path.exists(cp):
        # 重新生成时沿用首次写入的创建时间与设计系统记录
        with open(cp, encoding="utf-8") as f:
            old = json.load(f)
        canvas["createdOnFiles"] = old.get("createdOnFiles", canvas["createdOnFiles"])
        canvas["designSystems"] = old.get("designSystems", canvas["designSystems"])

    css = build_css()
    changed = []

    def write(rel, text):
        path = os.path.join(ROOT, rel)
        old = None
        if os.path.exists(path):
            with open(path, encoding="utf-8") as f:
                old = f.read()
        if old != text:
            with open(path, "w", encoding="utf-8") as f:
                f.write(text)
            changed.append(rel)

    for name, html in files.items():
        check(name, html)
        write(name, html)
    write("patra.css", css)
    # 画布索引只在首次生成时写入：发布后由画布编辑器接管（它会重排键、补字段），
    # 之后改布局要先从画布读回最新的 canvas.json 再改，不能用这里的副本覆盖
    if not os.path.exists(cp):
        write("canvas.json", json.dumps(canvas, ensure_ascii=False, indent=1) + "\n")

    if preview:
        pdir = os.path.join(HERE, "preview")
        os.makedirs(pdir, exist_ok=True)
        for name, html in files.items():
            for blob, local in LOCAL_ASSETS.items():
                html = html.replace(blob, local)
            with open(os.path.join(pdir, name.replace(".dc.html", ".html")), "w", encoding="utf-8") as f:
                f.write(html)
        with open(os.path.join(pdir, "patra.css"), "w", encoding="utf-8") as f:
            f.write(css)

    print(f"{len(files)} 块画板；本次变更 {len(changed)} 个文件")
    for c in changed:
        print("  ", c)


if __name__ == "__main__":
    main()
