import { createRequire } from "node:module";
import { readFileSync, existsSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
const require = createRequire(process.env.PORTAL_PKG);
const { chromium } = require("@playwright/test");
const here = dirname(fileURLToPath(import.meta.url));
const [canvasDir, file, query, ...evals] = process.argv.slice(2);
const browser = await chromium.launch({});
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
await ctx.route(/^https?:\/\//, async (route) => {
  const u = new URL(route.request().url());
  if (u.hostname !== "patra.test") return route.abort();
  let f = u.pathname === "/support.js" ? join(here, "support.js") : join(canvasDir, "project", decodeURIComponent(u.pathname.slice(1)));
  if (u.pathname.startsWith("/_blob/")) f = join(canvasDir, "assets/patra-mark.svg");
  if (!existsSync(f)) return route.fulfill({ status: 404, body: "" });
  const ext = f.split(".").pop();
  route.fulfill({ status: 200, contentType: { html: "text/html", css: "text/css", js: "text/javascript", svg: "image/svg+xml", json: "application/json" }[ext] || "application/octet-stream", body: readFileSync(f) });
});
const page = await ctx.newPage();
page.on("pageerror", (e) => console.log("[pageerror]", e.message, "\n", e.stack));
page.on("console", (m) => { if (m.type() === "error" || m.type() === "log") console.log("[console]", m.text()); });
await page.goto(`http://patra.test/${file}?${query || ""}`, { waitUntil: "domcontentloaded" });
await page.waitForFunction(() => window.__dcReady, null, { timeout: 20000 });
for (const e of evals) { const r = await page.evaluate(e); if (r !== undefined) console.log("[eval]", JSON.stringify(r).slice(0, 2000)); await page.waitForTimeout(300); }
await browser.close();
