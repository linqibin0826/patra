import re,sys
src=open(sys.argv[3] if len(sys.argv) > 3 else "patra-portal/src/styles/tokens.css",encoding="utf-8").read()
body=src[src.index(':root {'):]
body=body[:body.index('\n}\n')+3]
body=re.sub(r'/\*.*?\*/','',body,flags=re.S)
body=body.replace('var(--font-inter)','"Inter"').replace('var(--font-newsreader)','"Newsreader"').replace('"Noto Serif SC Variable"','"Noto Serif SC"').replace('var(--font-plex-mono)','"IBM Plex Mono"')
body=re.sub(r'\n\s*\n','\n',body)
body=body.replace('--gutter: clamp(20px, 4vw, 48px);','--gutter: 48px;')
body=body.rstrip()[:-1]+'  --font-sans: var(--patra-font-sans);\n  --font-serif: var(--patra-font-serif);\n  --font-mono: var(--patra-font-mono);\n}\n'
hdr='/* Patra 门户 token：自动取自 patra-portal/src/styles/tokens.css（next/font 字体变量换成 Google Fonts 字族名），不要手改；\n   下半段是画板用到的组件类（v0.12 用户中心、v0.13 文献库、v0.14 讨论、v0.15 有帮助与计数），每条注释写了对应的门户组件或 Tailwind 写法。 */\n'
comp=''.join(open(p,encoding='utf-8').read() for p in sys.argv[1].split(','))
open(sys.argv[2],'w',encoding='utf-8').write(hdr+body+'\n'+comp)
