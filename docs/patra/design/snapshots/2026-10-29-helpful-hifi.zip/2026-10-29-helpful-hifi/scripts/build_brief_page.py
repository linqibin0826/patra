# 由设计简报 Markdown 生成简报 Artifact 页面（页面在浏览器里用 marked 渲染，内容以仓库文件为准）。
# 用法：python3 build_brief_page.py <brief-page.template.html> <discussion.md> <输出 html> <更新日期>
import sys

tpl_path, md_path, out_path, updated = sys.argv[1:5]
tpl = open(tpl_path, encoding='utf-8').read()
src = open(md_path, encoding='utf-8').read().replace('</script', '<\\/script')
with open(out_path, 'w', encoding='utf-8') as f:
    f.write(tpl.replace('__MARKDOWN__', src).replace('__UPDATED__', updated))
