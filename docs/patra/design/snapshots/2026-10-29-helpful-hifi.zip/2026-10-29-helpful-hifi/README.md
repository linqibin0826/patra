# v0.15 有帮助与公开计数 · 画板快照（PAP-130）

持久画布：https://claude.ai/artifact/GzchLSeVWW1dnjnAHVhhDi　设计简报：`patra-portal/docs/design-briefs/v0.15/helpful.md`（简报页 https://claude.ai/artifact/8zarzXvtJmujDLAh4MDV86 由它生成）

| 目录 | 内容 |
|------|------|
| `project/` | 画布源文件（2026-10-29 用户确认后从画布读回，版本 1793283598-73df）：`canvas.json`（5 页 18 块）；有帮助按钮 `HelpfulStates`（9 种场景 × 4 处位置 × 6 种服务器返回，下方状态表一次列全）、组件 `Helpful`；文献页 `Paper` / `Paper-M`（事实条收藏、讨论两格 + 讨论区）、组件 `Discussion`（有帮助、「最有帮助」排序、楼内统计、标题条数，文献页与经验页共用）；期刊页经验列表 `Journal` / `Journal-M`、经验页 `Post` / `Post-M`、主页 `Profile` / `Profile-M`（获赞与经验行计数）；四处文献卡片 `Cards` / `Cards-M`、静态对比 `CardPlace`（列表卡片计数位置 A / B / C，定稿 A）；沿用 v0.14 不变的 `Nav`、`Composer`、`Md`、`ExpForm`；`patra.css`；`ds/patra/tokens.json` |
| `assets/` | 画板里以 `/_blob/<id>` 引用的素材：品牌标记（`4482e8099edebd970d220c60cce44cd6`，从 v0.14 画布用 `from_url` + `asset_ids` 复制过来的副本） |
| `scripts/` | `gen_tokens.py` 把 `patra-portal/src/styles/tokens.css` 的 `:root` 与组件类拼成 `project/patra.css`（`python3 <scripts>/gen_tokens.py <scripts>/components.css,<scripts>/components-v014.css,<scripts>/components-v015.css <project>/patra.css <tokens.css>`）；`components-v015.css` 是本版新增的类；`gen_mobile.py` 由桌面板生成手机薄包装板（`python3 gen_mobile.py <project> [Paper Journal Post Profile Cards]`）；`brief-page.template.html` + `build_brief_page.py` 生成简报 Artifact 页 |
| `harness/` | 本机自查：`support.js` 是最小运行时垫片（同 v0.14，只实现画板用到的语法）；`shoot.mjs` 用 portal 自带的 Playwright 按清单截图（`PORTAL_PKG=<装过依赖的 patra-portal/package.json> node <harness>/shoot.mjs <快照目录> <shots.json> <输出目录> [offline]`）；`debug.mjs` 打印页面报错的堆栈 |

场景在每块画板的 Tweaks 里切：「场景」是身份、数据与计数，「服务器返回」模拟接口结果（`helpResult` 对应简报 §3.2 的各种失败），「版式」的窄屏只给桌面板用。状态 ID 与简报 §4 一一对应。

2026-10-29 用户确认画板，简报 §10 的十条按画板定稿：`ThumbsUp` 图标；自己的内容为 0 时不显示；经验行改成铺满链接 + 底部操作行；列表卡片计数末尾单独一行、服务端取、未登录也显示；文献页收藏人数进事实条末尾；楼内统计放根评论操作行右端；邮箱未验证前端拦、失败用行内提示；「最有帮助」下新评论插在最上面、点了不重排；主页获赞不即时变；本人收藏时收藏人数 ±1。

本版没有做流程闭环板（AC 没有要求，验证场景在各页面板上逐条可走，见简报 §0）。示例数据沿用 v0.14 的文献、期刊与人物，文献卡片加了 CITRIS-ALI（JAMA 2019）与 LOVIT（NEJM 2022）；所有计数都是示意。`patra.css` 下半段的组件类是画板专用的，落地时照门户现有组件与 Tailwind 写法实现，不照搬类名。
