// 本机自查用的最小 .dc.html 运行时垫片：只实现画板用到的 {{}}、sc-if、sc-for、dc-import、onX 事件、setState。
// 不是画布的真实运行时，只用来本机截图核对版式。
(function () {
  class DCLogic {
    constructor(props) { this.props = props || {}; this.state = null; }
    setState(p) {
      const patch = typeof p === 'function' ? p(this.state, this.props) : p;
      this.state = Object.assign({}, this.state || {}, patch);
      if (this.__rerender) this.__rerender();
    }
    forceUpdate() { if (this.__rerender) this.__rerender(); }
  }
  window.DCLogic = DCLogic;

  function lookup(scope, path) {
    path = path.trim();
    if (path === 'true') return true;
    if (path === 'false') return false;
    if (/^-?\d+(\.\d+)?$/.test(path)) return Number(path);
    return path.split('.').reduce((o, k) => (o == null ? undefined : o[k]), scope);
  }
  function interp(str, scope) {
    const whole = str.match(/^\{\{\s*([^}]+?)\s*\}\}$/);
    if (whole) return lookup(scope, whole[1]);
    return str.replace(/\{\{\s*([^}]+?)\s*\}\}/g, (m, p) => {
      const v = lookup(scope, p);
      return v == null ? '' : String(v);
    });
  }
  const camel = (s) => s.replace(/-([a-z])/g, (m, c) => c.toUpperCase());

  async function loadComponent(url) {
    const html = await fetch(url).then((r) => r.text());
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const xdc = doc.querySelector('x-dc');
    const script = doc.querySelector('script[data-dc-script]');
    return { xdc, script };
  }

  function makeInstance(script, props) {
    const defs = JSON.parse(script.getAttribute('data-props') || '{}');
    const merged = {};
    for (const k of Object.keys(defs)) if (k[0] !== '$' && defs[k] && 'default' in defs[k]) merged[k] = defs[k].default;
    Object.assign(merged, props);
    const Cls = new Function('DCLogic', script.textContent + '\nreturn Component;')(DCLogic);
    return new Cls(merged);
  }

  function renderNodes(nodes, scope, out, pending) {
    for (const n of nodes) {
      if (n.nodeType === 3) { out.appendChild(document.createTextNode(interp(n.nodeValue, scope))); continue; }
      if (n.nodeType !== 1) continue;
      const tag = n.localName;
      if (tag === 'helmet') continue;
      if (tag === 'sc-if') { if (lookup(scope, n.getAttribute('value').replace(/^\{\{|\}\}$/g, ''))) renderNodes(n.childNodes, scope, out, pending); continue; }
      if (tag === 'sc-for') {
        const list = lookup(scope, n.getAttribute('list').replace(/^\{\{|\}\}$/g, '')) || [];
        const as = n.getAttribute('as');
        list.forEach((item, i) => renderNodes(n.childNodes, Object.assign(Object.create(scope), { [as]: item, $index: i }), out, pending));
        continue;
      }
      if (tag === 'dc-import') {
        const holder = document.createElement('div');
        const props = {};
        for (const a of n.attributes) if (a.name !== 'name' && !a.name.startsWith('hint-')) props[camel(a.name)] = interp(a.value, scope);
        out.appendChild(holder);
        pending.push(mount(n.getAttribute('name') + '.dc.html', holder, props));
        continue;
      }
      const el = n.namespaceURI === 'http://www.w3.org/1999/xhtml' ? document.createElement(tag) : document.createElementNS(n.namespaceURI, n.localName);
      for (const a of n.attributes) {
        if (/^on[a-z]/i.test(a.name) && a.value.includes('{{')) {
          const fn = interp(a.value, scope);
          let ev = a.name.slice(2).toLowerCase();
          // React 的 onChange 在文本框里每次输入都触发：垫片里对应 input 事件
          if (ev === 'change' && (tag === 'textarea' || (tag === 'input' && !/^(checkbox|radio|range)$/.test(n.getAttribute('type') || '')))) ev = 'input';
          if (ev === 'doubleclick') ev = 'dblclick';
          if (typeof fn === 'function') el.addEventListener(ev, (e) => { fn(e); });
          continue;
        }
        const v = interp(a.value, scope);
        if (v === false || v == null) continue;
        el.setAttribute(a.name, v === true ? '' : String(v));
      }
      renderNodes(n.childNodes, scope, el, pending);
      if ((tag === 'input' || tag === 'textarea' || tag === 'select') && el.hasAttribute('value')) el.value = el.getAttribute('value');
      if (tag === 'textarea' && n.hasAttribute('value')) el.textContent = el.getAttribute('value');
      out.appendChild(el);
    }
  }

  async function mount(url, host, props) {
    const { xdc, script } = await loadComponent(url);
    const inst = makeInstance(script, props);
    const tpl = Array.from(xdc.childNodes);
    let mounted = false;
    const draw = () => {
      const scope = inst.renderVals();
      const frag = document.createDocumentFragment();
      const pending = [];
      renderNodes(tpl, scope, frag, pending);
      host.replaceChildren(frag);
      return Promise.all(pending);
    };
    inst.__rerender = () => { draw(); if (inst.componentDidUpdate) inst.componentDidUpdate(); };
    await draw();
    mounted = true;
    if (inst.componentDidMount) inst.componentDidMount();
    window.__dcInstances = (window.__dcInstances || []).concat(inst);
    return inst;
  }

  window.addEventListener('DOMContentLoaded', async () => {
    const helm = document.querySelector('x-dc helmet');
    if (helm) for (const c of Array.from(helm.children)) document.head.appendChild(c.cloneNode(true));
    const q = new URLSearchParams(location.search);
    const props = {};
    for (const [k, v] of q) props[k] = v === '1' ? true : v === '0' ? false : v;
    const host = document.createElement('div');
    document.querySelector('x-dc').replaceWith(host);
    await mount(location.pathname.split('/').pop(), host, props);
    window.__dcReady = true;
  });
})();
