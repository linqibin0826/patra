// 本机自查：用 portal 自带的 Playwright 打开画板（垫片运行时 support.js），按清单截图。
// 用法（在仓库根目录运行）：node <harness>/shoot.mjs <canvasDir> <shots.json> <outDir> [offline]
// shots.json：[{ "file": "Main.dc.html", "q": { "scenario": "…" }, "size": "desktop|mobile", "out": "x.png", "eval": "js", "full": true }]
import { createRequire } from "node:module";
import { readFileSync, mkdirSync, existsSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const require = createRequire(join(process.cwd(), "patra-portal/package.json"));
const { chromium } = require("@playwright/test");
const here = dirname(fileURLToPath(import.meta.url));
const [canvasDir, shotsFile, outDir, offline] = process.argv.slice(2);
mkdirSync(outDir, { recursive: true });
const shots = JSON.parse(readFileSync(shotsFile, "utf8"));
// 画布素材 id → 本地文件（画板里写的是 /_blob/<id>）
const BLOB = {
  "6761d1820d5f49156b8361937d5f5396": "assets/patra-mark.svg",
  "c15dd1c1b514e5cf9680ebc8975648d7": "assets/venation-inverse.svg",
  "59917a26c1958045df608914283fb956": "assets/venation-paper.svg",
  "e6980453253718917facd9b55b89ab52": "assets/avatar-sample.svg",
};
const TYPES = { html: "text/html", css: "text/css", js: "text/javascript", svg: "image/svg+xml", webp: "image/webp", json: "application/json", png: "image/png" };

const browser = await chromium.launch(offline ? {} : { proxy: { server: "http://127.0.0.1:7890" } });
const ctxs = {};
async function ctxFor(size) {
  if (!ctxs[size]) {
    ctxs[size] = await browser.newContext(
      size === "mobile" ? { viewport: { width: 375, height: 812 }, deviceScaleFactor: 2 } : size === "email" ? { viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 } : { viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 },
    );
    await ctxs[size].route(/^https?:\/\//, async (route) => {
      const u = new URL(route.request().url());
      if (u.hostname === "patra.test") {
        let file;
        if (u.pathname.startsWith("/_blob/")) file = BLOB[u.pathname.slice(7)] ? join(canvasDir, BLOB[u.pathname.slice(7)]) : "";
        else if (u.pathname === "/support.js") file = join(here, "support.js");
        else file = join(canvasDir, "project", decodeURIComponent(u.pathname.slice(1)));
        const ext = (file || "").split(".").pop();
        if (!file || !existsSync(file)) return route.fulfill({ status: 404, body: "" });
        return route.fulfill({ status: 200, contentType: TYPES[ext] || "application/octet-stream", body: readFileSync(file) });
      }
      if (offline) return route.abort();
      return route.continue();
    });
  }
  return ctxs[size];
}

for (const s of shots) {
  const ctx = await ctxFor(s.size || "desktop");
  const page = await ctx.newPage();
  page.on("pageerror", (e) => console.log("[pageerror]", s.out, e.message));
  page.on("console", (m) => { if (m.type() === "error") console.log("[console]", s.out, m.text()); });
  const q = new URLSearchParams(s.q || {});
  await page.goto(`http://patra.test/${s.file}?${q}`, { waitUntil: "domcontentloaded" });
  try {
    await page.waitForFunction(() => window.__dcReady, null, { timeout: 20000 });
  } catch (e) { console.log("[timeout]", s.out); }
  await page.evaluate(() => document.fonts.ready);
  if (s.eval) {
    for (const step of [].concat(s.eval)) {
      await page.evaluate(step);
      await page.waitForTimeout(120);
    }
  }
  await page.waitForTimeout(offline ? 250 : 900);
  const h = await page.evaluate(() => document.documentElement.scrollHeight);
  await page.screenshot({ path: join(outDir, s.out), fullPage: s.full !== false });
  console.log(s.out, "height", h);
  await page.close();
}
await browser.close();
