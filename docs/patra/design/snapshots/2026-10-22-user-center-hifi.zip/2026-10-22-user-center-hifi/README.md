# v0.12 用户中心 · 画板快照（PAP-92）

持久画布：https://claude.ai/artifact/W8hmKqm6JcFdZu5FPy6MQ8　设计简报：`patra-portal/docs/design-briefs/v0.12/user-center.md`

| 目录 | 内容 |
|------|------|
| `project/` | 画布源文件（2026-10-22 从画布读回，版本 1792652947-2810）：`canvas.json`（4 页 20 块画板）、8 个可交互页面各一份桌面 `X.dc.html` 与移动 `X-M.dc.html`（移动板引用桌面板并打开窄屏模式）、静态板 `Avatars` / `Reserve` / `Emails` / `Emails-M`、`patra.css`、`ds/patra/tokens.json`（设计系统 token 副本） |
| `assets/` | 画板里以 `/_blob/<id>` 引用的素材：品牌标记、叶脉（墨底 / 纸底）、头像样图（叶脉合成，不是人像） |
| `scripts/` | `gen_tokens.py` 把 `patra-portal/src/styles/tokens.css` 的 `:root` 与 `components.css` 拼成 `project/patra.css`（`python3 gen_tokens.py components.css ../project/patra.css`） |
| `harness/` | 本机自查：`support.js` 是最小运行时垫片（只实现画板用到的 `{{}}`、`sc-if`、`sc-for`、`dc-import`、事件、`setState`、受控输入，不是画布真实运行时）；`shoot.mjs` 用 portal 自带的 Playwright 按清单截图，在仓库根目录运行 `node <harness>/shoot.mjs <快照目录> <shots.json> <输出目录> [offline]` |

画板分页：注册 · 导航（`Main`、`Nav`）／设置四个分区（`Profile`、`Account`、`Security`、`Privacy`）／公开主页 · 头像（`User`、`Reserve`、`Avatars`）／落地页 · 邮件（`Landing`、`Emails`）。场景在每块画板的 Tweaks 里切：「场景」一组是数据与状态开关，「服务器返回」一组模拟后端的各种响应，「版式」里的窄屏只给桌面板用。状态 ID 与简报 §4 一一对应。

`patra.css` 下半段的组件类是画板专用的，注释写了对应的门户组件；落地时照门户现有组件与 Tailwind 写法实现，不照搬类名。
