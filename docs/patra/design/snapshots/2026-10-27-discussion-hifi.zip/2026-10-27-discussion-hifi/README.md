# v0.14 讨论 · 画板快照（PAP-116）

持久画布：https://claude.ai/artifact/DcyaGqN7xUMiXNbK3exaBN　设计简报：`patra-portal/docs/design-briefs/v0.14/discussion.md`（简报页 https://claude.ai/artifact/8gaNTAsBGiHn6pQgfbYw3G 由它生成）

| 目录 | 内容 |
|------|------|
| `project/` | 画布源文件（2026-10-27 从画布读回，版本 1793075880-9b45）：`canvas.json`（4 页 20 块画板）；流程 `Flow` / `Flow-M`（步骤条串起六步）；文献讨论 `Paper` / `Paper-M`、组件 `Discussion`（文献页与经验页共用的讨论区）、`Composer`（编辑器与 @ 联想）、`Md`（Markdown 渲染）、静态对照 `Markdown`；投稿经验 `Journal` / `Journal-M`、组件 `ExpForm`（表单）、`Post` / `Post-M`（经验页）、`Profile` / `Profile-M`（主页「投稿经验」标签）；提醒 `Nav` / `Nav-M`（铃铛、用户菜单、窄屏顶栏与全屏菜单）、静态对比 `NavNarrow`（窄屏铃铛位置 B / A / C，定稿 B）、`Inbox` / `Inbox-M`（提醒列表）；`patra.css`；`ds/patra/tokens.json`（设计系统 token 副本） |
| `assets/` | 画板里以 `/_blob/<id>` 引用的素材：品牌标记（`ea834b7f7f51560bc0039c433b82bcd5`） |
| `scripts/` | `gen_tokens.py` 把 `patra-portal/src/styles/tokens.css` 的 `:root` 与组件类拼成 `project/patra.css`（v0.14 改为接收逗号分隔的多个组件文件：`python3 <scripts>/gen_tokens.py <scripts>/components.css,<scripts>/components-v014.css <project>/patra.css <tokens.css>`）；`components-v014.css` 是本版新增的组件类；`gen_mobile.py` 由桌面板生成手机薄包装板；`brief-page.template.html` + `build_brief_page.py` 生成简报 Artifact 页 |
| `harness/` | 本机自查：`support.js` 是最小运行时垫片（同 v0.13，只实现画板用到的语法，不是画布真实运行时）；`shoot.mjs` 用 portal 自带的 Playwright 按清单截图（`PORTAL_PKG=<装过依赖的 patra-portal/package.json> node <harness>/shoot.mjs <快照目录> <shots.json> <输出目录> [offline]`，worktree 没装依赖时指向主检出）；`debug.mjs` 打印页面报错的堆栈 |

画板分页：流程闭环（`Flow`）／文献讨论（`Paper`、`Discussion`、`Composer`、`Md`、`Markdown`）／投稿经验（`Journal`、`ExpForm`、`Post`、`Profile`）／提醒 · 导航（`Nav`、`NavNarrow`、`Inbox`）。场景在每块画板的 Tweaks 里切：「场景」一组是身份、数据与状态，「服务器返回」一组模拟后端的各种响应，「版式」里的窄屏只给桌面板用。状态 ID 与简报 §4 一一对应。

`Flow` 顶部是步骤条，串起 spec 第 1 节的验证场景：陈宇在文献页发起讨论 → 周敏回复 → 陈宇在期刊页写投稿经验（「同行经验」从 4 条变成完整统计）→ 林知远在经验下追问并 @ 陈宇 → 陈宇看到两条提醒 → 在单楼视图里回复。每一步的数据按上一步的结果预置，步骤之间不传状态。

2026-10-27 用户已定（简报 §10）：窄屏顶栏「检索 · 铃铛 · 菜单」；投稿经验表单在期刊页原地展开；修改历史逐版标出增删；「首轮用时」不含直接拒稿；既回复又 @ 同一人时提醒归「回复我的」。同日 identity 的 @ 前缀联想加了按昵称匹配，`Composer` 的「正在 @ 陈（按昵称）」场景演示它。

示例数据用的是真实文献：Marik 2017（Chest，PMID 27940189）与 VITAMINS（JAMA 2020，PMID 31950979）；期刊用 Journal of the American Heart Association。讨论内容、投稿经验和两组审稿周期的统计数字都是示意，落地时以接口返回为准。

`patra.css` 下半段的组件类是画板专用的，注释写了对应的门户组件；落地时照门户现有组件与 Tailwind 写法实现，不照搬类名。
